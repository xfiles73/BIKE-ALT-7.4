import 'dart:io';

import 'package:bike_control/gen/l10n.dart';
import 'package:bike_control/main.dart';
import 'package:bike_control/pages/markdown.dart';
import 'package:bike_control/utils/core.dart';
import 'package:bike_control/utils/i18n_extension.dart';
import 'package:bike_control/utils/keymap/apps/supported_app.dart';
import 'package:bike_control/utils/requirements/local_network.dart';
import 'package:bike_control/widgets/ui/connection_method.dart';
import 'package:bike_control/widgets/ui/toast.dart';
import 'package:prop/prop.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';

class MyWhooshLinkTile extends StatefulWidget {
  final bool small;
  const MyWhooshLinkTile({super.key, required this.small});

  @override
  State<MyWhooshLinkTile> createState() => _MywhooshLinkTileState();
}

class _MywhooshLinkTileState extends State<MyWhooshLinkTile> {
  /// Built once, not per build: PlatformRequirement carries a mutable
  /// `status`, so rebuilding the list every frame throws away whatever the
  /// last probe learned.
  final _requirements = localNetworkRequirements();

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder(
      valueListenable: core.whooshLink.isStarted,
      builder: (context, isStarted, _) {
        return ValueListenableBuilder(
          valueListenable: core.whooshLink.isConnected,
          builder: (context, isConnected, _) {
            return ConnectionMethod(
              trainerConnection: core.whooshLink,
              isRecommended: Platform.isIOS,
              small: widget.small,
              supportLevel: core.settings.getTrainerApp()?.supportLevel(AppConnectionMethod.myWhooshLink),
              isEnabled: core.settings.getMyWhooshLinkEnabled(),
              title: context.i18n.connectUsingMyWhooshLink,
              instructionLink: 'INSTRUCTIONS_MYWHOOSH_LINK.md',
              description: isConnected
                  ? context.i18n.myWhooshLinkConnected
                  : isStarted
                  ? context.i18n.checkMyWhooshConnectionScreen
                  : context.i18n.myWhooshLinkDescriptionLocal,
              requirements: _requirements,
              showTroubleshooting: true,
              onChange: (value) {
                core.settings.setMyWhooshLinkEnabled(value);
                if (!value) {
                  core.whooshLink.stopServer();
                } else if (value) {
                  buildToast(
                    title: AppLocalizations.of(context).myWhooshLinkInfo,
                    level: LogLevel.LOGLEVEL_INFO,
                    duration: Duration(seconds: 6),
                    closeTitle: AppLocalizations.current.open,
                    onClose: () {
                      openDrawer(
                        context: context,
                        position: OverlayPosition.bottom,
                        builder: (c) => MarkdownPage(assetPath: 'INSTRUCTIONS_MYWHOOSH_LINK.md'),
                      );
                    },
                  );
                  core.connection.startMyWhooshServer().catchError((e, s) {
                    recordError(e, s, context: 'MyWhoosh Link Server');
                    core.settings.setMyWhooshLinkEnabled(false);
                    buildToast(
                      title: context.i18n.errorStartingMyWhooshLink,
                    );
                  });
                }
              },
            );
          },
        );
      },
    );
  }
}
