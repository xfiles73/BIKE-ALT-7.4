import 'package:bike_control/bluetooth/messages/notification.dart';
import 'package:bike_control/main.dart';
import 'package:bike_control/pages/network_troubleshooting_page.dart';
import 'package:bike_control/utils/core.dart';
import 'package:bike_control/utils/i18n_extension.dart';
import 'package:bike_control/utils/keymap/apps/supported_app.dart';
import 'package:bike_control/utils/requirements/local_network.dart';
import 'package:bike_control/widgets/ui/connection_method.dart';
import 'package:dartx/dartx.dart';
import 'package:prop/prop.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';

class OpenBikeControlMdnsTile extends StatefulWidget {
  final bool small;
  const OpenBikeControlMdnsTile({super.key, required this.small});

  @override
  State<OpenBikeControlMdnsTile> createState() => _OpenBikeProtocolTileState();
}

class _OpenBikeProtocolTileState extends State<OpenBikeControlMdnsTile> {
  /// Built once, not per build: PlatformRequirement carries a mutable
  /// `status`, so rebuilding the list every frame throws away whatever the
  /// last probe learned.
  final _requirements = localNetworkRequirements();

  @override
  Widget build(BuildContext context) {
    return Column(
      spacing: 8,
      children: [
        ValueListenableBuilder(
          valueListenable: core.obpMdnsEmulator.isStarted,
          builder: (context, isStarted, _) {
            return ValueListenableBuilder(
              valueListenable: core.obpMdnsEmulator.connectedApp,
              builder: (context, isConnected, _) {
                return ConnectionMethod(
                  trainerConnection: core.obpMdnsEmulator,
                  isRecommended: true,
                  small: widget.small,
                  supportLevel: core.settings.getTrainerApp()?.supportLevel(AppConnectionMethod.obpMdns),
                  supportedActions: isConnected?.supportedActions,
                  isEnabled: core.settings.getObpMdnsEnabled(),
                  title: context.i18n.connectDirectlyOverNetwork,
                  instructionLink: 'https://bikecontrol.app/blog/mywhoosh-bikecontrol-partnership',
                  description: isConnected != null
                      ? context.i18n.connectedTo(
                          "${isConnected.appId}:\n${isConnected.supportedActions.joinToString(transform: (s) => s.title)}",
                        )
                      : isStarted
                      ? context.i18n.chooseBikeControlInConnectionScreen
                      : context.i18n.letsAppConnectOverNetwork(core.settings.getTrainerApp()?.name ?? ''),
                  requirements: _requirements,
                  onTroubleshoot: () => context.push(const NetworkTroubleshootingPage()),
                  onChange: (value) {
                    core.settings.setObpMdnsEnabled(value);
                    if (!value) {
                      core.obpMdnsEmulator.stopServer();
                    } else if (value) {
                      core.obpMdnsEmulator.startServer().catchError((e, s) {
                        recordError(e, s, context: 'OBP mDNS Emulator');
                        core.settings.setObpMdnsEnabled(false);
                        core.connection.signalNotification(
                          AlertNotification(
                            LogLevel.LOGLEVEL_ERROR,
                            "${context.i18n.errorStartingOpenBikeControlServer}:\n$e",
                          ),
                        );
                      });
                    }
                    setState(() {});
                  },
                );
              },
            );
          },
        ),
      ],
    );
  }
}
