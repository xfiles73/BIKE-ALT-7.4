import 'dart:async';

import 'package:bike_control/bluetooth/devices/base_device.dart';
import 'package:bike_control/utils/core.dart';
import 'package:bike_control/utils/i18n_extension.dart';
import 'package:bike_control/widgets/ui/connection_method.dart';
import 'package:bike_control/widgets/ui/wifi_animation.dart';
import 'package:flutter/foundation.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';

import '../utils/requirements/platform.dart';

class ScanWidget extends StatefulWidget {
  const ScanWidget({super.key});

  @override
  State<ScanWidget> createState() => _ScanWidgetState();
}

class _ScanWidgetState extends State<ScanWidget> with WidgetsBindingObserver {
  List<PlatformRequirement>? _needsPermissions;
  StreamSubscription<BaseDevice>? _connectionSub;

  @override
  void initState() {
    super.initState();

    _checkRequirements();
    WidgetsBinding.instance.addObserver(this);
    // The requirement list is captured once at mount — but permissions can be
    // granted while this widget sits behind another route (the onboarding
    // wizard grants them on its controller step). A device connecting proves
    // scanning works, and app resume covers grants via system settings.
    _connectionSub = core.connection.connectionStream.listen((_) {
      if (mounted && (_needsPermissions?.isNotEmpty ?? false)) {
        _checkRequirements();
      }
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && (_needsPermissions?.isNotEmpty ?? false)) {
      _checkRequirements();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _connectionSub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        if (_needsPermissions != null && _needsPermissions!.isNotEmpty)
          Basic(
            padding: EdgeInsets.all(12),
            title: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(context.i18n.permissionsRequired).xSmall.normal,
                Gap(12),
                ..._needsPermissions!.map((e) => Text(e.name).xSmall.normal.li),
              ],
            ),
            subtitle: Container(
              width: double.infinity,
              padding: const EdgeInsets.only(top: 12.0),
              child: PrimaryButton(
                child: Center(child: Text(context.i18n.enablePermissions)),
                onPressed: () async {
                  await openPermissionSheet(context, _needsPermissions!);
                  _checkRequirements();
                },
              ),
            ),
          )
        else
          Container(
            alignment: Alignment.center,
            padding: const EdgeInsets.symmetric(horizontal: 12.0),
            child: ValueListenableBuilder(
              valueListenable: core.connection.isScanning,
              builder: (context, isScanning, widget) {
                if (isScanning) {
                  return Column(
                    spacing: 18,
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (core.connection.controllerDevices.isEmpty)
                        Column(
                          spacing: 14,
                          children: [
                            SmoothWifiAnimation(),
                            Text(
                              context.i18n.scanningForDevices,
                              textAlign: TextAlign.center,
                            ).small.muted,
                          ],
                        ),
                      SizedBox(),
                    ],
                  );
                } else {
                  return Row(
                    children: [
                      PrimaryButton(
                        onPressed: () {
                          core.connection.performScanning();
                        },
                        child: Text(context.i18n.scan),
                      ),
                    ],
                  );
                }
              },
            ),
          ),
      ],
    );
  }

  void _checkRequirements() {
    core.permissions.getScanRequirements().then((permissions) {
      if (!mounted) return;
      setState(() {
        _needsPermissions = permissions;
      });
      if (permissions.isEmpty && !kIsWeb) {
        core.connection.performScanning();
      }
    });
  }
}
