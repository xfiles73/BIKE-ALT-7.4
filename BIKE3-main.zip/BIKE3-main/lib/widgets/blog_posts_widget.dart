import 'package:bike_control/services/blog_service.dart';
import 'package:bike_control/widgets/ui/colored_title.dart';
import 'package:bike_control/widgets/ui/colors.dart';
import 'package:bike_control/widgets/ui/type_scale.dart';
import 'package:intl/intl.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

class BlogPostsWidget extends StatefulWidget {
  final int maxPosts;
  final bool showHeader;
  final ValueChanged<bool>? onHasNewPosts;

  /// Test seam: replaces the default `BlogService().fetchPosts()` call —
  /// see blog_posts_widget_test.dart.
  final Future<List<BlogPost>>? postsFutureOverride;

  const BlogPostsWidget({
    super.key,
    this.maxPosts = 5,
    this.showHeader = true,
    this.onHasNewPosts,
    this.postsFutureOverride,
  });

  @override
  State<BlogPostsWidget> createState() => _BlogPostsWidgetState();
}

class _BlogPostsWidgetState extends State<BlogPostsWidget> {
  late Future<List<BlogPost>> _postsFuture;

  @override
  void initState() {
    super.initState();
    _postsFuture = widget.postsFutureOverride ?? BlogService().fetchPosts();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<BlogPost>>(
      future: _postsFuture,
      builder: (context, snapshot) {
        final posts = snapshot.data;

        final didLoad = posts != null;

        final displayPosts =
            (posts ??
                    List.filled(
                      widget.maxPosts,
                      BlogPost(
                        date: DateTime.now().add(Duration(days: -5)),
                        title: 'title title title ',
                        slug: '',
                      ),
                    ))
                .take(widget.maxPosts)
                .toList();
        final dateFormat = DateFormat.yMMMd();
        final hasNew = displayPosts.any((p) => p.isNew);

        // Notify parent about new-post status (used for tab badge).
        if (widget.onHasNewPosts != null) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            widget.onHasNewPosts!(hasNew);
          });
        }

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (widget.showHeader)
              Padding(
                padding: const EdgeInsets.only(left: 16, top: 4),
                child: ColoredTitle(text: 'BikeControl Blog', icon: LucideIcons.rss),
              ),
            if (widget.showHeader) const Gap(8),
            ...displayPosts.map(
              (post) => _BlogPostRow(post: post, dateFormat: dateFormat).asSkeleton(enabled: !didLoad),
            ),
          ],
        );
      },
    );
  }
}

class _BlogPostRow extends StatelessWidget {
  final BlogPost post;
  final DateFormat dateFormat;

  const _BlogPostRow({required this.post, required this.dateFormat});

  @override
  Widget build(BuildContext context) {
    // Follow the app's active language (OS locale or the in-app override from
    // the settings language switcher — see units.dart for the same lookup).
    // German posts live at their own /de/blog/<german-slug>/ URL; posts
    // without a translation fall back to the English one.
    final languageCode = Localizations.localeOf(context).languageCode;

    return Button.ghost(
      onPressed: () => launchUrl(Uri.parse(post.urlForLanguage(languageCode))),
      child: SizedBox(
        width: double.infinity,
        child: Basic(
          leading: post.isNew ? _newBadge(context) : null,
          title: Text(
            post.titleForLanguage(languageCode),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(color: Theme.of(context).colorScheme.mutedForeground),
          ).normal,
          trailing: Row(
            spacing: 8,
            children: [
              Text(dateFormat.format(post.date)).xSmall.normal.muted,
              Icon(LucideIcons.chevronRight, size: 18),
            ],
          ),
        ),
      ),
    );
  }

  Widget _newBadge(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: BKColor.main,
        borderRadius: BorderRadius.circular(4),
      ),
      child: Text(
        'NEW',
        style: context.typography.caption.copyWith(
          color: Colors.white,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.5,
        ),
      ),
    );
  }
}
