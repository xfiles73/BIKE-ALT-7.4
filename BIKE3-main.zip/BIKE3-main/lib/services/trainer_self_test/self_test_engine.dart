import 'dart:math' as math;

import 'package:bike_control/main.dart' show recordError;
import 'package:bike_control/services/trainer_self_test/self_test_harness.dart';
import 'package:bike_control/services/trainer_self_test/self_test_result.dart';
import 'package:flutter/foundation.dart';

/// Coarse stage of a running self-test. The precheck (waiting for the first
/// power sample) runs inside [SelfTestPhase.baseline] — from the rider's point
/// of view it is all "start pedaling".
enum SelfTestPhase { idle, baseline, ergStaircase, shiftSweep, done }

/// Immutable snapshot of the engine, rebuilt on every transition.
@immutable
class SelfTestState {
  final SelfTestPhase phase;

  /// True while the "keep pedaling" banner should be shown; the current step's
  /// clock is stopped while this holds.
  final bool pausedForCadence;

  /// True once the run has established that this trainer reports no cadence.
  /// Surfaced in the card while the test runs and again under the verdict —
  /// the rider should not have to guess why nothing on screen mentions rpm.
  final bool cadenceless;

  /// Non-null during [SelfTestPhase.ergStaircase] — the watt target currently
  /// commanded on the trainer.
  final int? currentErgTarget;

  /// Grow as steps finish; `true` == that step responded as commanded.
  final List<bool> ergStepResults;
  final List<bool> shiftStepResults;

  /// Non-null once [phase] == [SelfTestPhase.done].
  final SelfTestResult? result;

  const SelfTestState({
    this.phase = SelfTestPhase.idle,
    this.pausedForCadence = false,
    this.cadenceless = false,
    this.currentErgTarget,
    this.ergStepResults = const [],
    this.shiftStepResults = const [],
    this.result,
  });
}

/// Injectable delay so tests can drive the engine on a virtual clock.
typedef Sleeper = Future<void> Function(Duration);

/// Guided trainer resistance self-test: baseline → ERG staircase → shift sweep
/// → verdict.
///
/// Pure state machine — it owns no UI and no persistence. [run] returns the
/// [SelfTestResult]; storing it is the caller's job. Every phase transition and
/// step outcome is mirrored into [SelfTestHarness.log] as a short English line
/// (developer diagnostics for Activity/the support bundle, deliberately not
/// localized).
class SelfTestEngine {
  SelfTestEngine({required this.harness, Sleeper? sleep, DateTime Function()? now})
    : _sleep = sleep ?? _realSleep,
      _now = now ?? DateTime.now;

  final SelfTestHarness harness;
  final Sleeper _sleep;
  final DateTime Function() _now;

  // ---------------------------------------------------------------- timings
  /// Sampling period — everything below is expressed in whole ticks.
  static const Duration tick = Duration(milliseconds: 500);

  /// No power sample at all within this window → [SelfTestVerdict.noData].
  static const Duration noDataTimeout = Duration(seconds: 5);

  /// Cadence that counts as "pedaling" (start + resume threshold), rpm.
  static const int baselineCadenceMin = 40;

  /// Cadence must hold [baselineCadenceMin] this long before measuring.
  static const Duration baselineHold = Duration(seconds: 3);

  /// How long to look for any cadence reading before concluding the trainer
  /// does not report cadence at all.
  static const Duration cadenceProbe = Duration(seconds: 3);

  /// Power at or below which a rider on a cadence-less trainer counts as
  /// coasting, W — the stand-in for [pauseCadenceBelow] there.
  static const int coastingPowerW = 10;

  /// Power window whose median becomes `p0`.
  static const Duration baselineWindow = Duration(seconds: 3);

  /// Budget for one ERG step to land in band.
  static const Duration stepDuration = Duration(seconds: 8);

  /// ERG in-band tolerance: `max(ergBandFloorW, ergBandFraction * target)`.
  static const int ergBandFloorW = 15;
  static const double ergBandFraction = 0.12;

  /// Consecutive in-band ticks that make an ERG step pass.
  static const int ergInBandTicks = 2;

  /// ERG staircase targets: `[p0 + up, max(min, p0 - down), p0 + up]`.
  static const int ergStepUpW = 40;
  static const int ergStepDownW = 30;
  static const int ergStepMinW = 60;

  /// Steps that must pass for the ERG / shift phase to count as working.
  static const int stepsToPass = 2;

  /// Below this cadence the rider counts as coasting, rpm.
  static const int pauseCadenceBelow = 30;

  /// Coasting this long pauses the test.
  static const Duration pauseAfter = Duration(seconds: 4);

  /// Staying paused this long aborts it.
  static const Duration pauseTimeout = Duration(seconds: 20);

  /// Trailing window averaged into one plateau reading.
  static const Duration plateauWindow = Duration(seconds: 4);

  /// Upshifts scored during the sweep, and the gears kept free for them.
  static const int shiftTransitions = 3;
  static const int headroomGears = 3;

  /// A transition must not be explained by the rider spinning up/down.
  static const double cadenceDriftTolerance = 0.15;

  /// Safety stops for the shifting loops (a trainer may refuse to shift, and
  /// maxGear is rider-configurable down to 1).
  static const int maxRestoreShifts = 60;
  static const int maxHeadroomShifts = 8;

  // ------------------------------------------------------------------ state
  final ValueNotifier<SelfTestState> _state = ValueNotifier(const SelfTestState());

  ValueListenable<SelfTestState> get state => _state;

  Future<SelfTestResult>? _runFuture;
  bool _cancelled = false;

  SelfTestPhase _phase = SelfTestPhase.idle;
  bool _paused = false;
  int? _currentErgTarget;
  final List<bool> _ergResults = [];
  final List<bool> _shiftResults = [];
  SelfTestResult? _result;

  /// Every diagnostic line the run has emitted, in order. Handed to
  /// [SelfTestResult.stepLog] in [_buildResult] so a completed test's full trace
  /// rides along in the support bundle instead of living only in the volatile
  /// app log. [_record] is the single door that keeps this and the harness log
  /// in step.
  final List<String> _stepLog = [];

  /// Latest samples, refreshed by [_tick].
  int? _power;
  int? _cadence;

  /// True once any cadence reading has arrived, and its settled inverse:
  /// [_cadenceless] means this trainer's telemetry carries no cadence field at
  /// all, so every cadence gate below has to score on power instead.
  bool _cadenceSeen = false;
  bool _cadenceless = false;

  /// Pause bookkeeping.
  bool _pauseArmed = false;
  int _lowCadenceTicks = 0;
  int _pausedTicks = 0;

  /// Steps actually scored (0 for a skipped ERG phase).
  int _ergTotal = 0;
  int _shiftTotal = 0;

  /// Set while our own writes still need undoing.
  bool _ergDirty = false;
  bool _gearDirty = false;

  /// Runs the whole test, once. A repeat call returns the first run's result —
  /// in flight or already completed — so a second tap can't interleave two
  /// sweeps; a genuine re-test needs a fresh engine.
  Future<SelfTestResult> run() => _runFuture ??= _run();

  /// Ends the test at the next tick with [SelfTestVerdict.aborted]; restore
  /// still runs.
  void cancel() {
    if (_cancelled || _phase == SelfTestPhase.done) {
      return;
    }
    _cancelled = true;
  }

  Future<SelfTestResult> _run() async {
    // 1. Snapshot everything we are about to disturb.
    final wasErg = harness.isErgMode;
    final prevErgTarget = harness.ergTarget;
    final startGear = harness.currentGear;
    SelfTestVerdict? verdict;
    try {
      _record('start: vs=${harness.vsModeName} protocol=${harness.protocolName} gear=$startGear erg=$wasErg');
      _phase = SelfTestPhase.baseline;
      _emit();
      if (!await _precheck()) {
        _record('precheck: no power for ${noDataTimeout.inSeconds}s -> NO_DATA');
        verdict = SelfTestVerdict.noData;
      } else {
        final p0 = await _baseline();
        await _ergStaircase(p0);
        await _shiftSweep(startGear: startGear);
      }
    } on _AbortedException catch (e) {
      _record('aborted: ${e.reason}');
      verdict = SelfTestVerdict.aborted;
    } catch (e, s) {
      recordError(e, s, context: 'self-test run');
      _record('aborted: engine error ($e)');
      verdict = SelfTestVerdict.aborted;
    }
    return _finish(verdict: verdict, wasErg: wasErg, prevErgTarget: prevErgTarget, startGear: startGear);
  }

  // ----------------------------------------------------------------- phases
  /// 2. Precheck — a trainer that never reports power cannot be tested.
  Future<bool> _precheck() async {
    for (var i = 0; i < _ticksIn(noDataTimeout); i++) {
      await _tick();
      if (_power != null) {
        _record('precheck: power data present (${_power}W)');
        return true;
      }
    }
    return false;
  }

  /// 3. Baseline — hold cadence, then take the median power as `p0`.
  Future<int> _baseline() async {
    // Settle the cadence question first, while the pause watchdog is still
    // disarmed: some firmwares ship cadence disabled entirely, and waiting for
    // a reading that can never arrive used to hang the baseline until the
    // watchdog aborted the run — on exactly the trainers whose riders most
    // need a verdict.
    await _probeCadence();
    // The pause watchdog only arms here: a slow first sample during the
    // precheck must not count as coasting.
    _pauseArmed = true;
    if (_cadenceless) {
      _record('baseline: no cadence from this trainer, scoring on power alone');
    } else {
      _record('baseline: waiting for cadence >= $baselineCadenceMin rpm');
      var held = 0;
      while (held < _ticksIn(baselineHold)) {
        if (!await _tick()) {
          continue;
        }
        held = (_cadence ?? 0) >= baselineCadenceMin ? held + 1 : 0;
      }
    }
    var sampled = 0;
    final samples = <int>[];
    while (sampled < _ticksIn(baselineWindow)) {
      if (!await _tick()) {
        continue;
      }
      sampled++;
      final p = _power;
      if (p != null) {
        samples.add(p);
      }
    }
    final p0 = _median(samples);
    _record('baseline: p0=${p0}W from ${samples.length} samples');
    return p0;
  }

  /// Decides once whether this trainer reports cadence at all.
  ///
  /// [SelfTestHarness.cadenceRpm] only ever carries a value when a frame
  /// actually contained the field, so a probe window with nothing in it means
  /// the field is absent from the stream — not that the rider is stationary.
  Future<void> _probeCadence() async {
    for (var i = 0; i < _ticksIn(cadenceProbe) && !_cadenceSeen; i++) {
      await _tick();
    }
    _cadenceless = !_cadenceSeen;
    if (_cadenceless) {
      _emit();
    }
  }

  /// 4. ERG staircase — command targets and watch whether power follows.
  Future<void> _ergStaircase(int p0) async {
    try {
      if (!harness.supportsPowerTarget) {
        // Skipped, not failed: ergStepsTotal stays 0 and the verdict ignores
        // it. Inside the try on purpose — the finally below still has to take
        // the trainer out of ERG before the sweep measures anything.
        _record('erg: skipped, trainer has no power-target support');
        return;
      }
      // Only now, so a skipped phase doesn't flash "Testing power targets".
      _phase = SelfTestPhase.ergStaircase;
      _emit();
      _record('phase: erg staircase');
      final targets = [p0 + ergStepUpW, math.max(ergStepMinW, p0 - ergStepDownW), p0 + ergStepUpW];
      for (final target in targets) {
        _currentErgTarget = target;
        _emit();
        _record('erg: commanding ${target}W');
        _ergDirty = true;
        harness.setErgTarget(target);
        final passed = await _ergStep(target);
        _ergTotal++;
        _ergResults.add(passed);
        _record('erg: ${target}W ${passed ? 'reached' : 'no response'}');
        _emit();
      }
    } finally {
      // Always leave ERG here — whatever the rider's mode was before the test.
      // The sweep can only read resistance changes in SIM: manual ERG pins
      // power flat and would score every transition as "no change". A rider's
      // own ERG session is put back in _finish, once the sweep is done.
      _currentErgTarget = null;
      try {
        _exitErgForSweep();
      } catch (e, s) {
        // A refused write must not downgrade an otherwise scored run.
        recordError(e, s, context: 'self-test erg exit');
      }
      _emit();
    }
  }

  Future<bool> _ergStep(int target) async {
    final tolerance = math.max(ergBandFloorW.toDouble(), ergBandFraction * target);
    var elapsed = 0;
    var inBand = 0;
    while (elapsed < _ticksIn(stepDuration)) {
      if (!await _tick()) {
        continue;
      }
      elapsed++;
      final p = _power;
      if (p != null && (p - target).abs() <= tolerance) {
        inBand++;
        if (inBand >= ergInBandTicks) {
          return true;
        }
      } else {
        inBand = 0;
      }
    }
    return false;
  }

  /// 5. Shift sweep — three upshifts, each expected to harden the resistance.
  Future<void> _shiftSweep({required int startGear}) async {
    _phase = SelfTestPhase.shiftSweep;
    _emit();
    _record('phase: shift sweep');
    try {
      // Headroom: leave room for the upshifts before measuring anything.
      // Bounded twice over — a rider can configure maxGear down to 1 (the
      // target gear then sits below every reachable gear), and a trainer at its
      // lowest gear, or one refusing to shift at all, never moves.
      var headroomShifts = 0;
      while (harness.currentGear > harness.maxGear - headroomGears) {
        if (!await _tick()) {
          continue;
        }
        final before = harness.currentGear;
        _gearDirty = true;
        harness.shiftDown();
        headroomShifts++;
        if (harness.currentGear == before) {
          _record('shift: headroom stalled at gear $before');
          break;
        }
        _record('shift: headroom -> gear ${harness.currentGear}');
        if (headroomShifts >= maxHeadroomShifts) {
          _record('shift: headroom gave up at gear ${harness.currentGear}');
          break;
        }
      }
      var previous = await _plateau();
      _record(
        'shift: gear ${harness.currentGear} plateau ${_w(previous.power)}'
        '${_cadenceless ? '' : ' @ ${previous.cadence.round()}rpm'}',
      );
      for (var i = 0; i < shiftTransitions; i++) {
        _gearDirty = true;
        harness.shiftUp();
        var current = await _plateau();
        var passed = _transitionPassed(current, previous);
        if (!passed) {
          // One retry per plateau — re-measure, do not shift again.
          _record('shift: gear ${harness.currentGear} inconclusive, re-measuring');
          current = await _plateau();
          passed = _transitionPassed(current, previous);
        }
        _shiftTotal++;
        _shiftResults.add(passed);
        _record(
          'shift: gear ${harness.currentGear} ${_w(current.power)} vs ${_w(previous.power)} '
          '${passed ? 'harder' : 'no change'}',
        );
        _emit();
        previous = current;
      }
    } finally {
      try {
        await _restoreGear(startGear);
      } catch (e, s) {
        // Same rule as the staircase: a refused shift is logged, not fatal.
        recordError(e, s, context: 'self-test restore gear');
      }
    }
  }

  /// Mean power/cadence over one settled window.
  Future<_Plateau> _plateau() async {
    var elapsed = 0;
    final powers = <int>[];
    final cadences = <int>[];
    while (elapsed < _ticksIn(plateauWindow)) {
      if (!await _tick()) {
        continue;
      }
      elapsed++;
      final p = _power;
      if (p != null) {
        powers.add(p);
      }
      final c = _cadence;
      if (c != null) {
        cadences.add(c);
      }
    }
    return _Plateau(_mean(powers), _mean(cadences));
  }

  /// A transition counts only if power rose while the rider held cadence —
  /// otherwise a spin-up would read as resistance.
  ///
  /// A cadence-less trainer gives nothing to hold the rise against, so it is
  /// taken at face value: the rider was asked to pedal steadily, and the
  /// alternative is scoring every shift on such a trainer as a failure. The
  /// baseline log line records which of the two scorings ran.
  bool _transitionPassed(_Plateau current, _Plateau previous) {
    if (current.power <= previous.power) {
      return false;
    }
    if (_cadenceless) {
      return true;
    }
    if (previous.cadence <= 0) {
      return false;
    }
    final drift = (current.cadence - previous.cadence).abs() / previous.cadence;
    return drift <= cadenceDriftTolerance;
  }

  // ---------------------------------------------------------------- ticking
  /// Awaits one tick, refreshes the samples and updates pause bookkeeping.
  ///
  /// Returns false when the tick was swallowed by a pause — the caller must
  /// then not count it toward the current step's clock. Throws
  /// [_AbortedException] on cancel, on an upstream dropout, or when the pause
  /// outlives [pauseTimeout].
  Future<bool> _tick() async {
    _throwIfCancelled();
    await _sleep(tick);
    _throwIfCancelled();
    if (!harness.upstreamConnected) {
      // The power/cadence notifiers latch their last value on disconnect, so
      // without this the sweep would happily "measure" a dead link and report
      // NO_CONTROL for what is really a dropout.
      throw const _AbortedException('trainer disconnected');
    }
    _power = harness.powerW.value;
    _cadence = harness.cadenceRpm.value;
    if (_cadence != null) {
      _cadenceSeen = true;
    }
    if (!_pauseArmed) {
      return true;
    }
    final rpm = _cadence ?? 0;
    final watts = _power ?? 0;
    // Catching the rider stopping is what the watchdog is for, so on a
    // cadence-less trainer it reads power instead — that falls away just as
    // cadence would, and without it every remaining step would be scored as
    // "no response" for a rider who simply took a breather.
    final pedaling = _cadenceless ? watts > coastingPowerW : rpm >= baselineCadenceMin;
    final coasting = _cadenceless ? watts <= coastingPowerW : rpm < pauseCadenceBelow;
    if (_paused) {
      if (pedaling) {
        _paused = false;
        _pausedTicks = 0;
        _lowCadenceTicks = 0;
        _record(_cadenceless ? 'resumed: power back to ${watts}W' : 'resumed: cadence back to ${rpm}rpm');
        _emit();
        return true;
      }
      _pausedTicks++;
      if (_pausedTicks >= _ticksIn(pauseTimeout)) {
        throw _AbortedException('paused for ${pauseTimeout.inSeconds}s without pedaling');
      }
      return false;
    }
    if (coasting) {
      _lowCadenceTicks++;
      if (_lowCadenceTicks >= _ticksIn(pauseAfter)) {
        _paused = true;
        _pausedTicks = 0;
        _record(
          _cadenceless
              ? 'paused: power <= ${coastingPowerW}W for ${pauseAfter.inSeconds}s'
              : 'paused: cadence < $pauseCadenceBelow rpm for ${pauseAfter.inSeconds}s',
        );
        _emit();
        return false;
      }
    } else {
      _lowCadenceTicks = 0;
    }
    return true;
  }

  void _throwIfCancelled() {
    if (_cancelled) {
      throw const _AbortedException('cancelled by the rider');
    }
  }

  // ---------------------------------------------------------------- restore
  /// 8. Always runs — on pass, fail, cancel and exception alike.
  Future<SelfTestResult> _finish({
    required SelfTestVerdict? verdict,
    required bool wasErg,
    required int? prevErgTarget,
    required int startGear,
  }) async {
    // Separate guards: a gear restore that throws must not cost the rider
    // their ERG session, and neither may stop run() from resolving.
    try {
      await _restoreGear(startGear);
    } catch (e, s) {
      recordError(e, s, context: 'self-test restore gear');
    }
    try {
      _restoreErg(wasErg: wasErg, prevErgTarget: prevErgTarget);
    } catch (e, s) {
      recordError(e, s, context: 'self-test restore erg');
    }
    final result = _buildResult(verdict);
    try {
      _result = result;
      _phase = SelfTestPhase.done;
      _paused = false;
      _currentErgTarget = null;
      _emit();
      _record('verdict: ${result.toBundleString()}');
    } catch (e, s) {
      recordError(e, s, context: 'self-test finish');
    }
    return result;
  }

  SelfTestResult _buildResult(SelfTestVerdict? verdict) {
    var vsMode = 'unknown';
    var protocol = 'unknown';
    try {
      vsMode = harness.vsModeName;
      protocol = harness.protocolName;
    } catch (e, s) {
      // Labels are diagnostics only — never worth losing the verdict over.
      recordError(e, s, context: 'self-test result labels');
    }
    return SelfTestResult(
      at: _now(),
      verdict: verdict ?? _verdictFromSteps(),
      ergStepsPassed: _ergResults.where((passed) => passed).length,
      ergStepsTotal: _ergTotal,
      shiftStepsPassed: _shiftResults.where((passed) => passed).length,
      shiftStepsTotal: _shiftTotal,
      vsMode: vsMode,
      protocol: protocol,
      cadenceless: _cadenceless,
      // A copy: the run's own verdict line is recorded after this point, and
      // must not appear in the result the bundle reads.
      stepLog: List.of(_stepLog),
    );
  }

  /// Takes the trainer out of ERG before the sweep, whether the ERG session is
  /// one the staircase commanded or one the rider brought with them — a sweep
  /// measured under ERG reads flat and scores every transition as "no change".
  ///
  /// [_ergDirty] is deliberately left *set*: it now means "an ERG restore is
  /// owed", and [_restoreErg] settles it at the very end.
  void _exitErgForSweep() {
    if (!_ergDirty && !harness.isErgMode) {
      return;
    }
    _ergDirty = true;
    harness.exitErg();
    _record('erg: exited for the shift sweep');
  }

  /// Restores the ERG state captured at the start of [run] — a rider who was
  /// riding a manual ERG target gets that target back; everyone else is left
  /// out of ERG.
  ///
  /// Fires when we owe a restore *or* when the trainer's ERG state no longer
  /// matches the snapshot — shifting alone drops the definition out of ERG, so
  /// [_ergDirty] on its own would miss a session the sweep ended. A run that
  /// changed nothing (noData, early abort) still writes nothing at all.
  void _restoreErg({required bool wasErg, required int? prevErgTarget}) {
    final changed = _ergDirty || harness.isErgMode != wasErg || harness.ergTarget != prevErgTarget;
    if (!changed) {
      return;
    }
    if (wasErg && prevErgTarget != null) {
      harness.setErgTarget(prevErgTarget);
      _record('restore: erg target ${prevErgTarget}W');
    } else if (harness.isErgMode) {
      harness.exitErg();
      _record('restore: erg exited');
    }
    // Cleared only once the write went through, so a refused restore stays
    // visible to anything that looks after us.
    _ergDirty = false;
  }

  /// Shifts back to the starting gear, one shift per tick. Deliberately uses
  /// the raw sleeper: a cancel must not stop us from putting the gear back.
  Future<void> _restoreGear(int startGear) async {
    if (!_gearDirty || harness.currentGear == startGear) {
      _gearDirty = false;
      return;
    }
    var shifts = 0;
    while (harness.currentGear != startGear && shifts < maxRestoreShifts) {
      final before = harness.currentGear;
      if (before > startGear) {
        harness.shiftDown();
      } else {
        harness.shiftUp();
      }
      shifts++;
      if (harness.currentGear == before) {
        // Refused — burning 30 s of ticks on a trainer that won't move helps
        // nobody.
        break;
      }
      await _sleep(tick);
    }
    _gearDirty = false;
    if (harness.currentGear != startGear) {
      _record('restore: gear stuck at ${harness.currentGear}, wanted $startGear');
      return;
    }
    _record('restore: gear ${harness.currentGear}');
  }

  // ---------------------------------------------------------------- verdict
  /// 7. A skipped ERG phase (`ergStepsTotal == 0`) leaves the verdict to the
  /// shift sweep alone.
  SelfTestVerdict _verdictFromSteps() {
    final ergPassed = _ergResults.where((passed) => passed).length;
    final shiftPassed = _shiftResults.where((passed) => passed).length;
    final bool? ergPass = _ergTotal == 0 ? null : ergPassed >= stepsToPass;
    final shiftPass = shiftPassed >= stepsToPass;
    if ((ergPass ?? true) && shiftPass) {
      return SelfTestVerdict.pass;
    }
    if (ergPass == true && !shiftPass) {
      return SelfTestVerdict.ergOkVsFail;
    }
    // Shifting landed and only ERG didn't: the rider's virtual shifting is
    // working, so this is not "no control" and must not be reported as such.
    if (shiftPass) {
      return SelfTestVerdict.vsOkErgFail;
    }
    return SelfTestVerdict.noControl;
  }

  // ----------------------------------------------------------------- helpers
  /// Mirrors one diagnostic line into both the persisted step log and the
  /// harness (Activity / the app log). Every phase and step line goes through
  /// here so the two never drift apart.
  void _record(String message) {
    _stepLog.add(message);
    harness.log(message);
  }

  void _emit() {
    _state.value = SelfTestState(
      phase: _phase,
      pausedForCadence: _paused,
      cadenceless: _cadenceless,
      currentErgTarget: _currentErgTarget,
      ergStepResults: List.unmodifiable(_ergResults),
      shiftStepResults: List.unmodifiable(_shiftResults),
      result: _result,
    );
  }

  static Future<void> _realSleep(Duration d) => Future<void>.delayed(d);

  static int _ticksIn(Duration d) => (d.inMilliseconds / tick.inMilliseconds).ceil();

  static int _median(List<int> values) {
    if (values.isEmpty) {
      return 0;
    }
    final sorted = [...values]..sort();
    final middle = sorted.length ~/ 2;
    if (sorted.length.isOdd) {
      return sorted[middle];
    }
    return ((sorted[middle - 1] + sorted[middle]) / 2).round();
  }

  static double _mean(List<int> values) {
    if (values.isEmpty) {
      return 0;
    }
    return values.reduce((a, b) => a + b) / values.length;
  }

  static String _w(double value) => '${value.round()}W';
}

class _Plateau {
  const _Plateau(this.power, this.cadence);
  final double power;
  final double cadence;
}

class _AbortedException implements Exception {
  const _AbortedException(this.reason);
  final String reason;
  @override
  String toString() => 'SelfTestAborted: $reason';
}
