import 'package:bike_control/utils/keymap/apps/supported_app.dart';

import '../keymap.dart';

class OpenBikeControl extends SupportedApp {
  @override
  String? get officialUrl => 'https://openbikecontrol.org';

  @override
  List<(AppConnectionMethod, ConnectionSupport)> get connections => [
    (AppConnectionMethod.obpMdns, ConnectionSupport.supported),
    (AppConnectionMethod.obpBle, ConnectionSupport.supported),
  ];

  OpenBikeControl()
    : super(
        name: 'OpenBikeControl Compatible',
        packageName: "org.openbikecontrol",
        officialIntegration: false,
        keymap: Keymap(
          keyPairs: [],
        ),
      );
}
