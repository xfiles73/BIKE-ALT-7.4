import 'package:bike_control/widgets/ui/app_theme.dart';
import 'package:bike_control/widgets/ui/bk_page_header.dart';
import 'package:bike_control/bluetooth/devices/proxy/proxy_device.dart';
import 'package:bike_control/gen/l10n.dart';
import 'package:bike_control/main.dart';
import 'package:bike_control/models/shifting_config.dart';
import 'package:bike_control/pages/proxy_device_details/front_shift_card.dart';
import 'package:bike_control/pages/proxy_device_details/gear_hero_card.dart';
import 'package:bike_control/pages/proxy_device_details/gear_ratio_curve.dart';
import 'package:bike_control/pages/proxy_device_details/gear_ratio_presets.dart';
import 'package:bike_control/utils/core.dart';
import 'package:bike_control/widgets/ui/setting_tile.dart';
import 'package:bike_control/widgets/ui/stepper_control.dart';
import 'package:bike_control/widgets/ui/type_scale.dart';
import 'package:prop/emulators/definitions/fitness_bike_definition.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';

/// Keeps the gear-count mismatch warning ("MyWhoosh uses 30 gears …") off the
/// page. For the onboarding video, which shows the gear-count stepper without
/// the warning its intermediate counts would raise. Off everywhere else.
@visibleForTesting
bool debugHideGearCountMismatch = false;

class GearRatiosEditorPage extends StatefulWidget {
  final FitnessBikeDefinition definition;
  final ProxyDevice device;
  const GearRatiosEditorPage({super.key, required this.definition, required this.device});

  @override
  State<GearRatiosEditorPage> createState() => _GearRatiosEditorPageState();
}

class _GearRatiosEditorPageState extends State<GearRatiosEditorPage> {
  FitnessBikeDefinition get def => widget.definition;

  @override
  void initState() {
    super.initState();
    core.shiftingConfigs.addListener(_onConfigsChanged);
  }

  @override
  void dispose() {
    core.shiftingConfigs.removeListener(_onConfigsChanged);
    super.dispose();
  }

  void _onConfigsChanged() {
    if (mounted) setState(() {});
  }

  Future<void> _updateActive(ShiftingConfig Function(ShiftingConfig) mutate) async {
    final current = core.shiftingConfigs.activeFor(widget.device.trainerKey);
    await core.shiftingConfigs.upsert(mutate(current));
  }

  Future<void> _saveActiveGearRatios(List<double>? ratios) async {
    final current = core.shiftingConfigs.activeFor(widget.device.trainerKey);
    if (ratios == null) {
      await core.shiftingConfigs.upsert(current.copyWith(clearGearRatios: true));
    } else {
      await core.shiftingConfigs.upsert(current.copyWith(gearRatios: ratios));
    }
  }

  Future<void> _resetGearSettings() async {
    final app = core.settings.getTrainerApp();
    final targetMaxGear = app?.virtualGearAmount ?? ShiftingConfig.maxGearDefault;
    def.setMaxGear(targetMaxGear);
    def.setGradeSmoothingEnabled(true);
    def.resetGearRatios();
    await _updateActive(
      (c) => c.copyWith(
        maxGear: targetMaxGear,
        gradeSmoothing: true,
        clearGearRatios: true,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      headers: [
        BkPageHeader(
          title: AppLocalizations.of(context).gearSettings,
          actions: [
            Button(
              style: ButtonStyle.destructive(size: ButtonSize.small),
              onPressed: _resetGearSettings,
              leading: const Icon(LucideIcons.rotateCcw, size: 12),
              child: Text(
                AppLocalizations.of(context).reset,
                style: context.typography.caption.copyWith(fontWeight: FontWeight.w600),
              ),
            ),
          ],
        ),
      ],
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 800),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              spacing: 18,
              children: [
                _intro(context),
                if (!screenshotMode) ...[
                  GearHeroCard(definition: def, simOnly: true),
                  _vsModeCard(),
                  _gradeSmoothingCard(context),
                  _cadenceFilterCard(context),
                ],
                FrontShiftCard(device: widget.device, definition: def),
                _gearCountCard(context),
                _heroCurve(context),
                _presets(context),
                _perGearList(context),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _intro(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Text(
      AppLocalizations.of(context).tuneGearsIntro,
      style: context.typography.small.copyWith(color: cs.mutedForeground),
      softWrap: true,
    );
  }

  Widget _heroCurve(BuildContext context) => GearRatioCurve(definition: def);

  Widget _vsModeCard() => VirtualShiftingModeCard(definition: def, device: widget.device);

  Widget _gearCountCard(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final count = def.maxGear;
    final app = core.settings.getTrainerApp();
    final expected = app?.virtualGearAmount;
    final mismatch = app != null && expected != null && expected != count && !debugHideGearCountMismatch;
    return SettingTile(
      icon: LucideIcons.hash,
      title: AppLocalizations.of(context).gearCount,
      subtitle: AppLocalizations.of(context).gearCountDesc,
      trailing: StepperControl(
        value: count.toDouble(),
        step: 1.0,
        min: ShiftingConfig.maxGearMin.toDouble(),
        max: ShiftingConfig.maxGearMax.toDouble(),
        format: (v) => v.toStringAsFixed(0),
        onChanged: (v) async {
          final next = v.toInt();
          def.setMaxGear(next);
          await _updateActive((c) => c.copyWith(maxGear: next));
        },
      ),
      child: mismatch
          ? Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              decoration: BoxDecoration(
                color: BkStatusColors.of(context).warningWash,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: BkStatusColors.of(context).warning.withValues(alpha: 0.4)),
              ),
              child: Row(
                spacing: 8,
                children: [
                  Icon(LucideIcons.triangleAlert, size: 14, color: BkStatusColors.of(context).warning),
                  Expanded(
                    child: Text(
                      AppLocalizations.of(context).gearCountMismatch(app.name, expected, count),
                      style: context.typography.xSmall.copyWith(color: cs.foreground),
                    ),
                  ),
                  Button.ghost(
                    onPressed: () async {
                      def.setMaxGear(expected);
                      await _updateActive((c) => c.copyWith(maxGear: expected));
                    },
                    child: Text(AppLocalizations.of(context).useGearCount(expected), style: context.typography.xSmall),
                  ),
                ],
              ),
            )
          : null,
    );
  }

  Widget _gradeSmoothingCard(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: def.gradeSmoothingEnabled,
      builder: (context, enabled, _) => SettingTile(
        icon: LucideIcons.waves,
        title: AppLocalizations.of(context).gradeSmoothing,
        subtitle: AppLocalizations.of(context).gradeSmoothingDesc,
        trailing: Switch(
          value: enabled,
          onChanged: (v) async {
            def.setGradeSmoothingEnabled(v);
            await _updateActive((c) => c.copyWith(gradeSmoothing: v));
          },
        ),
      ),
    );
  }

  Widget _cadenceFilterCard(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: def.cadenceFilterEnabled,
      builder: (context, enabled, _) => SettingTile(
        icon: LucideIcons.filter,
        title: AppLocalizations.of(context).cadenceFilter,
        subtitle: AppLocalizations.of(context).cadenceFilterDesc,
        trailing: Switch(
          value: enabled,
          onChanged: (v) async {
            def.setCadenceFilterEnabled(v);
            await _updateActive((c) => c.copyWith(cadenceFilterEnabled: v));
          },
        ),
      ),
    );
  }

  // ---------- Presets ----------

  static bool _ratiosMatch(List<double> a, List<double> b, {double tol = 0.001}) {
    if (a.length != b.length) return false;
    for (var i = 0; i < a.length; i++) {
      if ((a[i] - b[i]).abs() > tol) return false;
    }
    return true;
  }

  Widget _presets(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      spacing: 8,
      children: [
        Text(
          AppLocalizations.of(context).presetsLabel,
          style: context.typography.caption.copyWith(
            fontWeight: FontWeight.w700,
            letterSpacing: 1,
            color: cs.mutedForeground,
          ),
        ),
        ValueListenableBuilder<List<double>>(
          valueListenable: def.gearRatios,
          builder: (context, current, _) {
            return Row(
              spacing: 8,
              children: gearRatioPresets(
                context,
                def.maxGear,
              ).map((p) => Expanded(child: _presetButton(context, p, current))).toList(),
            );
          },
        ),
      ],
    );
  }

  Widget _presetButton(BuildContext context, GearRatioPreset preset, List<double> current) {
    final cs = Theme.of(context).colorScheme;
    final active = _ratiosMatch(preset.values, current);
    return Button(
      style: active ? ButtonStyle.primary(size: ButtonSize.small) : ButtonStyle.outline(size: ButtonSize.small),
      onPressed: () async {
        // exactLength: a preset defines exactly its own gears; the editor's
        // rows and the gear-count card resync from the new curve length.
        def.setGearRatios(preset.values, exactLength: true);
        await _updateActive((c) => c.copyWith(maxGear: preset.values.length));
        await _saveActiveGearRatios(def.gearRatios.value);
      },
      // Four chips share a phone's width, and a preset name like "Compact" or
      // "Predeterminado" is wider than a quarter of it: the label is kept on
      // one line and shrunk to fit rather than broken mid-word.
      child: FittedBox(
        fit: BoxFit.scaleDown,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              preset.label,
              maxLines: 1,
              softWrap: false,
              style: context.typography.xSmall.copyWith(
                fontWeight: active ? FontWeight.w700 : FontWeight.w600,
              ),
            ),
            Text(
              preset.range,
              maxLines: 1,
              softWrap: false,
              style: context.typography.caption.copyWith(
                fontWeight: FontWeight.w500,
                color: active ? cs.primaryForeground.withValues(alpha: 0.8) : cs.mutedForeground,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ---------- Per-gear list ----------

  Widget _perGearList(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      spacing: 8,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              AppLocalizations.of(context).perGearLabel,
              style: context.typography.caption.copyWith(
                fontWeight: FontWeight.w700,
                letterSpacing: 1,
                color: cs.mutedForeground,
              ),
            ),
            // The rows below, counted — they follow the gear count.
            ValueListenableBuilder<List<double>>(
              valueListenable: def.gearRatios,
              builder: (context, ratios, _) => Text(
                AppLocalizations.of(context).perGearCount(ratios.length),
                style: context.typography.caption.copyWith(
                  fontWeight: FontWeight.w500,
                  color: Theme.of(context).colorScheme.mutedForeground,
                ),
              ),
            ),
          ],
        ),
        AnimatedBuilder(
          animation: Listenable.merge([def.gearRatios, def.currentGear]),
          builder: (context, _) {
            final ratios = def.gearRatios.value;
            final current = def.currentGear.value;
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              spacing: 6,
              // The store board only has to establish that every gear is
              // editable one by one; the rest of the 24 rows would just push
              // the cards above it off the phone.
              children: List<Widget>.generate(screenshotMode ? 3 : ratios.length, (i) {
                if (i >= ratios.length) return const SizedBox.shrink();
                final gear = i + 1;
                // Defensive: a stale/persisted curve shorter than the row
                // count must skip the row instead of throwing and blanking
                // the whole "per gear" section.
                if (gear - 1 >= ratios.length || gear > def.maxGear) {
                  return const SizedBox.shrink();
                }
                return _gearRow(context, gear, ratios[gear - 1], ratios, current);
              }),
            );
          },
        ),
      ],
    );
  }

  Widget _gearRow(
    BuildContext context,
    int gear,
    double ratio,
    List<double> ratios,
    int current,
  ) {
    final cs = Theme.of(context).colorScheme;
    final isCurrent = gear == current;
    final isNeutral = gear == def.neutralGear;

    final colors = gearRowColors(cs, isCurrent: isCurrent, isNeutral: isNeutral);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
      decoration: BoxDecoration(
        color: colors.background,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: colors.border, width: isCurrent ? 1.5 : 1),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        spacing: 12,
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: colors.badgeBackground,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Center(
              child: Text(
                '$gear',
                style: context.typography.small.copyWith(
                  fontWeight: FontWeight.w700,
                  color: colors.badgeForeground,
                ),
              ),
            ),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              spacing: 2,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  spacing: 6,
                  children: [
                    Text(
                      AppLocalizations.of(context).gearNumber(gear),
                      style: context.typography.small.copyWith(fontWeight: FontWeight.w600),
                    ),
                    if (isCurrent) _badge(AppLocalizations.of(context).currentBadge, cs.primary, cs.primaryForeground),
                    if (isNeutral && !isCurrent)
                      _badge(AppLocalizations.of(context).neutralBadge, colors.badgeBackground, colors.badgeForeground),
                  ],
                ),
                Text(
                  _hintFor(context, gear, ratio, ratios, def.neutralGear),
                  style: context.typography.caption.copyWith(color: cs.mutedForeground),
                ),
              ],
            ),
          ),
          // Stateful wrapper: the row list rebuilds on every curve change and
          // an uncontrolled TextField would lose both its text and the input
          // focus mid-edit. The controller is created once per gear slot and
          // kept in sync with the curve only while the field is NOT focused,
          // so typing never fights the notifier round-trip.
          _RatioField(
            key: ValueKey('ratio-field-$gear'),
            initialValue: ratio,
            onChanged: (v) async {
              def.setGearRatio(gear, v);
              await _saveActiveGearRatios(def.gearRatios.value);
            },
          ),
        ],
      ),
    );
  }

  Widget _badge(String text, Color bg, Color fg) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        text,
        style: context.typography.caption.copyWith(fontWeight: FontWeight.w700, color: fg),
      ),
    );
  }
}

/// One editable coefficient in the per-gear list.
///
/// Stateful on purpose: every curve change rebuilds the whole row list, and a
/// plain uncontrolled [TextField] would lose its text (and the keyboard) on
/// each rebuild — which is exactly why the old stepper-based rows felt dead
/// when tapped from a Windows touch/mouse build. The controller lives for as
/// long as the gear slot does; external updates only overwrite the field when
/// it is not focused, so typing never fights the notifier round-trip.
class _RatioField extends StatefulWidget {
  final double initialValue;
  final ValueChanged<double> onChanged;

  const _RatioField({super.key, required this.initialValue, required this.onChanged});

  static double clampRatio(double v) => v < 0.10 ? 0.10 : (v > 10.0 ? 10.0 : v);

  @override
  State<_RatioField> createState() => _RatioFieldState();
}

class _RatioFieldState extends State<_RatioField> {
  late final TextEditingController _controller = TextEditingController(
    text: widget.initialValue.toStringAsFixed(2),
  );

  @override
  void didUpdateWidget(covariant _RatioField oldWidget) {
    super.didUpdateWidget(oldWidget);
    // Sync an externally-changed value (preset tap, reset button, gear-count
    // resize). If the rider is mid-edit in this field their typed text wins
    // whenever it parses; only unparseable content snaps back to the curve.
    if (oldWidget.initialValue == widget.initialValue) return;
    final parsed = double.tryParse(_controller.text.replaceAll(',', '.'));
    if (parsed == null) {
      _controller.text = widget.initialValue.toStringAsFixed(2);
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _commit(String raw) {
    final v = double.tryParse(raw.replaceAll(',', '.'));
    if (v == null) {
      // Unparseable input: snap back to the last good value instead of
      // silently dropping the edit.
      _controller.text = widget.initialValue.toStringAsFixed(2);
      return;
    }
    final clamped = _RatioField.clampRatio(v);
    _controller.text = clamped.toStringAsFixed(2);
    if ((clamped - widget.initialValue).abs() >= 0.001) widget.onChanged(clamped);
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 84,
      child: TextField(
        controller: _controller,
        style: context.typography.small.copyWith(fontWeight: FontWeight.w700),
        onChanged: (raw) {
          // Live-commit while typing (the PC has no "Enter" habit); a valid
          // parse updates the curve + persistence immediately. Invalid text
          // is simply not committed — on blur it snaps back to the last good
          // value via didUpdateWidget/initialValue.
          final v = double.tryParse(raw.replaceAll(',', '.'));
          if (v == null) return;
          final clamped = _RatioField.clampRatio(v);
          if ((clamped - widget.initialValue).abs() >= 0.001) widget.onChanged(clamped);
        },
        onSubmitted: _commit,
      ),
    );
  }
}

String _hintFor(BuildContext context, int gear, double ratio, List<double> ratios, int neutralGear) {
  final l10n = AppLocalizations.of(context);
  if (gear == neutralGear) {
    return l10n.referenceBaseRatio;
  }
  // Defensive: the hint is secondary information — a curve that has not been
  // seeded to the expected length yet must never throw and blank the list.
  if (neutralGear < 1 || neutralGear > ratios.length) return '';
  final neutral = ratios[neutralGear - 1];
  final delta = ratio - neutral;
  if (delta.abs() < 0.05) return l10n.closeToNeutral;
  final mag = delta.abs().toStringAsFixed(2);
  if (delta > 0) return l10n.harderThanNeutral(mag);
  return l10n.easierThanNeutral(mag);
}

/// The Virtual Shifting mode selector (Target Power / Track Resistance / Basic),
/// extracted from [GearRatiosEditorPage] so it can be rendered standalone (e.g.
/// for a widget snapshot). It reads/writes the same [core.shiftingConfigs] and
/// the passed [definition], so behaviour inside the page is unchanged.
class VirtualShiftingModeCard extends StatelessWidget {
  final FitnessBikeDefinition definition;
  final ProxyDevice device;
  const VirtualShiftingModeCard({
    super.key,
    required this.definition,
    required this.device,
  });

  Future<void> _updateActive(ShiftingConfig Function(ShiftingConfig) mutate) async {
    final current = core.shiftingConfigs.activeFor(device.trainerKey);
    await core.shiftingConfigs.upsert(mutate(current));
  }

  // The three cards must stay the same height regardless of which one (if
  // any) shows the "Recommended" tag, and a translated label must never be
  // clipped instead of wrapping. A hard-coded height can't satisfy both at
  // once (translated labels like "Resistencia del recorrido" wrap to 2 lines
  // at phone widths, and a fixed height sized for English clips them against
  // RadioCard's ancestor Card, which paints with Clip.antiAlias). Callers
  // wrap the Row of cards in IntrinsicHeight with CrossAxisAlignment.stretch
  // instead (see build()), so every card is stretched to the tallest card's
  // own natural content height — never less than any card actually needs.
  Widget _vsRadioCard(
    BuildContext context,
    String label,
    VirtualShiftingMode value, {
    required bool recommended,
  }) {
    final supported = definition.supportsVirtualShiftingMode(value);
    return Expanded(
      child: RadioCard<VirtualShiftingMode>(
        value: value,
        enabled: supported,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              label,
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: context.typography.xSmall.copyWith(fontWeight: FontWeight.w600),
            ),
            if (recommended) ...[
              const Gap(2),
              Text(AppLocalizations.of(context).vsModeRecommended).xSmall.muted,
            ],
          ],
        ),
      ),
    );
  }

  /// The description for [mode], prefixed with a "not supported" notice when
  /// the connected trainer can't actually carry it (e.g. a saved preference
  /// that survived a reconnect onto a lesser trainer).
  String _descriptionFor(BuildContext context, VirtualShiftingMode mode) {
    final l10n = AppLocalizations.of(context);
    final desc = switch (mode) {
      VirtualShiftingMode.trackResistance => l10n.vsModeTrackResistanceDesc,
      VirtualShiftingMode.targetPower => l10n.vsModeTargetPowerDesc,
      VirtualShiftingMode.basicResistance => l10n.vsModeBasicDesc,
    };
    if (!definition.supportsVirtualShiftingMode(mode)) {
      return '${l10n.vsModeUnsupported}$desc';
    }
    return desc;
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge([definition.virtualShiftingMode, definition.trainerFeature]),
      builder: (context, _) {
        // The saved preference starts as null until the rider picks a mode;
        // render the effective (auto-picked) one so RadioGroup and the
        // description always receive a non-null VirtualShiftingMode.
        final mode = definition.effectiveVirtualShiftingMode;
        final defaultMode = definition.defaultVirtualShiftingMode;
        return SettingTile(
          title: AppLocalizations.of(context).virtualShiftingMode,
          subtitle: AppLocalizations.of(context).virtualShiftingModeDesc,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              RadioGroup<VirtualShiftingMode>(
                value: mode,
                onChanged: (v) async {
                  definition.setVirtualShiftingMode(v);
                  await _updateActive((c) => c.copyWith(mode: v));
                },
                // IntrinsicHeight + stretch: all three cards take the height
                // of whichever one actually needs the most room (a wrapped
                // 2-line label, the Recommended tag, or both) — never a
                // fixed guess that a translated label could outgrow.
                child: IntrinsicHeight(
                  child: Row(
                    spacing: 6,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _vsRadioCard(
                        context,
                        AppLocalizations.of(context).targetPowerMode,
                        VirtualShiftingMode.targetPower,
                        recommended: defaultMode == VirtualShiftingMode.targetPower,
                      ),
                      _vsRadioCard(
                        context,
                        AppLocalizations.of(context).trackResistanceMode,
                        VirtualShiftingMode.trackResistance,
                        recommended: defaultMode == VirtualShiftingMode.trackResistance,
                      ),
                      _vsRadioCard(
                        context,
                        AppLocalizations.of(context).basicMode,
                        VirtualShiftingMode.basicResistance,
                        recommended: defaultMode == VirtualShiftingMode.basicResistance,
                      ),
                    ],
                  ),
                ),
              ),
              const Gap(8),
              Text(_descriptionFor(context, mode)).xSmall.muted,
            ],
          ),
        );
      },
    );
  }
}

/// Colours for one row of the per-gear list, all derived from the theme so
/// the current row stays legible in dark mode (it used to be a fixed #EFF6FF
/// wash under near-white text).
@visibleForTesting
({Color background, Color border, Color badgeBackground, Color badgeForeground}) gearRowColors(
  ColorScheme cs, {
  required bool isCurrent,
  required bool isNeutral,
}) {
  if (isCurrent) {
    return (
      background: cs.primary.withValues(alpha: 0.10),
      border: cs.primary.withValues(alpha: 0.45),
      badgeBackground: cs.primary,
      badgeForeground: cs.primaryForeground,
    );
  }
  if (isNeutral) {
    return (
      background: cs.card,
      border: cs.border,
      badgeBackground: cs.primary.withValues(alpha: 0.15),
      badgeForeground: cs.foreground,
    );
  }
  return (background: cs.card, border: cs.border, badgeBackground: cs.muted, badgeForeground: cs.foreground);
}
