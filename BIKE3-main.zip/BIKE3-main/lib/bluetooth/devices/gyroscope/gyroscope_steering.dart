import 'dart:async';
import 'dart:math';

import 'package:bike_control/bluetooth/devices/base_device.dart';
import 'package:bike_control/bluetooth/devices/gyroscope/steering_estimator.dart';
import 'package:bike_control/bluetooth/devices/steering_device.dart';
import 'package:bike_control/bluetooth/messages/notification.dart';
import 'package:bike_control/gen/l10n.dart';
import 'package:bike_control/utils/core.dart';
import 'package:bike_control/utils/keymap/buttons.dart';
import 'package:bike_control/widgets/controller/controller_layout.dart';
import 'package:bike_control/widgets/ui/device_info.dart';
import 'package:bike_control/widgets/ui/small_progress_indicator.dart';
import 'package:flutter/foundation.dart';
import 'package:sensors_plus/sensors_plus.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';

/// Gyroscope and Accelerometer based steering device
/// Detects handlebar movement when the phone is mounted on the handlebar
class GyroscopeSteering extends BaseDevice implements SteeringDevice {
  GyroscopeSteering()
    : super(
        'Phone Steering',
        availableButtons: GyroscopeSteeringButtons.values,
        isBeta: true,
        uniqueId: 'gyroscope_steering_device',
        buttonPrefix: 'gyro',
        icon: LucideIcons.phone,
      );

  @override
  ControllerLayout get controllerLayout => ControllerLayout(
    aspectRatio: 0.5,
    shape: ContourShape.phone,
    positions: {
      GyroscopeSteeringButtons.leftSteer: const Offset(0.25, 0.5),
      GyroscopeSteeringButtons.rightSteer: const Offset(0.75, 0.5),
    },
  );

  StreamSubscription<GyroscopeEvent>? _gyroscopeSubscription;
  StreamSubscription<AccelerometerEvent>? _accelerometerSubscription;
  StreamSubscription<MagnetometerEvent>? _magnetometerSubscription;

  // Calibration state
  final SteeringEstimator _estimator = SteeringEstimator();
  bool _isCalibrated = false;
  ControllerButton? _lastSteeringButton;

  /// Live signed steering angle (degrees) for the UI gauge. Positive ⇒ steer
  /// LEFT, negative ⇒ steer RIGHT (see [_applyPWMSteering]).
  final ValueNotifier<double> steeringAngle = ValueNotifier(0.0);

  /// Mirrors [_isCalibrated] for the UI gauge.
  final ValueNotifier<bool> isCalibratedNotifier = ValueNotifier(false);

  // SteeringDevice interface
  @override
  ValueListenable<bool> get steeringCalibrated => isCalibratedNotifier;
  @override
  double get steeringThreshold => core.settings.getPhoneSteeringThreshold();
  @override
  ControllerButton get steerLeftButton => GyroscopeSteeringButtons.leftSteer;
  @override
  ControllerButton get steerRightButton => GyroscopeSteeringButtons.rightSteer;

  // Accelerometer raw data
  bool _hasAccelData = false;

  // Time tracking for integration
  DateTime? _lastGyroUpdate;

  /// The clock the gyroscope integration measures time between samples by.
  /// Tests that feed samples on a fake clock point it there.
  @visibleForTesting
  DateTime Function() nowFn = DateTime.now;

  // Last rounded angle for change detection
  int? _lastRoundedAngle;

  // Debounce timer for PWM-like keypress behavior
  Timer? _keypressTimer;

  // Magnetometer mode
  bool _useMagnetometer = false;
  double? _magnetometerCalibrationHeading;
  double _currentMagnetometerAngle = 0.0;
  final List<double> _magnetometerCalibrationSamples = [];

  // Magnetometer filtering state
  double? _filteredMagX;
  double? _filteredMagY;
  static const double _magnetometerFilterAlpha = 0.15; // Lower = more smoothing

  // Configuration (can be made customizable later)
  static const double STEERING_THRESHOLD = 5.0; // degrees
  static const double LEVEL_DEGREE_STEP = 10.0; // degrees per level
  static const int MAX_LEVELS = 5;
  static const int KEY_REPEAT_INTERVAL_MS = 40;
  static const double COMPLEMENTARY_FILTER_ALPHA = 0.98; // Weight for gyroscope
  static const double LOW_PASS_FILTER_ALPHA = 0.9; // Smoothing factor

  /// Start listening to the appropriate sensors based on the current mode
  Future<void> _startSensorStreams() async {
    // Cancel all existing subscriptions first
    await _gyroscopeSubscription?.cancel();
    await _accelerometerSubscription?.cancel();
    await _magnetometerSubscription?.cancel();
    _gyroscopeSubscription = null;
    _accelerometerSubscription = null;
    _magnetometerSubscription = null;

    if (_useMagnetometer) {
      // Magnetometer mode: only listen to magnetometer
      _magnetometerSubscription = magnetometerEventStream().listen(
        _handleMagnetometerEvent,
        onError: (error) {
          actionStreamInternal.add(LogNotification('Magnetometer error: $error'));
        },
      );
      actionStreamInternal.add(LogNotification('Started magnetometer stream'));
    } else {
      // Gyroscope mode: listen to gyroscope and accelerometer
      _gyroscopeSubscription = gyroscopeEventStream().listen(
        _handleGyroscopeEvent,
        onError: (error) {
          actionStreamInternal.add(LogNotification('Gyroscope error: $error'));
        },
      );

      _accelerometerSubscription = accelerometerEventStream().listen(
        _handleAccelerometerEvent,
        onError: (error) {
          actionStreamInternal.add(LogNotification('Accelerometer error: $error'));
        },
      );
      actionStreamInternal.add(LogNotification('Started gyroscope and accelerometer streams'));
    }
  }

  @override
  Future<void> connect() async {
    if (isConnected) {
      return;
    }

    try {
      // Start listening to sensors based on current mode
      await _startSensorStreams();

      isConnected = true;
      actionStreamInternal.add(LogNotification('Gyroscope Steering: Connected - Calibrating...'));

      // Reset calibration/estimator
      _setCalibrated(false);
      _hasAccelData = false;
      _estimator.reset();
      _lastGyroUpdate = null;
      _lastRoundedAngle = null;
      _lastSteeringButton = null;
    } catch (e) {
      actionStreamInternal.add(LogNotification('Failed to connect Gyroscope Steering: $e'));
      isConnected = false;
      rethrow;
    }
  }

  void _handleGyroscopeEvent(GyroscopeEvent event) {
    final now = nowFn();

    if (!_hasAccelData) {
      _lastGyroUpdate = now;
      return;
    }

    final dt = _lastGyroUpdate != null ? (now.difference(_lastGyroUpdate!).inMicroseconds / 1000000.0) : 0.0;
    _lastGyroUpdate = now;

    if (dt <= 0 || dt >= 1.0) {
      return;
    }

    // iOS drift fix:
    // - integrate bias-corrected gyro z (yaw) into an estimator
    // - learn bias while the device is still
    final angleDeg = _estimator.updateGyro(wz: event.z, dt: dt);

    if (!_isCalibrated) {
      // Consider calibration complete once we have a bit of stillness and sensor data.
      // This gives the bias estimator time to settle.
      if (_estimator.stillTimeSec >= 0.6) {
        _estimator.calibrate(seedBiasZRadPerSec: _estimator.biasZRadPerSec);
        _setCalibrated(true);
        /*actionStreamInternal.add(
          AlertNotification(LogLevel.LOGLEVEL_INFO, 'Calibration complete.'),
        );*/
      }
      return;
    }

    _processSteeringAngle(angleDeg);
  }

  void _handleAccelerometerEvent(AccelerometerEvent event) {
    _hasAccelData = true;
    _estimator.updateAccel(x: event.x, y: event.y, z: event.z);
  }

  void _handleMagnetometerEvent(MagnetometerEvent event) {
    // Magnetometer mode: calculate heading from X and Y components
    // This is more stable than using a single axis

    // Apply low-pass filter to reduce noise
    if (_filteredMagX == null || _filteredMagY == null) {
      // Initialize on first reading
      _filteredMagX = event.x;
      _filteredMagY = event.y;
    } else {
      // Exponential moving average (low-pass filter)
      _filteredMagX = _magnetometerFilterAlpha * event.x + (1 - _magnetometerFilterAlpha) * _filteredMagX!;
      _filteredMagY = _magnetometerFilterAlpha * event.y + (1 - _magnetometerFilterAlpha) * _filteredMagY!;
    }

    // Calculate heading from filtered X and Y components
    // atan2(y, x) gives the angle in radians, convert to degrees
    double heading = atan2(_filteredMagY!, _filteredMagX!) * (180 / pi);

    // Normalize heading to 0-360 range
    if (heading < 0) heading += 360;

    if (kDebugMode) {
      print(
        'Magnetometer - X: ${event.x.toStringAsFixed(2)}, Y: ${event.y.toStringAsFixed(2)}, '
        'Filtered X: ${_filteredMagX!.toStringAsFixed(2)}, Filtered Y: ${_filteredMagY!.toStringAsFixed(2)}, '
        'Heading: ${heading.toStringAsFixed(2)}°',
      );
    }

    // During calibration, collect heading samples
    if (!_isCalibrated) {
      _magnetometerCalibrationSamples.add(heading);

      // After 30 samples (~1 second at typical rates), calculate calibration heading
      if (_magnetometerCalibrationSamples.length >= 30) {
        // For heading, we need to handle the circular nature (0° and 360° are the same)
        // Use circular mean calculation
        double sumSin = 0, sumCos = 0;
        for (var h in _magnetometerCalibrationSamples) {
          final radians = h * (pi / 180);
          sumSin += sin(radians);
          sumCos += cos(radians);
        }
        final avgSin = sumSin / _magnetometerCalibrationSamples.length;
        final avgCos = sumCos / _magnetometerCalibrationSamples.length;
        _magnetometerCalibrationHeading = atan2(avgSin, avgCos) * (180 / pi);
        if (_magnetometerCalibrationHeading! < 0)
          _magnetometerCalibrationHeading = _magnetometerCalibrationHeading! + 360;

        _magnetometerCalibrationSamples.clear();
        _setCalibrated(true);
        actionStreamInternal.add(
          LogNotification(
            'Magnetometer calibration complete. Reference heading: ${_magnetometerCalibrationHeading!.toStringAsFixed(2)}°',
          ),
        );
      }
      return;
    }

    // Calculate steering angle relative to calibrated heading
    // This is the angular difference, accounting for wrap-around
    double angleDeg = heading - _magnetometerCalibrationHeading!;

    // Normalize to -180 to +180 range
    if (angleDeg > 180) {
      angleDeg -= 360;
    } else if (angleDeg < -180) {
      angleDeg += 360;
    }

    _currentMagnetometerAngle = angleDeg;

    _processSteeringAngle(angleDeg);
  }

  void _processSteeringAngle(double steeringAngleDeg) {
    steeringAngle.value = steeringAngleDeg;
    final roundedAngle = steeringAngleDeg.round();

    if (_lastRoundedAngle != roundedAngle) {
      if (kDebugMode) {
        actionStreamInternal.add(
          LogNotification(
            'Steering angle: $roundedAngle° (biasZ=${_estimator.biasZRadPerSec.toStringAsFixed(4)} rad/s)',
          ),
        );
      }
      _lastRoundedAngle = roundedAngle;
      _applyPWMSteering(roundedAngle);
    }
  }

  /// Applies PWM-like steering behavior with repeated keypresses proportional to angle magnitude
  void _applyPWMSteering(int roundedAngle) {
    // Cancel any pending keypress timer
    _keypressTimer?.cancel();

    // Determine if we're steering
    if (roundedAngle.abs() > core.settings.getPhoneSteeringThreshold()) {
      // Determine direction
      final button = roundedAngle < 0 ? GyroscopeSteeringButtons.rightSteer : GyroscopeSteeringButtons.leftSteer;

      if (_lastSteeringButton != button) {
        // New steering direction - reset any previous state
        _lastSteeringButton = button;
      } else {
        return;
      }

      handleButtonsClicked([button]);
    } else {
      _lastSteeringButton = null;
      // Center position - release any held buttons
      handleButtonsClicked([]);
    }
  }

  @override
  Future<void> disconnect() async {
    await _gyroscopeSubscription?.cancel();
    await _accelerometerSubscription?.cancel();
    await _magnetometerSubscription?.cancel();
    _gyroscopeSubscription = null;
    _accelerometerSubscription = null;
    _magnetometerSubscription = null;
    _keypressTimer?.cancel();
    isConnected = false;
    _setCalibrated(false);
    steeringAngle.value = 0.0;
    _hasAccelData = false;
    _estimator.reset();
    _magnetometerCalibrationHeading = null;
    _magnetometerCalibrationSamples.clear();
    _currentMagnetometerAngle = 0.0;
    _filteredMagX = null;
    _filteredMagY = null;
    actionStreamInternal.add(LogNotification('Gyroscope Steering: Disconnected'));
  }

  @override
  List<Widget> showMetaInformation(BuildContext context, {required bool showFull}) {
    return [
      Text(_isCalibrated ? 'Calibrated' : 'Calibrating...').xSmall.muted,
      Text(
        'Steering Angle: ${_isCalibrated ? '${(_useMagnetometer ? _currentMagnetometerAngle : _estimator.angleDeg).toStringAsFixed(2)}°' : 'Calibrating...'}',
      ).xSmall.muted,
    ];
  }

  void _setCalibrated(bool value) {
    _isCalibrated = value;
    isCalibratedNotifier.value = value;
  }

  /// Reset calibration so the sensors re-learn their neutral reference. Safe to
  /// call any time (also used by the assignable Calibrate action).
  void recalibrate() {
    _setCalibrated(false);
    if (_useMagnetometer) {
      _magnetometerCalibrationHeading = null;
      _magnetometerCalibrationSamples.clear();
      _currentMagnetometerAngle = 0.0;
      _filteredMagX = null;
      _filteredMagY = null;
    } else {
      _hasAccelData = false;
      _estimator.reset();
      _lastGyroUpdate = null;
    }
    _lastRoundedAngle = null;
    _lastSteeringButton = null;
    steeringAngle.value = 0.0;
  }

  @override
  Widget? buildPreferences(BuildContext context) {
    return StatefulBuilder(
      builder: (c, setState) => Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        spacing: 12,
        children: [
          // Magnetometer mode toggle
          Checkbox(
            trailing: Expanded(child: Text(AppLocalizations.of(context).useMagnetometerMode)),
            state: _useMagnetometer ? CheckboxState.checked : CheckboxState.unchecked,
            onChanged: (value) async {
              setState(() {
                _useMagnetometer = value == CheckboxState.checked;
                // Reset calibration when switching modes
                recalibrate();
              });

              // Restart sensor streams if device is connected
              if (isConnected) {
                await _startSensorStreams();
                actionStreamInternal.add(
                  LogNotification(
                    'Switched to ${_useMagnetometer ? "magnetometer" : "gyroscope + accelerometer"} mode',
                  ),
                );
              }
            },
          ),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              DeviceInfo(
                title: AppLocalizations.of(context).steeringCalibration,
                icon: LucideIcons.wrench,
                value: _isCalibrated
                    ? AppLocalizations.of(context).calibrationComplete
                    : AppLocalizations.of(context).calibrationInProgress,
              ),
              DeviceInfo(
                title: AppLocalizations.of(context).steeringAngle,
                icon: LucideIcons.moveHorizontal,
                value: _isCalibrated
                    ? '${(_useMagnetometer ? _currentMagnetometerAngle : _estimator.angleDeg).toStringAsFixed(2)}°'
                    : AppLocalizations.of(context).steeringCalibrating,
              ),
              if (kDebugMode && !_useMagnetometer)
                DeviceInfo(
                  title: 'Gyro Bias',
                  icon: LucideIcons.gauge,
                  value: '${_estimator.biasZRadPerSec.toStringAsFixed(4)} rad/s',
                ),
              if (kDebugMode && _useMagnetometer && _magnetometerCalibrationHeading != null)
                DeviceInfo(
                  title: 'Mag Heading',
                  icon: LucideIcons.compass,
                  value: '${_magnetometerCalibrationHeading!.toStringAsFixed(2)}°',
                ),
            ],
          ),
          Row(
            spacing: 8,
            children: [
              PrimaryButton(
                size: ButtonSize.small,
                leading: !_isCalibrated ? SmallProgressIndicator() : null,
                onPressed: !_isCalibrated
                    ? null
                    : () {
                        recalibrate();
                        // setState needed until the button wires to isCalibratedNotifier.
                        setState(() {});
                      },
                child: Text(
                  _isCalibrated
                      ? AppLocalizations.of(context).calibrate
                      : AppLocalizations.of(context).steeringCalibrating,
                ),
              ),
              Builder(
                builder: (context) {
                  return PrimaryButton(
                    size: ButtonSize.small,
                    trailing: Container(
                      padding: EdgeInsets.symmetric(horizontal: 4),
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.destructive,
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text('${core.settings.getPhoneSteeringThreshold().toInt()}°'),
                    ),
                    onPressed: () {
                      final values = [for (var i = 3; i <= 12; i += 1) i];
                      showDropdown(
                        context: context,
                        builder: (b) => DropdownMenu(
                          children: values
                              .map(
                                (v) => MenuButton(
                                  child: Text('$v°'),
                                  onPressed: (c) {
                                    core.settings.setPhoneSteeringThreshold(v);
                                    setState(() {});
                                  },
                                ),
                              )
                              .toList(),
                        ),
                      );
                    },
                    child: Text(AppLocalizations.of(context).triggerThreshold),
                  );
                },
              ),
            ],
          ),
          if (!_isCalibrated)
            Text(
              _useMagnetometer
                  ? AppLocalizations.of(context).calibratingMagnetometerHint
                  : AppLocalizations.of(context).calibratingSensorsHint,
            ).xSmall,
        ],
      ),
    );
  }
}

class GyroscopeSteeringButtons {
  static final ControllerButton leftSteer = ControllerButton(
    'gyroLeftSteer',
    action: InGameAction.steerLeft,
  );
  static final ControllerButton rightSteer = ControllerButton(
    'gyroRightSteer',
    action: InGameAction.steerRight,
  );

  static List<ControllerButton> get values => [
    leftSteer,
    rightSteer,
  ];
}
