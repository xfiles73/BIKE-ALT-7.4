import 'package:bike_control/bluetooth/devices/base_device.dart';
import 'package:bike_control/bluetooth/devices/zwift/constants.dart';
import 'package:bike_control/bluetooth/devices/zwift/firmware_support.dart';
import 'package:bike_control/bluetooth/devices/zwift/zwift_device.dart';
import 'package:bike_control/bluetooth/devices/zwift/zwift_unlock.dart';
import 'package:bike_control/bluetooth/messages/notification.dart';
import 'package:bike_control/utils/core.dart';
import 'package:bike_control/main.dart' show screenshotMode;
import 'package:bike_control/utils/keymap/buttons.dart';
import 'package:bike_control/widgets/controller/controller_layout.dart';
import 'package:bike_control/widgets/zwift_ride_v2_unlock.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:prop/prop.dart';
import 'package:protobuf/protobuf.dart' as $pb;
import 'package:universal_ble/universal_ble.dart';
import 'package:version/version.dart';

class ZwiftRide extends ZwiftDevice with ZwiftUnlock {
  /// Minimum absolute analog value (0-100) required to trigger paddle button press.
  /// Values below this threshold are ignored to prevent accidental triggers from
  /// analog drift or light touches.
  static const int analogPaddleThreshold = 25;

  @override
  DateTime? initializationTime;

  ZwiftRide(super.scanResult, {super.isBeta, List<ControllerButton>? availableButtons})
    : super(
        availableButtons:
            availableButtons ??
            [
              ZwiftButtons.navigationLeft,
              ZwiftButtons.navigationRight,
              ZwiftButtons.navigationUp,
              ZwiftButtons.navigationDown,
              ZwiftButtons.a,
              ZwiftButtons.b,
              ZwiftButtons.y,
              ZwiftButtons.z,
              ZwiftButtons.shiftUpLeft,
              ZwiftButtons.shiftDownLeft,
              ZwiftButtons.shiftUpRight,
              ZwiftButtons.shiftDownRight,
              ZwiftButtons.powerUpLeft,
              ZwiftButtons.powerUpRight,
              ZwiftButtons.onOffLeft,
              ZwiftButtons.onOffRight,
              ZwiftButtons.paddleLeft,
              ZwiftButtons.paddleRight,
            ],
      );

  @override
  String? get latestFirmwareVersion => '1.2.0';

  /// The Ride's two hoods, as the home card and device page draw them. Also
  /// the Ride V2 explainer's hero, so both show the same controller.
  static const contourAsset = 'assets/contours/zwift_play_both.svg';

  /// The first firmware of the Zwift Ride V2.
  static final Version rideV2Firmware = Version(1, 3, 0);

  /// Display name once a Ride is known to be a V2.
  static const rideV2Label = 'Zwift Ride V2';

  /// Whether this is a Zwift Ride V2: an actual Zwift Ride (not a subclass
  /// such as the Click V2 or a Play on firmware 2) reporting firmware 1.3 or
  /// newer. Only known once connected and the firmware has been read; unknown
  /// or unparseable firmware counts as a V1. Derived afresh every time, so a
  /// Ride that later reports 1.2.x is a V1 again.
  @override
  bool get isRideV2 {
    if (runtimeType != ZwiftRide) return false;
    final firmware = parseLenientFirmwareVersion(firmwareVersion);
    return firmware != null && firmware >= rideV2Firmware;
  }

  /// A Zwift Ride V2 is unlocked with Zwift, like a Click V2.
  @override
  bool get usesZwiftUnlock => isRideV2;

  @override
  String get unlockKeyPrefix => 'rideV2';

  @override
  String get unlockHelpUrl => zwiftRideV2HelpUrl;

  /// True only for an actual Zwift Ride (not subclasses such as Click v2 or
  /// Play fw2) whose firmware is past [latestFirmwareVersion] without being a
  /// Zwift Ride V2 — which has its own unlock flow. The fallback notice.
  static bool hasUnsupportedFirmware(BaseDevice device) =>
      device.runtimeType == ZwiftRide && (device as ZwiftRide).hasFirmwareBeyondSupported && !device.isRideV2;

  @override
  String toString() => isRideV2 ? rideV2Label : super.toString();

  /// A locked Ride V2 hides its Zwift service. That is its normal state until
  /// it has been unlocked in Zwift, so tell the rider how to unlock it instead
  /// of failing the connect.
  @override
  bool handleHiddenUnlockService() {
    if (!isRideV2) return false;
    actionStreamInternal.add(
      LogNotification('$this is locked: its Zwift service is hidden until it is unlocked in Zwift.'),
    );
    showZwiftRideV2LockedToast(this);
    return true;
  }

  @override
  List<Widget> showAdditionalInformation(BuildContext context) {
    if (!requiresZwiftUnlock || screenshotMode) return super.showAdditionalInformation(context);
    return [ZwiftRideV2UnlockSection(device: this)];
  }

  @override
  bool get canVibrate => true;

  @override
  ControllerLayout get controllerLayout => ControllerLayout(
    aspectRatio: 575 / 288,
    // SVG depicts both Plays side-by-side; shape kept as dropBar only as a
    // sizing-bucket hint for [ControllerCanvas] (the painter is not used).
    shape: ContourShape.steeringPad,
    svgAsset: contourAsset,
    positions: {
      // LEFT half — ZwiftPlay LEFT positions with x scaled by 0.5 so they
      // land inside the left controller silhouette in the both-svg.
      ZwiftButtons.navigationUp: const Offset(0.345, 0.24),
      ZwiftButtons.navigationLeft: const Offset(0.25, 0.40),
      ZwiftButtons.navigationRight: const Offset(0.44, 0.40),
      ZwiftButtons.navigationDown: const Offset(0.345, 0.56),
      ZwiftButtons.onOffLeft: const Offset(0.345, 0.76),
      ZwiftButtons.paddleLeft: const Offset(0.13, 0.1),
      // Ride-only extras laid out down the left drop column.
      ZwiftButtons.shiftUpLeft: const Offset(0.03, 0.32),
      ZwiftButtons.shiftDownLeft: const Offset(0.03, 0.55),
      ZwiftButtons.powerUpLeft: const Offset(0.07, 0.88),
      // RIGHT half — ZwiftPlay RIGHT positions with x mapped via x→x·0.5+0.5.
      ZwiftButtons.y: const Offset(0.67, 0.24),
      ZwiftButtons.z: const Offset(0.58, 0.40),
      ZwiftButtons.a: const Offset(0.77, 0.40),
      ZwiftButtons.b: const Offset(0.67, 0.56),
      ZwiftButtons.onOffRight: const Offset(0.67, 0.76),
      ZwiftButtons.paddleRight: const Offset(0.89, 0.1),
      // Ride-only extras laid out down the right drop column.
      ZwiftButtons.shiftUpRight: const Offset(0.97, 0.32),
      ZwiftButtons.shiftDownRight: const Offset(0.97, 0.55),
      ZwiftButtons.powerUpRight: const Offset(0.93, 0.88),
      // Play Firmware 2
      ZwiftButtons.sideButtonLeft: const Offset(0.04, 0.26),
      ZwiftButtons.sideButtonRight: const Offset(0.98, 0.26),
    },
  );

  @override
  Future<void> processData(Uint8List bytes) async {
    Opcode? opcode = Opcode.valueOf(bytes[0]);
    Uint8List message = bytes.sublist(1);

    if (kDebugMode) {
      print(
        '${DateTime.now().toString().split(" ").last} Received $opcode: ${bytes.map((e) => e.toRadixString(16).padLeft(2, '0')).join(' ')}',
      );
    }

    switch (opcode) {
      case Opcode.RIDE_ON:
        initializationTime = DateTime.now();

        break;
      case Opcode.STATUS_RESPONSE:
        final status = StatusResponse.fromBuffer(message);
        if (kDebugMode) {
          print('StatusResponse: ${status.command} status: ${Status.valueOf(status.status)}');
        }
        break;
      case Opcode.GET_RESPONSE:
        final response = GetResponse.fromBuffer(message);
        final dataObjectType = DO.valueOf(response.dataObjectId);
        if (kDebugMode) {
          print(
            'GetResponse: ${dataObjectType?.value.toRadixString(16).padLeft(4, '0') ?? response.dataObjectId} $dataObjectType',
          );
        }

        switch (dataObjectType) {
          case DO.PAGE_DEV_INFO:
            final pageDevInfo = DevInfoPage.fromBuffer(response.dataObjectData);
            if (kDebugMode) {
              print('PageDevInfo: $pageDevInfo');
            }
            break;
          case DO.PAGE_DATE_TIME:
            final pageDateTime = DateTimePage.fromBuffer(response.dataObjectData);
            if (kDebugMode) {
              print('PageDateTime: $pageDateTime');
            }
            break;
          case DO.PAGE_CONTROLLER_INPUT_CONFIG:
            final pageDateTime = ControllerInputConfigPage.fromBuffer(response.dataObjectData);
            if (kDebugMode) {
              print('PageDateTime: $pageDateTime');
            }
            break;
          case null:
            break;
          default:
            break;
        }
        break;
      case Opcode.VENDOR_MESSAGE:
        break;
      case Opcode.LOG_DATA:
        final logMessage = LogDataNotification.fromBuffer(message);
        if (kDebugMode) {
          actionStreamInternal.add(LogNotification(logMessage.toString()));
        }
        break;
      case Opcode.BATTERY_NOTIF:
        final notification = BatteryNotification.fromBuffer(message);
        if (batteryLevel != notification.newPercLevel) {
          batteryLevel = notification.newPercLevel;
          core.connection.signalChange(this);
        }
        break;
      case Opcode.CONTROLLER_NOTIFICATION:
        try {
          final buttonsClicked = processClickNotification(message);
          handleButtonsClicked(buttonsClicked);
        } catch (e) {
          actionStreamInternal.add(LogNotification(e.toString()));
        }
        break;
      case null:
        if (bytes[0] == 0x1A) {
          final batteryStatus = BatteryStatus.fromBuffer(message);
          if (kDebugMode) {
            print('BatteryStatus: $batteryStatus');
          }
        }
        break;
    }
  }

  @override
  List<ControllerButton> processClickNotification(Uint8List message) {
    final status = RideKeyPadStatus.fromBuffer(message);

    // Debug: Log all button mask detections (moved to ZwiftRide.processClickNotification)

    // Process DIGITAL buttons separately
    final buttonsClicked = [
      if (status.buttonMap & RideButtonMask.LEFT_BTN.mask == PlayButtonStatus.ON.value) ZwiftButtons.navigationLeft,
      if (status.buttonMap & RideButtonMask.RIGHT_BTN.mask == PlayButtonStatus.ON.value) ZwiftButtons.navigationRight,
      if (status.buttonMap & RideButtonMask.UP_BTN.mask == PlayButtonStatus.ON.value) ZwiftButtons.navigationUp,
      if (status.buttonMap & RideButtonMask.DOWN_BTN.mask == PlayButtonStatus.ON.value) ZwiftButtons.navigationDown,
      if (status.buttonMap & RideButtonMask.A_BTN.mask == PlayButtonStatus.ON.value) ZwiftButtons.a,
      if (status.buttonMap & RideButtonMask.B_BTN.mask == PlayButtonStatus.ON.value) ZwiftButtons.b,
      if (status.buttonMap & RideButtonMask.Y_BTN.mask == PlayButtonStatus.ON.value) ZwiftButtons.y,
      if (status.buttonMap & RideButtonMask.Z_BTN.mask == PlayButtonStatus.ON.value) ZwiftButtons.z,
      if (status.buttonMap & RideButtonMask.SHFT_UP_L_BTN.mask == PlayButtonStatus.ON.value) ZwiftButtons.shiftUpLeft,
      if (status.buttonMap & RideButtonMask.SHFT_DN_L_BTN.mask == PlayButtonStatus.ON.value) ZwiftButtons.shiftDownLeft,
      if (status.buttonMap & RideButtonMask.SHFT_UP_R_BTN.mask == PlayButtonStatus.ON.value) ZwiftButtons.shiftUpRight,
      if (status.buttonMap & RideButtonMask.SHFT_DN_R_BTN.mask == PlayButtonStatus.ON.value)
        ZwiftButtons.shiftDownRight,
      if (status.buttonMap & RideButtonMask.POWERUP_L_BTN.mask == PlayButtonStatus.ON.value) ZwiftButtons.powerUpLeft,
      if (status.buttonMap & RideButtonMask.POWERUP_R_BTN.mask == PlayButtonStatus.ON.value) ZwiftButtons.powerUpRight,
      if (status.buttonMap & RideButtonMask.ONOFF_L_BTN.mask == PlayButtonStatus.ON.value) ZwiftButtons.onOffLeft,
      if (status.buttonMap & RideButtonMask.ONOFF_R_BTN.mask == PlayButtonStatus.ON.value) ZwiftButtons.onOffRight,
    ];

    // Process ANALOG inputs separately - now properly separated from digital
    // All analog paddles (L0-L3) appear in field 3 as repeated RideAnalogKeyPress
    final List<ControllerButton> analogButtons = [];
    try {
      for (final paddle in status.analogPaddles) {
        if (paddle.hasLocation() && paddle.hasAnalogValue()) {
          if (paddle.analogValue.abs() >= analogPaddleThreshold) {
            final button = switch (paddle.location.value) {
              0 => ZwiftButtons.paddleLeft, // L0 = left paddle
              1 => ZwiftButtons.paddleRight, // L1 = right paddle
              _ => null, // L2, L3 unused
            };

            if (button != null) {
              buttonsClicked.add(button);
              analogButtons.add(button);
            }
          }
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error parsing analog paddle data: $e');
      }
    }
    return buttonsClicked;
  }

  @override
  Future<void> sendCommand(Opcode opCode, $pb.GeneratedMessage? message) async {
    final buffer = Uint8List.fromList([opCode.value, ...message?.writeToBuffer() ?? []]);
    if (kDebugMode) {
      print("Sending $opCode: ${buffer.map((e) => e.toRadixString(16).padLeft(2, '0')).join(' ')}");
    }
    await UniversalBle.write(
      device.deviceId,
      customService!.uuid,
      syncRxCharacteristic!.uuid,
      buffer,
      withoutResponse: true,
    );
    await Future.delayed(Duration(milliseconds: 500));
  }

  @override
  Future<void> sendCommandBuffer(Uint8List buffer) async {
    if (kDebugMode) {
      Logger.info("Sending ${buffer.map((e) => e.toRadixString(16).padLeft(2, '0')).join(' ')}");
    }
    await UniversalBle.write(
      device.deviceId,
      customService!.uuid,
      syncRxCharacteristic!.uuid,
      buffer,
      withoutResponse: true,
    );
  }
}

enum RideButtonMask {
  LEFT_BTN(0x00001),
  UP_BTN(0x00002),
  RIGHT_BTN(0x00004),
  DOWN_BTN(0x00008),

  A_BTN(0x00010),
  B_BTN(0x00020),
  Y_BTN(0x00040),
  Z_BTN(0x00080),

  SHFT_UP_L_BTN(0x00100),
  SHFT_DN_L_BTN(0x00200),
  SHFT_UP_R_BTN(0x01000),
  SHFT_DN_R_BTN(0x02000),

  POWERUP_L_BTN(0x00400),
  POWERUP_R_BTN(0x04000),
  ONOFF_L_BTN(0x00800),
  ONOFF_R_BTN(0x08000);

  final int mask;

  const RideButtonMask(this.mask);
}
