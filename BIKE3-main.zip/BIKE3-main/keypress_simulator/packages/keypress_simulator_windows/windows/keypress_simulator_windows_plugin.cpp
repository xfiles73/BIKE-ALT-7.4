#include "keypress_simulator_windows_plugin.h"

// This must be included before many other Windows headers.
#include <flutter_windows.h>
#include <psapi.h>
#include <string.h>
#include <windows.h>

#include <flutter/method_channel.h>
#include <flutter/plugin_registrar_windows.h>
#include <flutter/standard_method_codec.h>

#include <algorithm>
#include <memory>
#include <sstream>
#include <unordered_map>
#include <vector>

using flutter::EncodableList;
using flutter::EncodableMap;
using flutter::EncodableValue;

namespace keypress_simulator_windows {

// Forward declarations
struct FindWindowData {
  std::string targetProcessName;
  std::string targetWindowTitle;
  HWND foundWindow;
};

BOOL CALLBACK EnumWindowsCallback(HWND hwnd, LPARAM lParam);
HWND FindTargetWindow(const std::string& processName,
                      const std::string& windowTitle);

// static
void KeypressSimulatorWindowsPlugin::RegisterWithRegistrar(
    flutter::PluginRegistrarWindows* registrar) {
  auto channel =
      std::make_unique<flutter::MethodChannel<flutter::EncodableValue>>(
          registrar->messenger(), "dev.leanflutter.plugins/keypress_simulator",
          &flutter::StandardMethodCodec::GetInstance());

  auto plugin = std::make_unique<KeypressSimulatorWindowsPlugin>();

  channel->SetMethodCallHandler(
      [plugin_pointer = plugin.get()](const auto& call, auto result) {
        plugin_pointer->HandleMethodCall(call, std::move(result));
      });

  registrar->AddPlugin(std::move(plugin));
}

KeypressSimulatorWindowsPlugin::KeypressSimulatorWindowsPlugin() {}

KeypressSimulatorWindowsPlugin::~KeypressSimulatorWindowsPlugin() {}

void KeypressSimulatorWindowsPlugin::SimulateKeyPress(
    const flutter::MethodCall<flutter::EncodableValue>& method_call,
    std::unique_ptr<flutter::MethodResult<flutter::EncodableValue>> result) {
  const EncodableMap& args = std::get<EncodableMap>(*method_call.arguments());

  UINT keyCode = std::get<int>(args.at(EncodableValue("keyCode")));
  std::vector<std::string> modifiers;
  bool keyDown = std::get<bool>(args.at(EncodableValue("keyDown")));

  EncodableList key_modifier_list =
      std::get<EncodableList>(args.at(EncodableValue("modifiers")));
  for (flutter::EncodableValue key_modifier_value : key_modifier_list) {
    std::string key_modifier = std::get<std::string>(key_modifier_value);
    modifiers.push_back(key_modifier);
  }

  // List of compatible training apps to look for
  std::vector<std::string> compatibleApps = {"MyWhooshHD.exe", "MyWhoosh.exe",
                                             "indieVelo.exe", "biketerra.exe",
                                             "Rouvy.exe"};

  // Try to find and focus (or directly target) a compatible app
  std::string foundProcessName;
  bool supportsBackgroundInput = true;
  HWND targetWindow = NULL;
  for (const std::string& processName : compatibleApps) {
    targetWindow = FindTargetWindow(processName, "");
    if (targetWindow != NULL) {
      foundProcessName = processName;
      if (!supportsBackgroundInput && GetForegroundWindow() != targetWindow) {
        SetForegroundWindow(targetWindow);
        Sleep(50);  // Brief delay to ensure window is focused
      }
      break;
    }
  }

  // If we found a target window that supports background input and it's not
  // focused, send messages directly
  auto postKeyMessage = [](HWND hwnd, UINT vkCode, bool down) {
    const WORD scanCode =
        static_cast<WORD>(MapVirtualKey(vkCode, MAPVK_VK_TO_VSC));
    // Build lParam with repeat count 1 and scan code; set transition states for
    // key up
    LPARAM lParam = 1 | (static_cast<LPARAM>(scanCode) << 16);
    if (vkCode == VK_LEFT || vkCode == VK_RIGHT || vkCode == VK_UP ||
        vkCode == VK_DOWN || vkCode == VK_INSERT || vkCode == VK_DELETE ||
        vkCode == VK_HOME || vkCode == VK_END || vkCode == VK_PRIOR ||
        vkCode == VK_NEXT) {
      lParam |= (1 << 24);  // extended key
    }
    if (!down) {
      lParam |= (1 << 30);  // previous key state
      lParam |= (1 << 31);  // transition state
    }
    PostMessage(hwnd, down ? WM_KEYDOWN : WM_KEYUP, vkCode, lParam);
  };

  auto sendKeyToWindow = [&postKeyMessage](HWND hwnd,
                                           const std::vector<std::string>& mods,
                                           UINT keyCode, bool down) {
    auto handleModifier = [&postKeyMessage, hwnd](UINT vk, bool press) {
      postKeyMessage(hwnd, vk, press);
    };

    if (down) {
      for (const std::string& modifier : mods) {
        if (modifier == "shiftModifier") {
          handleModifier(VK_SHIFT, true);
        } else if (modifier == "controlModifier") {
          handleModifier(VK_CONTROL, true);
        } else if (modifier == "altModifier") {
          handleModifier(VK_MENU, true);
        } else if (modifier == "metaModifier") {
          handleModifier(VK_LWIN, true);
        }
      }
      postKeyMessage(hwnd, keyCode, true);
    } else {
      postKeyMessage(hwnd, keyCode, false);
      // release modifiers
      for (const std::string& modifier : mods) {
        if (modifier == "shiftModifier") {
          handleModifier(VK_SHIFT, false);
        } else if (modifier == "controlModifier") {
          handleModifier(VK_CONTROL, false);
        } else if (modifier == "altModifier") {
          handleModifier(VK_MENU, false);
        } else if (modifier == "metaModifier") {
          handleModifier(VK_LWIN, false);
        }
      }
    }
  };

  if (targetWindow != NULL && !foundProcessName.empty() &&
      supportsBackgroundInput && GetForegroundWindow() != targetWindow) {
    sendKeyToWindow(targetWindow, modifiers, keyCode, keyDown);
    result->Success(flutter::EncodableValue(true));
    return;
  }

  // Helper function to send modifier key events
  auto sendModifierKey = [](UINT vkCode, bool down) {
    WORD sc = (WORD)MapVirtualKey(vkCode, MAPVK_VK_TO_VSC);
    INPUT in = {0};
    in.type = INPUT_KEYBOARD;
    in.ki.wVk = 0;
    in.ki.wScan = sc;
    in.ki.dwFlags = KEYEVENTF_SCANCODE | (down ? 0 : KEYEVENTF_KEYUP);
    SendInput(1, &in, sizeof(INPUT));
  };

  // Helper function to process modifiers
  auto processModifiers = [&sendModifierKey](
                              const std::vector<std::string>& mods, bool down) {
    for (const std::string& modifier : mods) {
      if (modifier == "shiftModifier") {
        sendModifierKey(VK_SHIFT, down);
      } else if (modifier == "controlModifier") {
        sendModifierKey(VK_CONTROL, down);
      } else if (modifier == "altModifier") {
        sendModifierKey(VK_MENU, down);
      } else if (modifier == "metaModifier") {
        sendModifierKey(VK_LWIN, down);
      }
    }
  };

  // Press modifier keys first (if keyDown)
  if (keyDown) {
    processModifiers(modifiers, true);
  }

  // Send the main key
  WORD sc = (WORD)MapVirtualKey(keyCode, MAPVK_VK_TO_VSC);

  INPUT in = {0};
  in.type = INPUT_KEYBOARD;
  in.ki.wVk = 0;  // when using SCANCODE, set VK=0
  in.ki.wScan = sc;
  in.ki.dwFlags = KEYEVENTF_SCANCODE | (keyDown ? 0 : KEYEVENTF_KEYUP);
  if (keyCode == VK_LEFT || keyCode == VK_RIGHT || keyCode == VK_UP ||
      keyCode == VK_DOWN || keyCode == VK_INSERT || keyCode == VK_DELETE ||
      keyCode == VK_HOME || keyCode == VK_END || keyCode == VK_PRIOR ||
      keyCode == VK_NEXT) {
    in.ki.dwFlags |= KEYEVENTF_EXTENDEDKEY;
  }
  SendInput(1, &in, sizeof(INPUT));

  // Release modifier keys (if keyUp)
  if (!keyDown) {
    processModifiers(modifiers, false);
  }

  /*BYTE byteValue = static_cast<BYTE>(keyCode);
  keybd_event(byteValue, 0x45, keyDown ? 0 : KEYEVENTF_KEYUP, 0);*/

  result->Success(flutter::EncodableValue(true));
}

void KeypressSimulatorWindowsPlugin::SimulateMouseClick(
    const flutter::MethodCall<flutter::EncodableValue>& method_call,
    std::unique_ptr<flutter::MethodResult<flutter::EncodableValue>> result) {
  const EncodableMap& args = std::get<EncodableMap>(*method_call.arguments());
  double x = 0;
  double y = 0;

  bool keyDown = std::get<bool>(args.at(EncodableValue("keyDown")));
  auto it_x = args.find(EncodableValue("x"));
  if (it_x != args.end() && std::holds_alternative<double>(it_x->second)) {
    x = std::get<double>(it_x->second);
  }

  auto it_y = args.find(EncodableValue("y"));
  if (it_y != args.end() && std::holds_alternative<double>(it_y->second)) {
    y = std::get<double>(it_y->second);
  }

  // Get the monitor containing the target point and its DPI
  const POINT target_point = {static_cast<LONG>(x), static_cast<LONG>(y)};
  HMONITOR monitor = MonitorFromPoint(target_point, MONITOR_DEFAULTTONEAREST);
  UINT dpi = FlutterDesktopGetDpiForMonitor(monitor);
  double scale_factor = dpi / 96.0;

  // Scale the coordinates according to the DPI scaling
  int scaled_x = static_cast<int>(x * scale_factor);
  int scaled_y = static_cast<int>(y * scale_factor);

  // Move the mouse to the specified coordinates
  SetCursorPos(scaled_x, scaled_y);

  // Prepare input for mouse down and up
  INPUT input = {0};
  input.type = INPUT_MOUSE;

  if (keyDown) {
    // Mouse left button down
    input.mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
    SendInput(1, &input, sizeof(INPUT));

  } else {
    // Mouse left button up
    input.mi.dwFlags = MOUSEEVENTF_LEFTUP;
    SendInput(1, &input, sizeof(INPUT));
  }

  result->Success(flutter::EncodableValue(true));
}

BOOL CALLBACK EnumWindowsCallback(HWND hwnd, LPARAM lParam) {
  FindWindowData* data = reinterpret_cast<FindWindowData*>(lParam);

  // Check if window is visible and not minimized
  if (!IsWindowVisible(hwnd) || IsIconic(hwnd)) {
    return TRUE;  // Continue enumeration
  }

  // Get window title
  char windowTitle[256];
  GetWindowTextA(hwnd, windowTitle, sizeof(windowTitle));

  // Get process name
  DWORD processId;
  GetWindowThreadProcessId(hwnd, &processId);
  HANDLE hProcess =
      OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, processId);
  char processName[MAX_PATH];
  if (hProcess) {
    DWORD size = sizeof(processName);
    if (QueryFullProcessImageNameA(hProcess, 0, processName, &size)) {
      // Extract just the filename from the full path
      char* filename = strrchr(processName, '\\');
      if (filename) {
        filename++;  // Skip the backslash
      } else {
        filename = processName;
      }

      // Check if this matches our target
      if (!data->targetProcessName.empty() &&
          _stricmp(filename, data->targetProcessName.c_str()) == 0) {
        data->foundWindow = hwnd;
        return FALSE;  // Stop enumeration
      }
    }
    CloseHandle(hProcess);
  }

  // Check window title if process name didn't match
  if (!data->targetWindowTitle.empty() &&
      _stricmp(windowTitle, data->targetWindowTitle.c_str()) == 0) {
    data->foundWindow = hwnd;
    return FALSE;  // Stop enumeration
  }

  return TRUE;  // Continue enumeration
}

HWND FindTargetWindow(const std::string& processName,
                      const std::string& windowTitle) {
  FindWindowData data;
  data.targetProcessName = processName;
  data.targetWindowTitle = windowTitle;
  data.foundWindow = NULL;

  EnumWindows(EnumWindowsCallback, reinterpret_cast<LPARAM>(&data));
  return data.foundWindow;
}

void KeypressSimulatorWindowsPlugin::SimulateMediaKey(
    const flutter::MethodCall<flutter::EncodableValue>& method_call,
    std::unique_ptr<flutter::MethodResult<flutter::EncodableValue>> result) {
  const EncodableMap& args = std::get<EncodableMap>(*method_call.arguments());
  std::string keyIdentifier =
      std::get<std::string>(args.at(EncodableValue("key")));

  // Map string identifier to Windows virtual key codes
  static const std::unordered_map<std::string, UINT> keyMap = {
      {"playPause", VK_MEDIA_PLAY_PAUSE}, {"stop", VK_MEDIA_STOP},
      {"next", VK_MEDIA_NEXT_TRACK},      {"previous", VK_MEDIA_PREV_TRACK},
      {"volumeUp", VK_VOLUME_UP},         {"volumeDown", VK_VOLUME_DOWN}};

  auto it = keyMap.find(keyIdentifier);
  if (it == keyMap.end()) {
    result->Error("UNSUPPORTED_KEY", "Unsupported media key identifier");
    return;
  }
  UINT vkCode = it->second;

  // Send key down event
  INPUT inputs[2] = {};
  inputs[0].type = INPUT_KEYBOARD;
  inputs[0].ki.wVk = static_cast<WORD>(vkCode);
  inputs[0].ki.dwFlags = 0;  // Key down

  // Send key up event
  inputs[1].type = INPUT_KEYBOARD;
  inputs[1].ki.wVk = static_cast<WORD>(vkCode);
  inputs[1].ki.dwFlags = KEYEVENTF_KEYUP;

  UINT eventsSent = SendInput(2, inputs, sizeof(INPUT));
  if (eventsSent != 2) {
    result->Error("SEND_INPUT_FAILED", "Failed to send media key input events");
    return;
  }

  result->Success(flutter::EncodableValue(true));
}

void KeypressSimulatorWindowsPlugin::HandleMethodCall(
    const flutter::MethodCall<flutter::EncodableValue>& method_call,
    std::unique_ptr<flutter::MethodResult<flutter::EncodableValue>> result) {
  if (method_call.method_name().compare("simulateKeyPress") == 0) {
    SimulateKeyPress(method_call, std::move(result));
  } else if (method_call.method_name().compare("simulateMouseClick") == 0) {
    SimulateMouseClick(method_call, std::move(result));
  } else if (method_call.method_name().compare("simulateMediaKey") == 0) {
    SimulateMediaKey(method_call, std::move(result));
  } else {
    result->NotImplemented();
  }
}

}  // namespace keypress_simulator_windows
