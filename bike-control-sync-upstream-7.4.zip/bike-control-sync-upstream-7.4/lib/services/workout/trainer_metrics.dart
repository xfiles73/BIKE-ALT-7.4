import 'package:flutter/foundation.dart';
import 'package:prop/emulators/definitions/composite_ble_definition.dart';
import 'package:prop/emulators/definitions/fitness_bike_definition.dart';
import 'package:prop/emulators/definitions/proxy_bike_definition.dart';

/// Bundles the four `ValueListenable`s that drive workout recording, regardless
/// of whether the source is an FTMS passthrough (`FitnessBikeDefinition`) or a
/// Zwift-protocol-only trainer (`ProxyBikeDefinition`).
class TrainerMetrics {
  final ValueListenable<int?> powerW;
  final ValueListenable<int?> cadenceRpm;
  final ValueListenable<double?> speedKph;
  final ValueListenable<int?> heartRateBpm;

  /// Whether [heartRateBpm] currently comes from Apple Health (the sensor hub
  /// overrides the trainer's own value). Null means "never".
  final bool Function()? isHeartRateFromHealth;

  /// The virtual rear gear, where BikeControl shifts (FTMS bridge). Null for
  /// sources without gears; a ride then has no gear-change count.
  final ValueListenable<int>? gear;

  /// The virtual front chainring, counted as a shift when it flips.
  final ValueListenable<Object?>? frontRing;

  /// The grade the trainer app has the trainer on, in %, or null when it
  /// sends none (ERG). Null for sources BikeControl doesn't simulate for.
  final double? Function()? gradePct;

  /// What the rider sees as the source (the trainer's or sensor's name).
  final String? sourceName;

  const TrainerMetrics({
    required this.powerW,
    required this.cadenceRpm,
    required this.speedKph,
    required this.heartRateBpm,
    this.isHeartRateFromHealth,
    this.gear,
    this.frontRing,
    this.gradePct,
    this.sourceName,
  });

  TrainerMetrics named(String? name) => TrainerMetrics(
    powerW: powerW,
    cadenceRpm: cadenceRpm,
    speedKph: speedKph,
    heartRateBpm: heartRateBpm,
    isHeartRateFromHealth: isHeartRateFromHealth,
    gear: gear,
    frontRing: frontRing,
    gradePct: gradePct,
    sourceName: name,
  );

  /// Returns null when [definition] is not a supported bike definition.
  ///
  /// Accepts a [CompositeBleDefinition] and extracts the first supported child,
  /// so callers can pass [DirconEmulator.activeDefinition] directly.
  static TrainerMetrics? fromDefinition(Object? definition, {bool Function()? isHeartRateFromHealth}) {
    if (definition is CompositeBleDefinition) {
      final fbd = definition.firstOfType<FitnessBikeDefinition>();
      if (fbd != null) return fromDefinition(fbd, isHeartRateFromHealth: isHeartRateFromHealth);
      final proxy = definition.firstOfType<ProxyBikeDefinition>();
      if (proxy != null) return fromDefinition(proxy, isHeartRateFromHealth: isHeartRateFromHealth);
      return null;
    }
    if (definition is FitnessBikeDefinition) {
      return TrainerMetrics(
        powerW: definition.powerW,
        cadenceRpm: definition.cadenceRpm,
        speedKph: definition.speedKph,
        heartRateBpm: definition.heartRateBpm,
        isHeartRateFromHealth: isHeartRateFromHealth,
        gear: definition.currentGear,
        frontRing: definition.frontRing,
        // In ERG the last SIM grade lingers; the course is not being ridden.
        gradePct: () => definition.trainerMode.value == TrainerMode.ergMode ? null : definition.simGrade.value / 100,
      );
    }
    if (definition is ProxyBikeDefinition) {
      return TrainerMetrics(
        powerW: definition.powerW,
        cadenceRpm: definition.cadenceRpm,
        speedKph: definition.speedKph,
        heartRateBpm: definition.heartRateBpm,
        isHeartRateFromHealth: isHeartRateFromHealth,
      );
    }
    return null;
  }
}
