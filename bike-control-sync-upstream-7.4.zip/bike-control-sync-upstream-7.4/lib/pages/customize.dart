import 'package:bike_control/bluetooth/devices/base_device.dart';
import 'package:bike_control/main.dart';
import 'package:bike_control/pages/trainer_connection_settings.dart';
import 'package:bike_control/utils/core.dart';
import 'package:bike_control/utils/i18n_extension.dart';
import 'package:bike_control/utils/iap/iap_manager.dart';
import 'package:bike_control/utils/keymap/apps/custom_app.dart';
import 'package:bike_control/utils/keymap/apps/supported_app.dart';
import 'package:bike_control/utils/keymap/manager.dart';
import 'package:bike_control/widgets/keymap/mapping.dart';
import 'package:bike_control/widgets/keymap_explanation.dart';
import 'package:bike_control/widgets/status_icon.dart';
import 'package:bike_control/widgets/ui/beta_pill.dart';
import 'package:bike_control/widgets/ui/openbikecontrol_logo.dart';
import 'package:bike_control/widgets/ui/warning.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';

class CustomizePage extends StatefulWidget {
  final bool isMobile;

  final BaseDevice? filterDevice;

  /// The picked button, shared with a detail pane beside the list.
  final MappingSelection? selection;

  /// The list only picks buttons; the detail pane beside it edits them.
  final bool master;

  /// Called after the mapping changed (another mapping picked, or edited), so
  /// a detail pane outside this widget can follow.
  final VoidCallback? onChanged;

  const CustomizePage({
    super.key,
    required this.isMobile,
    this.filterDevice,
    this.selection,
    this.master = false,
    this.onChanged,
  });

  @override
  State<CustomizePage> createState() => _CustomizeState();
}

class _CustomizeState extends State<CustomizePage> {
  @override
  void initState() {
    IAPManager.instance.entitlements.addListener(_onIAPChange);
    super.initState();
  }

  @override
  void dispose() {
    IAPManager.instance.entitlements.removeListener(_onIAPChange);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      spacing: 12,
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (core.actionHandler.supportedApp != null)
          Row(
            spacing: 8,
            children: [
              Expanded(
                child: Select<SupportedApp?>(
                  value: core.actionHandler.supportedApp,
                  popup: SelectPopup(
                    items: SelectItemList(
                      children: [
                        ..._getAllApps().map(
                          (a) => SelectItemButton(
                            value: a,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(child: Text(a.name)),
                                if (a is CustomApp)
                                  BetaPill(text: 'CUSTOM')
                                else if (a.supports(AppConnectionMethod.obpBle) ||
                                    a.supports(AppConnectionMethod.obpMdns) ||
                                    a.supports(AppConnectionMethod.obpDirCon))
                                  OpenBikeControlLogo(),
                              ],
                            ),
                          ),
                        ),
                        SelectItemButton(
                          value: CustomApp(profileName: 'New'),
                          child: Row(
                            spacing: 6,
                            children: [
                              Icon(LucideIcons.plus, color: Theme.of(context).colorScheme.mutedForeground),
                              Expanded(child: Text(context.i18n.createNewKeymap).normal.muted),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ).call,
                  itemBuilder: (c, app) => Row(
                    spacing: 8,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(child: Text(shownKeymapName(app!.name))),
                      if (app is CustomApp) BetaPill(text: 'CUSTOM'),
                    ],
                  ),
                  placeholder: Text(context.i18n.selectKeymap),

                  onChanged: (app) async {
                    if (app == null) {
                      return;
                    } else if (app.name == 'New') {
                      final profileName = await KeymapManager().showNewProfileDialog(context);
                      if (profileName != null && profileName.isNotEmpty) {
                        final customApp = CustomApp(profileName: profileName);
                        core.actionHandler.init(customApp);
                        await core.settings.setKeyMap(customApp);

                        setState(() {});
                        widget.onChanged?.call();
                      }
                    } else {
                      core.actionHandler.init(app);
                      await core.settings.setKeyMap(app);
                      setState(() {});
                      widget.onChanged?.call();
                    }
                  },
                ),
              ),
              // A cloud and a dot say nothing on their own: the tooltip and
              // the label name what it does; StatusIcon reads its on/off.
              Tooltip(
                tooltip: (c) => TooltipContainer(child: Text(context.i18n.keymapSyncLabel)),
                child: Semantics(
                  label: context.i18n.keymapSyncLabel,
                  child: StatusIcon(
                  status: IAPManager.instance.isProEnabled,
                  icon: LucideIcons.cloudUpload,
                  started: IAPManager.instance.isProEnabled,
                  onPressed: IAPManager.instance.isProEnabled
                      ? null
                      : () {
                          // The cloud icon carries no label of its own, so the
                          // dialog is where the rider finds out what it does.
                          IAPManager.instance.ensureProForFeature(
                            context,
                            featureName: context.i18n.synchronizeAcrossDevices,
                          );
                        },
                  ),
                ),
              ),
              KeymapManager().getManageProfileDialog(
                context,
                core.actionHandler.supportedApp is CustomApp ? core.actionHandler.supportedApp?.name : null,
                onDone: () {
                  setState(() {});
                  widget.onChanged?.call();
                },
              ),
            ],
          ),

        if (core.actionHandler.supportedApp != null && _hasSomethingToMap)
          KeymapExplanation(
            key: Key(core.actionHandler.supportedApp!.keymap.runtimeType.toString()),
            keymap: core.actionHandler.supportedApp!.keymap,
            filterDevice: widget.filterDevice,
            selection: widget.selection,
            master: widget.master,
            onUpdate: () {
              setState(() {});
              widget.onChanged?.call();
            },
          )
        else if (core.actionHandler.supportedApp == null)
          Warning(
            children: [
              Text(context.i18n.noTrainerSelected).small,
              Button.outline(
                child: Text(context.i18n.openConnectionSettings),
                onPressed: () async {
                  await context.push(const TrainerConnectionSettingsPage());
                  setState(() {});
                },
              ),
            ],
          )
        else
          Warning(
            children: [
              Text(context.i18n.noConnectionMethodSelected).small,
              Button.outline(
                child: Text(context.i18n.openConnectionSettings),
                onPressed: () async {
                  await context.push(const TrainerConnectionSettingsPage());
                  setState(() {});
                },
              ),
            ],
          ),
      ],
    );
  }

  /// Whether there are any buttons worth showing a mapping table for.
  ///
  /// [CustomizePage.filterDevice] is the strongest answer there is: the page is
  /// embedded in that device's own settings, so the rider is looking straight
  /// at the thing whose buttons they came to map. It counts even when the
  /// device is only a remembered stand-in — a controller that is switched off
  /// is still one whose mapping can be edited, and falling through to "no
  /// connection method selected" both hid that and named a reason that had
  /// nothing to do with it.
  bool get _hasSomethingToMap =>
      widget.filterDevice != null ||
      core.connection.controllerDevices.isNotEmpty ||
      core.connection.proxyDevices.any((e) => e.isConnected);

  List<SupportedApp> _getAllApps() {
    final baseApp = core.settings.getTrainerApp();
    final customProfiles = core.settings.getCustomAppProfiles();

    final customApps = customProfiles.map((profile) {
      final customApp = CustomApp(profileName: profile);
      final savedKeymap = core.settings.getCustomAppKeymap(profile);
      if (savedKeymap != null) {
        try {
          customApp.decodeKeymap(savedKeymap);
        } catch (e, s) {
          recordError(e, s, context: 'getAllApps');
        }
      }
      return customApp;
    }).toList();

    // If no custom profiles exist, add the default "Custom" one
    if (customApps.isEmpty) {
      customApps.add(CustomApp());
    }

    return [if (baseApp != null) baseApp, ...customApps];
  }

  void _onIAPChange() {
    setState(() {});
  }
}
