import 'dart:async';
import 'dart:io';

import 'package:bike_control/gen/l10n.dart';
import 'package:bike_control/utils/auth/account_session.dart';
import 'package:bike_control/bluetooth/messages/notification.dart';
import 'package:bike_control/main.dart';
import 'package:bike_control/models/subscription_term.dart';
import 'package:bike_control/services/entitlements_service.dart';
import 'package:bike_control/utils/analytics/campaign_attributes.dart';
import 'package:bike_control/utils/analytics/install_referrer_reporter.dart';
import 'package:bike_control/utils/core.dart';
import 'package:bike_control/widgets/ui/toast.dart';
import 'package:dartx/dartx.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:prop/prop.dart' as zp;
import 'package:purchases_flutter/purchases_flutter.dart';
import 'package:purchases_ui_flutter/purchases_ui_flutter.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher_string.dart';
import 'package:version/version.dart';

/// RevenueCat-based IAP service for iOS, macOS, and Android
class RevenueCatService {
  static const int trialDays = 5;

  /// First build number shipped as a free download. Builds at or above this
  /// number are no longer auto-granted the full version — they fall into the
  /// existing trial/freemium path. Builds 77..[freeAgainFromBuild] - 1 remain
  /// the paid era and keep the full version forever (Apple's
  /// `originalApplicationVersion` is fixed at first download).
  static const int freeAgainFromBuild = 138;

  /// Whether an Apple `originalApplicationVersion` integer build number should
  /// be treated as having purchased the full version.
  ///
  /// - `< 58` (macOS `< 61`): old paid era → purchased.
  /// - `58..76`: legacy free + trial window → not purchased.
  /// - `77..[freeAgainFromBuild] - 1`: current paid era → purchased.
  /// - `>= freeAgainFromBuild`: free + trial again → not purchased.
  @visibleForTesting
  static bool isPurchasedBuild(int build, {required bool isMacOS}) =>
      build < (isMacOS ? 61 : 58) || (build >= 77 && build < freeAgainFromBuild);

  static const String _trialStartDateKey = 'iap_trial_start_date';
  static const String _purchaseStatusKey = 'iap_purchase_status';
  static const String _dailyCommandCountKey = 'iap_daily_command_count';
  static const String _lastCommandDateKey = 'iap_last_command_date';
  static const String _syncedPurchasesKey = 'iap_synced_purchases';

  // RevenueCat entitlement identifier
  static const String fullVersionEntitlement = 'Full Version';
  static const String proVersionEntitlement = 'pro';

  final FlutterSecureStorage _prefs;
  final ValueNotifier<bool> isPurchasedNotifier;
  final ValueNotifier<bool> isProNotifier;

  /// The store's record of the Pro subscription (renewal, billing issue,
  /// trial), null without one.
  final ValueNotifier<SubscriptionTerm?>? termNotifier;

  /// Receives the store's subscription-management page.
  final void Function(String? url)? onManagementUrl;
  final int Function() getDailyCommandLimit;
  final void Function(int limit) setDailyCommandLimit;
  final EntitlementsService entitlementsService;
  final String premiumProductKeyMonthly;
  final String premiumProductKeyYearly;

  bool _isInitialized = false;
  bool _isConfigured = false;
  String? _trialStartDate;
  String? _lastCommandDate;
  int? _dailyCommandCount;
  bool hasPurchasedBefore50 = false;

  RevenueCatService(
    this._prefs, {
    required this.isPurchasedNotifier,
    required this.isProNotifier,
    this.termNotifier,
    this.onManagementUrl,
    required this.getDailyCommandLimit,
    required this.setDailyCommandLimit,
    required this.entitlementsService,
    required this.premiumProductKeyMonthly,
    required this.premiumProductKeyYearly,
  });

  /// Initialize the RevenueCat service
  Future<void> initialize() async {
    if (_isInitialized) return;

    try {
      // Skip RevenueCat initialization on web or unsupported platforms
      if (kIsWeb) {
        debugPrint('RevenueCat not supported on web');
        _isInitialized = true;
        return;
      }

      // Get API key from environment variable
      final String apiKey;

      if (Platform.isAndroid) {
        apiKey =
            Platform.environment['REVENUECAT_API_KEY_ANDROID'] ??
            const String.fromEnvironment('REVENUECAT_API_KEY_ANDROID', defaultValue: '');
      } else if (Platform.isIOS || Platform.isMacOS) {
        apiKey =
            Platform.environment['REVENUECAT_API_KEY_IOS'] ??
            const String.fromEnvironment('REVENUECAT_API_KEY_IOS', defaultValue: '');
      } else {
        apiKey = '';
      }

      if (apiKey.isEmpty) {
        debugPrint('RevenueCat API key not found in environment');
        core.connection.signalNotification(
          LogNotification('RevenueCat API key not configured'),
        );
        isPurchasedNotifier.value = false;
        _isInitialized = true;
        return;
      }

      // Configure RevenueCat
      final configuration = PurchasesConfiguration(apiKey);
      // Only a real account becomes the RevenueCat identity, never the
      // support chat's anonymous session. Without one, RevenueCat keeps its
      // cached (or anonymous) app user id.
      final session = core.supabase.auth.currentSession;
      if (session != null && hasAccount(session.user)) {
        configuration.appUserID = session.user.id;
      }

      // Enable debug logs in debug mode
      if (kDebugMode) {
        await Purchases.setLogLevel(LogLevel.debug);
      }

      await Purchases.configure(configuration);
      _isConfigured = true;

      // Apple Ads attribution, the iOS/macOS counterpart of the Play install
      // referrer that setAttributes() forwards on Android. RevenueCat reads
      // the AdServices token itself and attaches campaign / ad group /
      // keyword to the subscriber, which is what turns a cost-per-install into
      // trial-to-paid and revenue per keyword. Off by default in the SDK. A
      // failure here must not cost us the rest of the init.
      if (Platform.isIOS || Platform.isMacOS) {
        try {
          await Purchases.enableAdServicesAttributionTokenCollection();
        } catch (e, s) {
          recordError(e, s, context: 'RevenueCat AdServices attribution');
        }
      }

      debugPrint('RevenueCat initialized successfully');
      core.connection.signalNotification(LogNotification('RevenueCat initialized'));

      // Listen for customer info updates
      Purchases.addCustomerInfoUpdateListener((customerInfo) {
        _handleCustomerInfoUpdate(customerInfo);
      });
      _isInitialized = true;

      // Check existing purchase status
      await _checkExistingPurchase();
      await _syncRevenueCatUser(session);
    } catch (e, s) {
      debugPrint('Error initializing RevenueCat: $e');
      recordError(e, s, context: 'Initializing RevenueCat');
      isPurchasedNotifier.value = false;
      _isInitialized = true;
    }

    try {
      _trialStartDate = await _prefs.read(key: _trialStartDateKey);
      core.connection.signalNotification(
        LogNotification('Trial start date: $_trialStartDate => $trialDaysRemaining'),
      );

      _lastCommandDate = await _prefs.read(key: _lastCommandDateKey);
      final commandCount = await _prefs.read(key: _dailyCommandCountKey) ?? '0';
      _dailyCommandCount = int.tryParse(commandCount);

      if (!isTrialExpired) {
        setDailyCommandLimit(80);
      }
      await setAttributes();
    } catch (e, s) {
      recordError(e, s, context: 'Initializing Trial and Command Tracking');
      core.connection.signalNotification(
        AlertNotification(
          zp.LogLevel.LOGLEVEL_ERROR,
          'There was an error initializing the trial period or command tracking. Please try again.',
        ),
      );
    }
  }

  /// Check if the user has an active entitlement
  Future<void> _checkExistingPurchase() async {
    try {
      final storedStatus = await _prefs.read(key: _syncedPurchasesKey);
      if (storedStatus != "true") {
        await _prefs.write(key: _syncedPurchasesKey, value: "true");
        await Purchases.syncPurchases();
      }
      // Check current entitlement status from RevenueCat
      final customerInfo = await Purchases.getCustomerInfo();
      await _handleCustomerInfoUpdate(customerInfo);
    } catch (e, s) {
      debugPrint('Error checking existing purchase: $e');
      recordError(e, s, context: 'Checking existing purchase');
    }
  }

  /// Handle customer info updates from RevenueCat
  Future<bool> _handleCustomerInfoUpdate(CustomerInfo customerInfo) async {
    final fullVersionEntitlements = customerInfo.entitlements.active[fullVersionEntitlement];

    final userId = await Purchases.appUserID;
    core.connection.signalNotification(LogNotification('User ID: $userId at ${customerInfo.requestDate}'));
    core.connection.signalNotification(LogNotification('Full Version entitlement: ${fullVersionEntitlements != null}'));

    final pro = customerInfo.entitlements.active[proVersionEntitlement];
    isProNotifier.value = pro != null;
    termNotifier?.value = pro == null ? null : SubscriptionTerm.fromRevenueCat(pro);
    onManagementUrl?.call(customerInfo.managementURL);

    if (fullVersionEntitlements == null) {
      // purchased before IAP migration
      if (Platform.isAndroid) {
        final storedStatus = await _prefs.read(key: _purchaseStatusKey);
        if (storedStatus == "true") {
          core.connection.signalNotification(LogNotification('Setting full version based on stored status'));
          await Purchases.setAttributes({_purchaseStatusKey: "true"});
          isPurchasedNotifier.value = true;
          hasPurchasedBefore50 = true;
        }
      } else {
        final purchasedVersion = customerInfo.originalApplicationVersion;
        core.connection.signalNotification(LogNotification('Apple receipt validated for version: $purchasedVersion'));
        if (purchasedVersion != null && purchasedVersion.contains(".")) {
          final parsedVersion = Version.parse(purchasedVersion);
          isPurchasedNotifier.value = parsedVersion < Version(4, 2, 0) || parsedVersion >= Version(4, 4, 0);
          hasPurchasedBefore50 = parsedVersion < Version(5, 0, 0);
        } else {
          final purchasedVersionAsInt = int.tryParse(purchasedVersion.toString()) ?? 1337;
          isPurchasedNotifier.value = isPurchasedBuild(purchasedVersionAsInt, isMacOS: Platform.isMacOS);
          hasPurchasedBefore50 = purchasedVersionAsInt < 114;
        }
      }
    } else {
      isPurchasedNotifier.value = true;
      hasPurchasedBefore50 = DateTime.parse(
        fullVersionEntitlements.originalPurchaseDate,
      ).isBefore(DateTime(2026, 4, 19));
    }

    return isPurchasedNotifier.value;
  }

  /// Present the RevenueCat paywall
  Future<void> presentPaywall(Offering offering) async {
    try {
      if (!_isInitialized) {
        await initialize();
      }

      final paywallResult = await RevenueCatUI.presentPaywall(displayCloseButton: true, offering: offering);

      debugPrint('Paywall result: $paywallResult');
      if (paywallResult == PaywallResult.purchased || paywallResult == PaywallResult.restored) {
        await refreshEntitlementsWithRetry();
      }
    } catch (e, s) {
      debugPrint('Error presenting paywall: $e');
      recordError(e, s, context: 'Presenting paywall');
      core.connection.signalNotification(
        AlertNotification(
          zp.LogLevel.LOGLEVEL_ERROR,
          'There was an error displaying the paywall. Please try again.',
        ),
      );
    }
  }

  /// Restore previous purchases. Says the outcome in a toast and resolves to
  /// whether a purchase (Base or Pro) was found; rethrows when the store
  /// could not be asked.
  Future<bool> restorePurchases() async {
    try {
      final customerInfo = await Purchases.restorePurchases();
      final purchased = await _handleCustomerInfoUpdate(customerInfo);
      await refreshEntitlementsWithRetry();
      final restored = purchased || isProNotifier.value;
      core.connection.signalNotification(
        AlertNotification(
          zp.LogLevel.LOGLEVEL_INFO,
          restored ? AppLocalizations.current.restorePurchasesDone : AppLocalizations.current.restorePurchasesNone,
        ),
      );
      return restored;
    } catch (e, s) {
      core.connection.signalNotification(
        AlertNotification(zp.LogLevel.LOGLEVEL_ERROR, AppLocalizations.current.restorePurchasesFailed),
      );
      recordError(e, s, context: 'Restore Purchases');
      rethrow;
    }
  }

  /// Purchase the full version (use paywall instead)
  Future<void> purchaseFullVersion(BuildContext context, {bool directPurchase = false}) async {
    // Direct the user to the paywall for a better experience
    final offerings = await Purchases.getOfferings();
    final defaultOffering = offerings.all['pro'];
    if (defaultOffering == null) {
      buildToast(title: AppLocalizations.current.fullVersionOfferingUnavailable);
      return;
    }

    if (Platform.isMacOS || directPurchase) {
      try {
        final lifetimePackage = defaultOffering.lifetime;
        if (lifetimePackage == null) {
          await presentPaywall(defaultOffering);
          return;
        }

        final purchaseParams = PurchaseParams.package(lifetimePackage);
        PurchaseResult result = await Purchases.purchase(purchaseParams);
        core.connection.signalNotification(
          LogNotification('Purchase result: $result'),
        );
        await refreshEntitlementsWithRetry();
      } on PlatformException catch (e, s) {
        var errorCode = PurchasesErrorHelper.getErrorCode(e);
        // A rider dismissing the store sheet is expected — never log or toast it.
        if (errorCode != PurchasesErrorCode.purchaseCancelledError) {
          recordError(e, s, context: 'Purchasing full version');
          buildToast(title: e.message);
        }
      }
    } else {
      await presentPaywall(defaultOffering);
    }
  }

  /// Purchase the subscription (use paywall instead)
  Future<void> purchaseSubscription(
    BuildContext context, {
    bool yearly = false,
    bool directPurchase = false,
  }) async {
    // Direct the user to the paywall for a better experience
    final offerings = await Purchases.getOfferings();
    Offering? proOffering;
    if (isPurchasedNotifier.value) {
      proOffering = offerings.all['proonly-freemonth'];
    } else {
      proOffering = offerings.all['proonly'];
    }
    if (proOffering == null) {
      buildToast(title: AppLocalizations.current.subscriptionOfferingUnavailable);
      return;
    }

    if (Platform.isMacOS || directPurchase) {
      try {
        final packageToPurchase = yearly
            ? (proOffering.annual ?? proOffering.monthly)
            : (proOffering.monthly ?? proOffering.annual);
        if (packageToPurchase == null) {
          await presentPaywall(proOffering);
          return;
        }

        final purchaseParams = PurchaseParams.package(packageToPurchase);
        PurchaseResult result = await Purchases.purchase(purchaseParams);
        core.connection.signalNotification(
          LogNotification('Purchase result: $result'),
        );
        await refreshEntitlementsWithRetry();
      } on PlatformException catch (e, s) {
        var errorCode = PurchasesErrorHelper.getErrorCode(e);
        // A rider dismissing the store sheet is expected — never log or toast it.
        if (errorCode != PurchasesErrorCode.purchaseCancelledError) {
          recordError(e, s, context: 'Purchasing subscription');
          buildToast(title: e.message);
        }
      }
    } else {
      await presentPaywall(proOffering);
    }
  }

  Future<void> logInWithSupabaseUserId(String supabaseUserId, {required bool performSync}) async {
    if (!_isConfigured) {
      return;
    }
    final result = await Purchases.logIn(supabaseUserId);
    // Pro bought while signed out sits on the anonymous RevenueCat id until
    // this logIn; the sync can run before RevenueCat's API shows it under the
    // account, leaving the backend without Pro. When RevenueCat says Pro,
    // ask the backend to wait for it, and heal if it still came back empty.
    await _handleCustomerInfoUpdate(result.customerInfo);
    if (performSync) {
      await _syncSubscriptions(expectActive: isProNotifier.value);
    }
    if (needsSubscriptionSync(signedIn: true, storePro: isProNotifier.value, backendPro: _backendPro)) {
      await refreshEntitlementsWithRetry();
    }
  }

  Future<void> _syncSubscriptions({required bool expectActive}) =>
      core.supabase.functions.invoke('sync-subscriptions', body: syncSubscriptionsBody(expectActive: expectActive));

  /// The `sync-subscriptions` request body. `expectActive` makes the backend
  /// retry RevenueCat briefly instead of returning no subscription at once;
  /// only sent when RevenueCat already says Pro on this device.
  @visibleForTesting
  static Map<String, dynamic>? syncSubscriptionsBody({required bool expectActive}) =>
      expectActive ? const {'expectActive': true} : null;

  bool get _backendPro =>
      entitlementsService.hasActive(premiumProductKeyMonthly) || entitlementsService.hasActive(premiumProductKeyYearly);

  /// Whether the backend must be told to re-read the store: signed into an
  /// account, RevenueCat says Pro, but the account's entitlements don't.
  @visibleForTesting
  static bool needsSubscriptionSync({required bool signedIn, required bool storePro, required bool backendPro}) =>
      signedIn && storePro && !backendPro;

  static const List<Duration> _entitlementRetryDelays = [
    Duration(seconds: 1),
    Duration(seconds: 2),
    Duration(seconds: 4),
  ];

  /// Re-reads the backend entitlements until they show Pro, backing off
  /// between attempts. While [needsSync] holds, each retry first runs
  /// `sync-subscriptions`, since RevenueCat's API can lag a few seconds
  /// behind a logIn or purchase. Resolves to whether the backend has Pro.
  @visibleForTesting
  static Future<bool> refreshUntilBackendPro({
    required Future<void> Function() refresh,
    required bool Function() backendPro,
    required bool Function() needsSync,
    required Future<void> Function() syncSubscriptions,
    List<Duration> retryDelays = _entitlementRetryDelays,
    Future<void> Function(Duration delay) wait = Future.delayed,
  }) async {
    for (var attempt = 0; ; attempt++) {
      if (attempt > 0 && needsSync()) await syncSubscriptions();
      await refresh();
      if (backendPro()) return true;
      if (attempt == retryDelays.length) return false;
      await wait(retryDelays[attempt]);
    }
  }

  Future<void> logOut() async {
    if (!_isConfigured) {
      return;
    }
    try {
      await Purchases.logOut();
    } on PlatformException catch (error) {
      // RevenueCat throws when logging out anonymous users.
      if (error.code != '22') {
        // LogOut was called but the current user is anonymous.
        rethrow;
      }
    }
  }

  Future<void> refreshEntitlementsWithRetry() async {
    final backendPro = await refreshUntilBackendPro(
      refresh: () => entitlementsService.refresh(force: true),
      backendPro: () => _backendPro,
      needsSync: () => needsSubscriptionSync(
        signedIn: hasAccount(core.supabase.auth.currentSession?.user),
        storePro: isProNotifier.value,
        backendPro: _backendPro,
      ),
      syncSubscriptions: () async {
        try {
          await _syncSubscriptions(expectActive: true);
        } catch (e, s) {
          recordError(e, s, context: 'Healing backend entitlements via sync-subscriptions');
        }
      },
    );
    if (backendPro) {
      isPurchasedNotifier.value = true;
    }
  }

  /// Check if the trial period has started
  bool get hasTrialStarted {
    return _trialStartDate != null;
  }

  /// Start the trial period
  Future<void> startTrial() async {
    if (!hasTrialStarted) {
      await _prefs.write(key: _trialStartDateKey, value: DateTime.now().toIso8601String());
    }
  }

  /// Get the number of days remaining in the trial
  int get trialDaysRemaining {
    if (isPurchasedNotifier.value) return 0;

    final trialStart = _trialStartDate;
    if (trialStart == null) return trialDays;

    final startDate = DateTime.parse(trialStart);
    final now = DateTime.now();
    final daysPassed = now.difference(startDate).inDays;
    final remaining = trialDays - daysPassed;

    return remaining > 0 ? remaining : 0;
  }

  /// Check if the trial has expired
  bool get isTrialExpired {
    return (!isPurchasedNotifier.value && hasTrialStarted && trialDaysRemaining <= 0);
  }

  /// Get the number of commands executed today
  int get dailyCommandCount {
    final lastDate = _lastCommandDate;
    final today = DateTime.now().toIso8601String().split('T')[0];

    if (lastDate != today) {
      // Reset counter for new day
      _lastCommandDate = today;
      _dailyCommandCount = 0;
    }

    return _dailyCommandCount ?? 0;
  }

  /// Increment the daily command count
  Future<void> incrementCommandCount() async {
    if (isPurchasedNotifier.value) {
      return; // No need to track for purchased users
    }
    try {
      final today = DateTime.now().toIso8601String().split('T')[0];
      final lastDate = await _prefs.read(key: _lastCommandDateKey);

      if (lastDate != today) {
        // Reset counter for new day
        _lastCommandDate = today;
        _dailyCommandCount = 1;
        await _prefs.write(key: _lastCommandDateKey, value: today);
        await _prefs.write(key: _dailyCommandCountKey, value: '1');
      } else {
        final count = _dailyCommandCount ?? 0;
        _dailyCommandCount = count + 1;
        await _prefs.write(key: _dailyCommandCountKey, value: _dailyCommandCount.toString());
      }
    } catch (e, s) {
      final count = _dailyCommandCount ?? 0;
      _dailyCommandCount = count + 1;
      // e.g. https://github.com/OpenBikeControl/bikecontrol/issues/279
      debugPrint('Error incrementing command count: $e');
      recordError(e, s, context: 'Incrementing command count');
    }
  }

  /// Check if the user can execute a command
  bool get canExecuteCommand {
    if (isPurchasedNotifier.value) return true;
    return dailyCommandCount < getDailyCommandLimit();
  }

  /// Get the number of commands remaining today (for free tier after trial)
  int get commandsRemainingToday {
    if (isPurchasedNotifier.value) return -1; // Unlimited
    final remaining = getDailyCommandLimit() - dailyCommandCount;
    return remaining > 0 ? remaining : 0; // Never return negative
  }

  /// Dispose the service
  void dispose() {}

  Future<void> reset(bool fullReset) async {
    if (fullReset) {
      await _prefs.deleteAll();
    } else {
      await _prefs.delete(key: _purchaseStatusKey);
      _isInitialized = false;
      Purchases.invalidateCustomerInfoCache();
      await initialize();
      _checkExistingPurchase();
    }
  }

  Future<void> redeem(String purchaseId) async {
    await Purchases.setAttributes({"purchase_id": purchaseId});
    core.connection.signalNotification(LogNotification('Redeemed purchase ID: $purchaseId'));
    Purchases.invalidateCustomerInfoCache();
    _checkExistingPurchase();
    isPurchasedNotifier.value = true;
  }

  Future<void> setAttributes() async {
    if (!_isConfigured) {
      return;
    }
    final Session? session = core.supabase.auth.currentSession;

    // Campaign attribution for this install, from the Play referrer the
    // reporter stored on first launch (Android only -- everywhere else this is
    // simply empty). Re-sent every time, because RevenueCat subscriber
    // attributes do not persist on their own, and it is what makes paid
    // acquisition measurable past the install: trial-to-paid and revenue by
    // campaign, not just cost-per-install.
    var campaign = const <String, String>{};
    try {
      if (core.settings.isInitialized) {
        campaign = campaignAttributes(core.settings.prefs.getString(InstallReferrerReporter.referrerKey));
      }
    } catch (e, s) {
      // A malformed stored referrer must not cost us the other attributes.
      recordError(e, s, context: 'RevenueCatService.campaignAttributes');
    }

    // attributes are fully anonymous
    await Purchases.setAttributes({
      ...campaign,
      if (session != null && hasAccount(session.user)) "bikecontrol_user": session.user.id,
      "bikecontrol_trainer": core.settings.getTrainerApp()?.name ?? '-',
      "bikecontrol_target": core.settings.getLastTarget()?.name ?? '-',
      if (core.connection.controllerDevices.isNotEmpty)
        'bikecontrol_controllers': core.connection.controllerDevices.joinToString(
          transform: (d) => d.toString(),
          separator: ',',
        ),
      'bikecontrol_keymap': core.settings.getKeyMap()?.name ?? '-',
    });
  }

  Future<void> _syncRevenueCatUser(Session? session) async {
    if (!_isConfigured) {
      return;
    }
    if (session == null) {
      await logOut();
      return;
    }
    // Anonymous support-chat session: leave the RevenueCat identity as it is.
    // Logging out would drop a store purchase made without an account from
    // view, logging in would tie it to a throwaway user.
    if (!hasAccount(session.user)) return;
    await logInWithSupabaseUserId(session.user.id, performSync: false);
  }

  /// The Mac App Store's subscription settings, when the store gave no page.
  static const String macSubscriptionsUrl = 'https://apps.apple.com/account/subscriptions';

  Future<bool> openBillingPortal(BuildContext context, {String? managementUrl}) async {
    if (Platform.isMacOS) {
      // RevenueCat's customer center is not available on macOS: open the Mac
      // App Store's subscription settings instead.
      await launchUrlString(managementUrl ?? macSubscriptionsUrl, mode: LaunchMode.externalApplication);
      return true;
    }
    await RevenueCatUI.presentCustomerCenter();
    return true;
  }
}
