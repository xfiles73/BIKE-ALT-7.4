import 'dart:async';
import 'dart:io';

import 'package:bike_control/utils/auth/account_session.dart';
import 'package:bike_control/gen/l10n.dart';
import 'package:bike_control/models/device_limit_reached_error.dart';
import 'package:bike_control/models/entitlement.dart';
import 'package:bike_control/models/subscription_term.dart';
import 'package:bike_control/pages/paywall.dart';
import 'package:bike_control/widgets/ui/sheet_pull_to_dismiss.dart';
import 'package:bike_control/services/device_identity_service.dart';
import 'package:bike_control/services/device_management_service.dart';
import 'package:bike_control/services/entitlements_service.dart';
import 'package:bike_control/utils/core.dart';
import 'package:bike_control/utils/host_platform.dart';
import 'package:bike_control/utils/iap/revenuecat_service.dart';
import 'package:bike_control/utils/iap/windows_iap_service.dart';
import 'package:bike_control/utils/plan_format.dart';
import 'package:bike_control/utils/windows_store_environment.dart';
import 'package:bike_control/widgets/go_pro_dialog.dart';
import 'package:bike_control/widgets/ui/toast.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

enum SubscriptionPlan {
  monthly,
  yearly,
}

/// Where this build sells and restores purchases.
enum PurchaseChannel {
  appStore,
  macAppStore,
  playStore,
  microsoftStore,

  /// The Windows download from the website: Stripe, behind a sign-in.
  windowsDirect,

  /// No purchases here (the web, tests).
  none;

  /// "Restore purchases" asks the store; only the app stores can answer.
  bool get canRestore => this == appStore || this == macAppStore || this == playStore;
}

/// Unified IAP manager that handles platform-specific IAP services.
class IAPManager {
  static IAPManager? _instance;
  static IAPManager get instance {
    _instance ??= IAPManager._();
    return _instance!;
  }

  static const String premiumMonthlyProductKey = 'premium_monthly';
  static const String premiumYearlyProductKey = 'premium_yearly';
  static const String fullVersionProductKey = 'full_version';
  static const String betaAccessProductKey = 'beta_access';
  static int dailyCommandLimit = 15;

  RevenueCatService? _revenueCatService;
  WindowsIAPService? _windowsIapService;
  StreamSubscription<AuthState>? _authSubscription;
  bool _isInitialized = false;

  final DeviceIdentityService deviceIdentity = DeviceIdentityService();
  late final DeviceManagementService deviceManagement = DeviceManagementService(
    supabase: core.supabase,
    deviceIdentityService: deviceIdentity,
  );
  late final EntitlementsService entitlements = EntitlementsService(
    core.supabase,
    deviceIdentityService: deviceIdentity,
  );

  ValueNotifier<bool> isPurchased = ValueNotifier<bool>(false);
  ValueNotifier<bool> isLocalPro = ValueNotifier<bool>(false);

  /// The store's own record of the Pro subscription on this device (iOS,
  /// Android, macOS): whether it renews, a billing issue, a trial. Null where
  /// the store has none, e.g. Pro bought on another platform.
  final ValueNotifier<SubscriptionTerm?> storeTerm = ValueNotifier<SubscriptionTerm?>(null);

  /// The store's page for managing subscriptions, when it gave one.
  String? storeManagementUrl;

  IAPManager._();

  /// Signed into a real account. The anonymous session the support chat
  /// creates on demand doesn't count, so a store-bought Pro user who never
  /// signed in keeps the local (RevenueCat) entitlement path.
  bool get isLoggedIn => hasAccount(core.supabase.auth.currentSession?.user);

  /// The Supabase user id RevenueCat was last logged in as by
  /// [_handleAuthStateChange]; null while there's no account.
  String? _revenueCatUserId;

  /// Pure decision behind the RevenueCat login in [_handleAuthStateChange]:
  /// who to log in as and whether to run `sync-subscriptions`, or null to
  /// leave RevenueCat alone. Anonymous users are never used as a RevenueCat
  /// identity. Syncs on a fresh sign-in or launch, and whenever the account
  /// differs from [previousUserId] — e.g. an anonymous session that just
  /// became an account by linking an email keeps its id but only fires
  /// `userUpdated`.
  @visibleForTesting
  static ({String userId, bool performSync})? revenueCatLogin({
    required AuthChangeEvent event,
    required User? user,
    required String? previousUserId,
  }) {
    if (user == null || !hasAccount(user)) return null;
    final freshSession = event == AuthChangeEvent.initialSession || event == AuthChangeEvent.signedIn;
    return (userId: user.id, performSync: freshSession || user.id != previousUserId);
  }

  /// Whether the logged-in user is flagged for the Shorebird beta update
  /// track (a manual `beta_access` entitlement granted from the admin
  /// dashboard). Reads the cached entitlements; false when logged out or
  /// before the first entitlements fetch.
  bool get isBetaTester => (isLoggedIn && entitlements.hasActive(betaAccessProductKey) || kDebugMode);

  /// Local-build switch (`--dart-define=BIKECONTROL_LOCAL_PRO=true`): treats this
  /// build as Pro on this device, so the Pro-gated features, the trial gate and
  /// the daily command limit stay out of the way. It only changes what the app
  /// itself decides; it never claims an entitlement from the account, so
  /// anything the server grants (settings sync) still needs a real
  /// subscription — see [hasVerifiedSubscription]. Off by default.
  static const bool _localPro = bool.fromEnvironment('BIKECONTROL_LOCAL_PRO');

  /// The subscription as the account or the local Pro flag record it, ignoring
  /// [_localPro]. Server-side features gate on this one.
  bool get hasVerifiedSubscription =>
      (isLoggedIn && (entitlements.hasActive(premiumMonthlyProductKey)) ||
          entitlements.hasActive(premiumYearlyProductKey)) ||
      (!isLoggedIn && isLocalPro.value);

  bool get hasActiveSubscription => _localPro || hasVerifiedSubscription;

  bool get isProEnabled => _localPro || (hasActiveSubscription && (isLoggedIn || (!isLoggedIn && isLocalPro.value)));

  bool get isProEnabledForCurrentDevice {
    if (_localPro && !_unregisteredDeviceForTesting) return true;
    if (!_isInitialized) return false;
    if (_unregisteredDeviceForTesting) return false;
    return hasActiveSubscription &&
        ((isLoggedIn && entitlements.isRegisteredDevice) || (!isLoggedIn && isLocalPro.value));
  }

  /// Pro is on the account but this device is not registered for it, so the
  /// Pro-gated features stay off here. Riders in this state used to see only
  /// "Pro (unregistered device)" in the title bar and wrote in believing Pro
  /// was broken — the home banner, the virtual-shifting notice and the
  /// post-purchase dialog all key off this.
  bool get isProButDeviceUnregistered => _isInitialized && isProEnabled && !isProEnabledForCurrentDevice;

  bool get isProEnabledForCurrentDeviceOrDidPurchaseOld {
    if (!_isInitialized) return false;
    return isProEnabledForCurrentDevice || hasPurchasedBefore50RVC;
  }

  /// Test-only: makes [isProEnabledForCurrentDevice] report false while
  /// [isProEnabled] holds — the state a logged-in rider lands in when the
  /// device could not be registered (platform limit reached). Nothing in the
  /// production paths sets it.
  bool _unregisteredDeviceForTesting = false;

  /// Test-only: force the Pro entitlement state so Pro-gated actions/UI can be
  /// exercised without a live subscription or device registration.
  /// [registeredDevice] false yields "Pro on the account, not on this device".
  @visibleForTesting
  void setProForTesting({required bool enabled, bool registeredDevice = true}) {
    _isInitialized = true;
    _unregisteredDeviceForTesting = enabled && !registeredDevice;
    isLocalPro.value = enabled;
  }

  bool get hasPurchasedBefore50RVC =>
      isPurchased.value &&
      ((_revenueCatService?.hasPurchasedBefore50 ?? false) || (_windowsIapService?.hasPurchasedBefore50 ?? false));

  /// The current Pro period, from the store when it knows (it says whether
  /// the subscription renews), else from the account's entitlement, which
  /// carries only the date. Null without an active subscription.
  SubscriptionTerm? get subscriptionTerm {
    if (!hasActiveSubscription) return null;
    final fromStore = storeTerm.value;
    if (fromStore != null) return fromStore;
    Entitlement? latest;
    for (final e in entitlements.current) {
      if (!e.isActive || (e.productKey != premiumMonthlyProductKey && e.productKey != premiumYearlyProductKey)) {
        continue;
      }
      if (latest == null || (e.activeUntil?.isAfter(latest.activeUntil ?? DateTime(0)) ?? false)) latest = e;
    }
    return latest == null ? null : SubscriptionTerm.fromEntitlement(latest);
  }

  /// Test-only: stage the store's record of the subscription.
  @visibleForTesting
  void setSubscriptionTermForTesting(SubscriptionTerm? term) => storeTerm.value = term;

  /// Where this build sells and restores purchases.
  PurchaseChannel get purchaseChannel {
    if (kIsWeb) return PurchaseChannel.none;
    if (_purchaseChannelForTesting case final channel?) return channel;
    if (isUsingRevenueCat) {
      if (HostPlatform.isIOS) return PurchaseChannel.appStore;
      if (HostPlatform.isMacOS) return PurchaseChannel.macAppStore;
      if (HostPlatform.isAndroid) return PurchaseChannel.playStore;
    }
    if (isWindows) return isOutsideStoreWindowsBuild ? PurchaseChannel.windowsDirect : PurchaseChannel.microsoftStore;
    return PurchaseChannel.none;
  }

  PurchaseChannel? _purchaseChannelForTesting;

  /// Test-only: stage the build's purchase channel (null restores the real one).
  @visibleForTesting
  set purchaseChannelForTesting(PurchaseChannel? channel) => _purchaseChannelForTesting = channel;

  DateTime? get premiumActiveUntil =>
      entitlements.activeUntil(premiumMonthlyProductKey) ?? entitlements.activeUntil(premiumYearlyProductKey);

  /// Initialize the IAP manager.
  Future<void> initialize() async {
    if (_isInitialized) return;

    final prefs = FlutterSecureStorage(aOptions: AndroidOptions());
    await entitlements.initialize();
    entitlements.addListener(_onEntitlementsChanged);
    _bindAuthLifecycle();

    if (kIsWeb) {
      _isInitialized = true;
      return;
    }

    try {
      if (Platform.isWindows) {
        _windowsIapService = WindowsIAPService(
          prefs,
          entitlementsService: entitlements,
        );
        await _windowsIapService!.initialize();
      } else if (Platform.isIOS || Platform.isMacOS || Platform.isAndroid) {
        _revenueCatService = RevenueCatService(
          prefs,
          isPurchasedNotifier: isPurchased,
          isProNotifier: isLocalPro,
          termNotifier: storeTerm,
          onManagementUrl: (url) => storeManagementUrl = url,
          getDailyCommandLimit: () => dailyCommandLimit,
          setDailyCommandLimit: (limit) => dailyCommandLimit = limit,
          entitlementsService: entitlements,
          premiumProductKeyMonthly: premiumMonthlyProductKey,
          premiumProductKeyYearly: premiumYearlyProductKey,
        );
        await _revenueCatService!.initialize();
      } else {
        throw UnsupportedError('Unsupported platform for IAP: ${Platform.operatingSystem}');
      }

      await entitlements.refresh();
      _syncPurchaseFlagFromEntitlements();
      _isInitialized = true;
    } catch (e) {
      debugPrint('Error initializing IAP manager: $e');
      _isInitialized = true;
    }
  }

  /// Called on app start when a session may already exist.
  Future<void> refreshEntitlementsOnAppStart() async {
    await entitlements.refresh(force: true);
    _syncPurchaseFlagFromEntitlements();
  }

  /// Called on app resume to refresh stale entitlement cache.
  Future<void> refreshEntitlementsOnResume() async {
    await entitlements.refresh();
    _syncPurchaseFlagFromEntitlements();
  }

  /// Check if the trial period has started.
  bool get hasTrialStarted {
    if (isOutsideStoreWindowsBuild) {
      return true;
    }
    if (_revenueCatService != null) {
      return _revenueCatService!.hasTrialStarted;
    } else if (_windowsIapService != null) {
      return _windowsIapService!.hasTrialStarted;
    }
    return false;
  }

  /// Start the trial period.
  Future<void> startTrial() async {
    if (_revenueCatService != null) {
      await _revenueCatService!.startTrial();
    }
  }

  /// Get the number of days remaining in the trial.
  int get trialDaysRemaining {
    if (isOutsideStoreWindowsBuild) {
      return 0;
    }
    if (_revenueCatService != null) {
      return _revenueCatService!.trialDaysRemaining;
    } else if (_windowsIapService != null) {
      return _windowsIapService!.trialDaysRemaining;
    }
    return 0;
  }

  /// Check if the trial has expired.
  bool get isTrialExpired {
    // Before IAP is initialized there is no trial to have expired yet, and the
    // pro/subscription checks below reach into Supabase which isn't wired up
    // until startup completes. Mirror isProEnabledForCurrentDevice's guard.
    if (!_isInitialized) return false;
    if (isProEnabled) {
      return false;
    }
    if (isOutsideStoreWindowsBuild && !isPurchased.value) {
      return true;
    }
    if (_revenueCatService != null) {
      return _revenueCatService!.isTrialExpired;
    } else if (_windowsIapService != null) {
      return _windowsIapService!.isTrialExpired;
    }
    return false;
  }

  /// Check if the user can execute a command.
  bool get canExecuteCommand {
    if (isProEnabled) return true;
    if (_revenueCatService == null && _windowsIapService == null) return true;

    if (_revenueCatService != null) {
      return _revenueCatService!.canExecuteCommand;
    } else if (_windowsIapService != null) {
      return _windowsIapService!.canExecuteCommand;
    }
    return true;
  }

  /// Get the number of commands remaining today (for free tier after trial).
  int get commandsRemainingToday {
    if (isProEnabled) {
      return -1;
    }
    if (_revenueCatService != null) {
      return _revenueCatService!.commandsRemainingToday;
    } else if (_windowsIapService != null) {
      return _windowsIapService!.commandsRemainingToday;
    }
    return -1;
  }

  /// Get the daily command count.
  int get dailyCommandCount {
    if (_revenueCatService != null) {
      return _revenueCatService!.dailyCommandCount;
    } else if (_windowsIapService != null) {
      return _windowsIapService!.dailyCommandCount;
    }
    return 0;
  }

  /// Increment the daily command count.
  Future<void> incrementCommandCount() async {
    if (isProEnabled) {
      return;
    }
    if (_revenueCatService != null) {
      await _revenueCatService!.incrementCommandCount();
    } else if (_windowsIapService != null) {
      await _windowsIapService!.incrementCommandCount();
    }
  }

  /// Get a status message for the user.
  String getStatusMessage() {
    final l10n = AppLocalizations.current;
    if (kIsWeb) {
      return "Web";
    } else if (isProEnabledForCurrentDevice) {
      final term = subscriptionTerm;
      return (term == null ? null : subscriptionTermLine(l10n, term)) ?? 'Pro';
    } else if (isProEnabled) {
      return l10n.proNotOnThisDevice;
    } else if (isPurchased.value) {
      return l10n.fullVersion;
    } else if (isOutsideStoreWindowsBuild) {
      return l10n.trialExpired(dailyCommandLimit);
    } else if (!hasTrialStarted) {
      return l10n.trialDaysAvailable(
        _revenueCatService?.trialDaysRemaining ?? _windowsIapService?.trialDaysRemaining ?? 0,
      );
    } else if (!isTrialExpired) {
      return l10n.trialDaysRemaining(trialDaysRemaining);
    } else {
      return l10n.commandsRemainingToday(commandsRemainingToday, dailyCommandLimit);
    }
  }

  /// Purchase the full version.
  Future<void> purchaseFullVersion(BuildContext context, {bool fromPaywall = false}) async {
    if (isOutsideStoreWindowsBuild) {
      if (!fromPaywall) {
        return _showPaywall(context, false);
      }
      return _windowsIapService!.purchaseFullVersionViaStripe(context);
    }
    // The in-app paywall is what riders see on every platform — RevenueCat's
    // hosted sheet is only reached as a fallback when an offering has no
    // matching package (see RevenueCatService.purchase*). `fromPaywall` is
    // the paywall's own buttons asking for the direct store purchase.
    if (!fromPaywall) {
      return _showPaywall(context, false);
    } else if (_revenueCatService != null) {
      return _revenueCatService!.purchaseFullVersion(
        context,
        directPurchase: fromPaywall,
      );
    } else if (_windowsIapService != null) {
      return _windowsIapService!.purchaseFullVersion();
    }
  }

  /// Purchase a subscription.
  Future<void> purchaseSubscription(
    BuildContext context, {
    SubscriptionPlan plan = SubscriptionPlan.monthly,
    bool fromPaywall = false,
  }) async {
    if (!fromPaywall) {
      return _showPaywall(context, true);
    } else if (_revenueCatService != null) {
      return _revenueCatService!.purchaseSubscription(
        context,
        directPurchase: fromPaywall,
        yearly: plan == SubscriptionPlan.yearly,
      );
    } else if (_windowsIapService != null) {
      return _windowsIapService!.purchaseSubscription(
        context,
        yearly: plan == SubscriptionPlan.yearly,
      );
    }
  }

  Future<void> _showPaywall(BuildContext context, bool subscription) async {
    // openDrawer needs a DrawerOverlay ancestor (Scaffold creates one) and does
    // `parentLayer!` in release, so a caller that hands us a context from above
    // its own Scaffold turns "Go Pro" into a bare "Null check operator used on
    // a null value" toast and the paywall never opens. Callers should pass a
    // context below the Scaffold, but the paywall is the last thing that should
    // break when one doesn't — fall back to a dialog, which only needs a
    // Navigator. Paywall already constrains and scrolls itself.
    if (DrawerOverlay.maybeFind(context) == null) {
      await showDialog<void>(
        context: context,
        builder: (c) => Paywall(defaultToFullVersion: !subscription),
      );
      return;
    }
    openDrawer(
      context: context,
      // The paywall scrolls, which swallows the drawer's own swipe-to-close —
      // SheetPullToDismiss restores it (pull down past the top).
      builder: (c) => SheetPullToDismiss(child: Paywall(defaultToFullVersion: !subscription)),
      position: OverlayPosition.bottom,
    );
  }

  /// Restore previous purchases. Resolves to whether the store found a
  /// purchase (Base or Pro); throws when the store could not be asked.
  Future<bool> restorePurchases() async {
    var restored = false;
    if (_revenueCatService != null) {
      restored = await _revenueCatService!.restorePurchases();
    }
    _syncPurchaseFlagFromEntitlements();
    return restored;
  }

  /// Check if RevenueCat is being used.
  bool get isUsingRevenueCat => _revenueCatService != null;

  /// Check if running on Windows
  bool get isWindows => _windowsIapService != null;

  bool get isOutsideStoreWindowsBuild =>
      !kIsWeb && defaultTargetPlatform == TargetPlatform.windows && WindowsStoreEnvironment.isOutsideStoreCached;

  /// Check if user is logged in (Windows Stripe requires this)
  bool get isWindowsLoggedIn => _windowsIapService?.isLoggedIn ?? false;

  /// Opens where the subscription is managed: the store's subscription
  /// settings (iOS, Android, macOS) or the Stripe billing portal (Windows).
  /// Returns false if user has no Stripe customer (should hide button)
  Future<bool> openBillingPortal(BuildContext context) async {
    if (_revenueCatService != null) {
      return _revenueCatService!.openBillingPortal(context, managementUrl: storeManagementUrl);
    } else if (_windowsIapService != null) {
      return _windowsIapService!.openBillingPortal(context);
    } else {
      return false;
    }
  }

  /// Check if user has a Stripe customer record (Windows only)
  Future<bool> hasStripeCustomer() async {
    if (_windowsIapService == null) return false;
    return _windowsIapService!.hasStripeCustomer();
  }

  /// Dispose the manager.
  void dispose() {
    _authSubscription?.cancel();
    entitlements.removeListener(_onEntitlementsChanged);
    _revenueCatService?.dispose();
    _windowsIapService?.dispose();
  }

  Future<void> reset(bool fullReset) async {
    isPurchased.value = false;
    await entitlements.clearCache();
    _windowsIapService?.reset();
    await _revenueCatService?.reset(fullReset);
  }

  Future<void> redeem(String purchaseId) async {
    if (_revenueCatService != null) {
      await _revenueCatService!.redeem(purchaseId);
      await entitlements.refresh(force: true);
      _syncPurchaseFlagFromEntitlements();
    }
  }

  void setAttributes() {
    _revenueCatService?.setAttributes();
  }

  void _bindAuthLifecycle() {
    _authSubscription ??= core.supabase.auth.onAuthStateChange.listen((data) {
      unawaited(_handleAuthStateChange(data.event, data.session));
    });
  }

  Future<void> _handleAuthStateChange(AuthChangeEvent event, Session? session) async {
    switch (event) {
      case AuthChangeEvent.initialSession:
      case AuthChangeEvent.signedIn:
      case AuthChangeEvent.tokenRefreshed:
      case AuthChangeEvent.userUpdated:
      case AuthChangeEvent.mfaChallengeVerified:
        final login = revenueCatLogin(event: event, user: session?.user, previousUserId: _revenueCatUserId);
        if (login != null) {
          _revenueCatUserId = login.userId;
          await _revenueCatService?.logInWithSupabaseUserId(login.userId, performSync: login.performSync);
        }
        await _revenueCatService?.setAttributes();
        await entitlements.refresh(force: true);
        _syncPurchaseFlagFromEntitlements();
        // A rider who tapped Buy on the Windows Stripe build while logged out was
        // sent to the login gate; a genuine `signedIn` is our cue to finish the
        // checkout they started. Skip token refreshes / the initial session,
        // which are not a fresh login and would fire on every launch.
        if (event == AuthChangeEvent.signedIn && isLoggedIn) {
          await _windowsIapService?.resumePendingPurchaseAfterLogin(isAlreadyPro: isProEnabled);
        }
        return;
      case AuthChangeEvent.signedOut:
      // ignore: deprecated_member_use
      case AuthChangeEvent.userDeleted:
        _revenueCatUserId = null;
        await _revenueCatService?.logOut();
        await entitlements.clearCache();
        // reset isPurchased value
        if (Platform.isWindows) {
          await _windowsIapService?.initialize();
        } else if (Platform.isIOS || Platform.isMacOS || Platform.isAndroid) {
          await _revenueCatService?.initialize();
        }
        return;
      case AuthChangeEvent.passwordRecovery:
        return;
    }
  }

  void _onEntitlementsChanged() {
    _syncPurchaseFlagFromEntitlements();
  }

  void _syncPurchaseFlagFromEntitlements() {
    if (isProEnabled) {
      isPurchased.value = true;
    } else if (isOutsideStoreWindowsBuild && entitlements.hasActive(fullVersionProductKey)) {
      isPurchased.value = true;
    }
  }

  /// Registers this device for the account's Pro subscription and refreshes
  /// the entitlements, so [isProEnabledForCurrentDevice] reflects the result.
  /// One call shared by the Registered Devices view, the home banner, the
  /// virtual-shifting notice and the post-purchase dialog. Throws
  /// [DeviceLimitReachedError] when the platform's device limit is reached —
  /// the rider then has to pick a device to revoke.
  Future<void> registerCurrentDevice() async {
    final platform = await deviceManagement.currentPlatform();
    final package = await PackageInfo.fromPlatform();
    await deviceManagement.registerCurrentDevice(
      deviceName: 'BikeControl ${platform?.toUpperCase() ?? ''}',
      appVersion: package.version,
    );
    await entitlements.refresh(force: true);
  }

  /// [featureName] names the gated feature in the upgrade dialog — see
  /// [showGoProDialog].
  Future<bool> ensureProForFeature(
    BuildContext context, {
    bool isAllowedForOldPurchases = false,
    String? featureName,
  }) async {
    if (isProEnabledForCurrentDevice || (isAllowedForOldPurchases && hasPurchasedBefore50RVC)) {
      return true;
    } else if (isProEnabled) {
      buildToast(title: AppLocalizations.of(context).currentDeviceIsNotRegistered);
      return isProEnabledForCurrentDevice;
    } else {
      await showGoProDialog(context, featureName: featureName);
    }
    return IAPManager.instance.hasActiveSubscription;
  }

  void setWinBoughtBefore50() {
    _windowsIapService?.setBoughtBefore50();
  }
}
