import 'package:bike_control/bluetooth/devices/cycplus/cycplus_bc2.dart';
import 'package:bike_control/bluetooth/devices/elite/elite_square.dart';
import 'package:bike_control/bluetooth/devices/elite/elite_sterzo.dart';
import 'package:bike_control/bluetooth/devices/gyroscope/gyroscope_steering.dart';
import 'package:bike_control/bluetooth/devices/openbikecontrol/protocol_parser.dart';
import 'package:bike_control/bluetooth/devices/shimano/shimano_di2.dart';
import 'package:bike_control/bluetooth/devices/stages/stages_smart_bike.dart';
import 'package:bike_control/bluetooth/devices/wahoo/wahoo_kickr_bike_shift.dart';
import 'package:bike_control/bluetooth/devices/wheeltop/wheeltop_eds.dart';
import 'package:bike_control/bluetooth/devices/zwift/constants.dart';
import 'package:bike_control/gen/l10n.dart';
import 'package:bike_control/widgets/keymap_explanation.dart';
import 'package:dartx/dartx.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';

enum InGameAction {
  shiftUp('Shift Up', icon: LucideIcons.badgePlus),
  shiftDown('Shift Down', icon: LucideIcons.badgeMinus),
  uturn('U-Turn', alternativeTitle: 'Down', icon: LucideIcons.arrowDownUp),
  tuck('Tuck', icon: LucideIcons.gauge),
  steerLeft(
    'Steer Left',
    alternativeTitle: 'Left',
    icon: LucideIcons.chevronsLeft,
    isLongPress: true,
    requiresHold: true,
  ),
  steerRight(
    'Steer Right',
    alternativeTitle: 'Right',
    icon: LucideIcons.chevronsRight,
    isLongPress: true,
    requiresHold: true,
  ),

  // mywhoosh
  cameraAngle('Change Camera Angle', possibleValues: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], icon: LucideIcons.video),
  emote('Emote', possibleValues: [1, 2, 3, 4, 5, 6], icon: LucideIcons.smile),
  toggleUi('Toggle UI', icon: LucideIcons.toggleLeft),
  navigateLeft('Navigate Left', icon: LucideIcons.cornerUpLeft),
  navigateRight('Navigate Right', icon: LucideIcons.cornerUpRight),
  increaseResistance('Increase Resistance', icon: LucideIcons.chartNoAxesColumnIncreasing),
  decreaseResistance('Decrease Resistance', icon: LucideIcons.chartNoAxesColumnDecreasing),

  // zwift
  openActionBar('Open Action Bar', alternativeTitle: 'Up', icon: LucideIcons.squareMenu, isLongPress: true),
  usePowerUp('Use Power-Up', icon: LucideIcons.zap, isLongPress: true),
  select('Select', icon: LucideIcons.mousePointerClick),
  back('Back', icon: LucideIcons.arrowLeft),
  rideOnBomb('Ride On Bomb', icon: LucideIcons.bomb, isLongPress: true),

  // rouvy
  kudos('Kudos', icon: LucideIcons.thumbsUp),
  pause('Pause/Resume', icon: LucideIcons.pause, isLongPress: true),

  // headwind
  headwindSpeed(
    'Headwind Speed',
    possibleValues: [0, 25, 50, 75, 100],
    icon: LucideIcons.wind,
    isOutsideTrainerApp: true,
  ),
  headwindSpeedInc('Headwind Speed Increase', icon: LucideIcons.wind, isOutsideTrainerApp: true),
  headwindSpeedDec('Headwind Speed Decrease', icon: LucideIcons.wind, isOutsideTrainerApp: true),
  headwindSpeedCyclicInc('Headwind Speed Cyclic Increase', icon: LucideIcons.wind, isOutsideTrainerApp: true),
  headwindSpeedCyclicDec('Headwind Speed Cyclic Decrease', icon: LucideIcons.wind, isOutsideTrainerApp: true),
  headwindHeartRateMode('Headwind HR Mode', icon: LucideIcons.heart, isOutsideTrainerApp: true),

  // Incline devices (KICKR Climb, Elite Rizer)
  inclineIncrease('Incline Up', icon: LucideIcons.trendingUp, isOutsideTrainerApp: true),
  inclineDecrease('Incline Down', icon: LucideIcons.trendingDown, isOutsideTrainerApp: true),
  inclineZero('Incline Flatten (0%)', icon: LucideIcons.minus, isOutsideTrainerApp: true),
  inclineAutoMode('Incline Auto (Follow Grade)', icon: LucideIcons.mountain, isOutsideTrainerApp: true),

  // openbikecontrol
  up('Up', icon: LucideIcons.arrowUp),
  down('Down', icon: LucideIcons.arrowDown),
  home('Home', icon: LucideIcons.house),
  menu('Menu', icon: LucideIcons.menu),
  gearSet('Gear Set', icon: LucideIcons.gauge),
  pushToTalk('Push to Talk', icon: LucideIcons.mic, requiresHold: true),
  skipInterval('Skip Interval', icon: LucideIcons.skipForward),
  previousInterval('Previous Interval', icon: LucideIcons.skipBack),
  lap('Lap', icon: LucideIcons.timer),
  resume('Resume', icon: LucideIcons.play),
  changeMode('Change Mode', icon: LucideIcons.repeat),
  takeBreak('Take a Break', icon: LucideIcons.coffee),
  joinRider('Join Rider', icon: LucideIcons.userPlus),
  changeRoute('Change Route', icon: LucideIcons.signpost),
  mapToggle('Map Toggle', icon: LucideIcons.map),
  spectateRider('Spectate Rider', icon: LucideIcons.eye),

  // trainer control
  trainerSwitchMode('Trainer: Switch ERG/SIM', icon: LucideIcons.repeat, isOutsideTrainerApp: true),
  trainerIntensityUp('Trainer: Intensity Up', icon: LucideIcons.trendingUp, isOutsideTrainerApp: true),
  trainerIntensityDown('Trainer: Intensity Down', icon: LucideIcons.trendingDown, isOutsideTrainerApp: true),
  workoutPauseResume('Workout: Pause/Resume', icon: LucideIcons.pause, isOutsideTrainerApp: true),
  frontShift('Front Shift (Chainring)', icon: LucideIcons.arrowLeftRight, isOutsideTrainerApp: true),

  // device / system
  calibratePhoneSteering('Calibrate Steering', icon: LucideIcons.wrench, isOutsideTrainerApp: true),
  screenRecording('Record Screen', icon: LucideIcons.video, isOutsideTrainerApp: true);

  final String englishTitle;

  /// The trigger a button gets when it is first mapped to this action.
  final bool isLongPress;

  /// The action only does something while the button is held: the trainer
  /// app steers (or keeps the microphone open) for as long as it sees the
  /// press. A single or double click sends the press and its release back to
  /// back, so on a click it does next to nothing — it belongs on a long press.
  final bool requiresHold;
  final bool isOutsideTrainerApp;
  final IconData? icon;
  final String? alternativeTitle;
  final List<int>? possibleValues;

  const InGameAction(
    this.englishTitle, {
    this.possibleValues,
    this.isOutsideTrainerApp = false,
    this.alternativeTitle,
    this.icon,
    this.isLongPress = false,
    this.requiresHold = false,
  });

  /// Localized label shown in the UI (falls back to [englishTitle]).
  String get title {
    final l = AppLocalizations.current;
    return switch (this) {
      InGameAction.shiftUp => l.actionShiftUp,
      InGameAction.shiftDown => l.actionShiftDown,
      InGameAction.uturn => l.actionUturn,
      InGameAction.tuck => l.actionTuck,
      InGameAction.steerLeft => l.actionSteerLeft,
      InGameAction.steerRight => l.actionSteerRight,
      InGameAction.cameraAngle => l.actionCameraAngle,
      InGameAction.emote => l.actionEmote,
      InGameAction.toggleUi => l.actionToggleUi,
      InGameAction.navigateLeft => l.actionNavigateLeft,
      InGameAction.navigateRight => l.actionNavigateRight,
      InGameAction.increaseResistance => l.actionIncreaseResistance,
      InGameAction.decreaseResistance => l.actionDecreaseResistance,
      InGameAction.openActionBar => l.actionOpenActionBar,
      InGameAction.usePowerUp => l.actionUsePowerUp,
      InGameAction.select => l.actionSelect,
      InGameAction.back => l.actionBack,
      InGameAction.rideOnBomb => l.actionRideOnBomb,
      InGameAction.kudos => l.actionKudos,
      InGameAction.pause => l.actionPause,
      InGameAction.headwindSpeed => l.actionHeadwindSpeed,
      InGameAction.headwindSpeedInc => l.actionHeadwindSpeedInc,
      InGameAction.headwindSpeedDec => l.actionHeadwindSpeedDec,
      InGameAction.headwindSpeedCyclicInc => l.actionHeadwindSpeedCyclicInc,
      InGameAction.headwindSpeedCyclicDec => l.actionHeadwindSpeedCyclicDec,
      InGameAction.headwindHeartRateMode => l.actionHeadwindHeartRateMode,
      InGameAction.inclineIncrease => l.actionInclineIncrease,
      InGameAction.inclineDecrease => l.actionInclineDecrease,
      InGameAction.inclineZero => l.actionInclineZero,
      InGameAction.inclineAutoMode => l.actionInclineAutoMode,
      InGameAction.up => l.actionUp,
      InGameAction.down => l.actionDown,
      InGameAction.home => l.actionHome,
      InGameAction.menu => l.actionMenu,
      InGameAction.gearSet => l.actionGearSet,
      InGameAction.pushToTalk => l.actionPushToTalk,
      InGameAction.skipInterval => l.actionSkipInterval,
      InGameAction.previousInterval => l.actionPreviousInterval,
      InGameAction.lap => l.actionLap,
      InGameAction.resume => l.actionResume,
      InGameAction.changeMode => l.actionChangeMode,
      InGameAction.takeBreak => l.actionTakeBreak,
      InGameAction.joinRider => l.actionJoinRider,
      InGameAction.changeRoute => l.actionChangeRoute,
      InGameAction.mapToggle => l.actionMapToggle,
      InGameAction.spectateRider => l.actionSpectateRider,
      InGameAction.trainerSwitchMode => l.actionTrainerSwitchMode,
      InGameAction.trainerIntensityUp => l.actionTrainerIntensityUp,
      InGameAction.trainerIntensityDown => l.actionTrainerIntensityDown,
      InGameAction.workoutPauseResume => l.actionWorkoutPauseResume,
      InGameAction.frontShift => l.actionFrontShift,
      InGameAction.calibratePhoneSteering => l.actionCalibratePhoneSteering,
      InGameAction.screenRecording => l.actionScreenRecording,
    };
  }

  @override
  String toString() => englishTitle;
}

const trainerActions = [
  InGameAction.shiftUp,
  InGameAction.shiftDown,
  InGameAction.trainerSwitchMode,
  InGameAction.trainerIntensityUp,
  InGameAction.trainerIntensityDown,
  InGameAction.workoutPauseResume,
  InGameAction.frontShift,
];

const trainerOnlyActions = [
  InGameAction.trainerSwitchMode,
  InGameAction.trainerIntensityUp,
  InGameAction.trainerIntensityDown,
  InGameAction.workoutPauseResume,
];

class ControllerButton {
  static const int _deviceIdSuffixLength = 4;
  static const _unset = Object();
  final String name;
  final int? identifier;
  final InGameAction? action;
  final Color? color;
  final IconData? icon;
  final String? sourceDeviceId;

  /// The button's own short label, where [initials] would say something
  /// the picture already shows — "P" for a pod's paddle, not "P→".
  final String? label;

  const ControllerButton(
    this.name, {
    this.color,
    this.icon,
    this.label,
    this.identifier,
    this.action,
    this.sourceDeviceId,
  });

  ControllerButton copyWith({
    String? name,
    int? identifier,
    InGameAction? action,
    Color? color,
    IconData? icon,
    String? label,
    Object? sourceDeviceId = _unset,
  }) {
    final newSourceDeviceId = sourceDeviceId == _unset ? this.sourceDeviceId : sourceDeviceId as String?;

    return ControllerButton(
      name ?? this.name,
      color: color ?? this.color,
      icon: icon ?? this.icon,
      label: label ?? this.label,
      identifier: identifier ?? this.identifier,
      action: action ?? this.action,
      sourceDeviceId: newSourceDeviceId,
    );
  }

  String get displayName {
    if (sourceDeviceId == null) {
      return name.splitByUpperCase();
    }

    final shortenedId = sourceDeviceId!.length <= _deviceIdSuffixLength
        ? sourceDeviceId!
        : sourceDeviceId!.substring(sourceDeviceId!.length - _deviceIdSuffixLength);
    return '${name.splitByUpperCase()} (${shortenedId.toUpperCase()})';
  }

  /// Uppercase initials derived from the camelCase [name].
  /// Example: `sideButtonLeft` → `SBL`, `navigationUp` → `NU`, `a` → `A`.
  /// Uses the raw [name] (not [displayName]) so the multi-device `(HASH)`
  /// suffix never leaks into the label.
  String get initials {
    // Generic gamepads send numbered keys ("button-7", "axis-1_-1"); keep the
    // number, or every button reads "B" and every axis "A".
    final generic = _genericKeyPattern.firstMatch(name);
    if (generic != null) {
      final direction = switch (generic.group(3)) {
        '1' => '+',
        '-1' => '−',
        _ => '',
      };
      return '${generic.group(1)![0].toUpperCase()}${generic.group(2)}$direction';
    }
    final words = name.splitByUpperCase().split(' ');
    return words
        .where((w) => w.isNotEmpty)
        .map(
          (w) => w
              .replaceAll('Up', '↑')
              .replaceAll('Right', '→')
              .replaceAll('Down', '↓')
              .replaceAll('Left', '←')[0]
              .toUpperCase(),
        )
        .join();
  }

  static final _genericKeyPattern = RegExp(r'^(button|axis)-(\d+)(?:_(-?\d+))?$');

  /// What the button's face reads when it has no icon.
  String get shortLabel => label ?? initials;

  @override
  String toString() {
    return name;
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ControllerButton &&
          runtimeType == other.runtimeType &&
          name == other.name &&
          identifier == other.identifier &&
          action == other.action &&
          color == other.color &&
          icon == other.icon &&
          label == other.label &&
          sourceDeviceId == other.sourceDeviceId;

  @override
  int get hashCode => Object.hash(name, action, identifier, color, icon, label, sourceDeviceId);

  static List<ControllerButton> get values => [
    ...SterzoButtons.values,
    ...GyroscopeSteeringButtons.values,
    ...ZwiftButtons.values,
    ...EliteSquareButtons.values,
    ...WahooKickrShiftButtons.values,
    ...StagesSmartBikeButtons.values,
    ...CycplusBc2Buttons.values,
    ...WheeltopEdsButtons.values,
    ...ShimanoDi2Buttons.values,
    ...OpenBikeProtocolParser.BUTTON_NAMES.values,
  ].distinct().toList();
}
