import 'dart:async';
import 'dart:io';

import 'package:bike_control/bluetooth/ble_command_queue_config.dart';
import 'package:bike_control/bluetooth/devices/bluetooth_device.dart';
import 'package:bike_control/bluetooth/devices/gamepad/gamepad_device.dart';
import 'package:bike_control/bluetooth/devices/gyroscope/gyroscope_steering.dart';
import 'package:bike_control/bluetooth/devices/hid/hid_device.dart';
import 'package:bike_control/bluetooth/devices/proxy/proxy_device.dart';
import 'package:bike_control/bluetooth/devices/sensors/ble_sensor_device.dart';
import 'package:bike_control/bluetooth/devices/wahoo/wahoo_kickr_climb.dart';
import 'package:bike_control/bluetooth/devices/wahoo/wahoo_kickr_headwind.dart';
import 'package:bike_control/bluetooth/devices/zwift/zwift_clickv2_left_side.dart';
import 'package:bike_control/bluetooth/devices/zwift/zwift_unlock.dart';
import 'package:bike_control/bluetooth/inactivity_disconnector.dart';
import 'package:bike_control/bluetooth/incline/incline_controller.dart';
import 'package:bike_control/bluetooth/incline/incline_sink.dart';
import 'package:bike_control/bluetooth/incline/manual_incline_device.dart';
import 'package:bike_control/bluetooth/support_log_buffer.dart';
import 'package:bike_control/bluetooth/wifi_trainer_scanner.dart';
import 'package:bike_control/gen/l10n.dart';
import 'package:bike_control/main.dart';
import 'package:bike_control/models/remembered_device.dart';
import 'package:bike_control/services/sensors/broadcast_controller.dart';
import 'package:bike_control/services/sensors/health_kit_channel.dart';
import 'package:bike_control/services/sensors/health_kit_sensor_source.dart';
import 'package:bike_control/services/sensors/sensor_bridge_binding.dart';
import 'package:bike_control/services/sensors/sensor_quantity.dart';
import 'package:bike_control/services/sensors/sensor_sink_controller.dart';
import 'package:bike_control/services/sensors/sensor_sink_sync.dart';
import 'package:bike_control/services/sensors/sensor_source.dart';
import 'package:bike_control/services/sensors/standalone_sensor_lifecycle.dart';
import 'package:bike_control/utils/core.dart';
import 'package:bike_control/utils/iap/iap_manager.dart';
import 'package:bike_control/utils/interpreter.dart';
import 'package:bike_control/utils/requirements/android.dart';
import 'package:dartx/dartx.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart' show PlatformException;
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:gamepads/gamepads.dart';
import 'package:prop/emulators/definitions/fitness_bike_definition.dart';
import 'package:prop/emulators/definitions/sensor_definition.dart';
import 'package:prop/prop.dart' hide Set;
import 'package:universal_ble/universal_ble.dart';

import 'devices/base_device.dart';
import 'devices/zwift/constants.dart';
import 'messages/notification.dart';

class Connection {
  final devices = <BaseDevice>[];

  /// Apple Health as a heart-rate source. Non-null only on iOS with Health
  /// data available (see the SensorHub wiring in [initialize]); tests inject
  /// one over a fake channel. Its existence IS the "is HealthKit supported"
  /// signal the signals grid reads — there is deliberately no second flag.
  HealthKitSensorSource? healthKitSource;

  bool get isHealthKitConnected =>
      core.sensors.sources.any((s) => s.id == HealthKitSensorSource.sourceId);

  /// The Broadcast switch for the no-trainer path. Constructed in
  /// [initialize] (this file cannot be built in a unit test — see
  /// `SensorSinkSync`'s own doc comment for why that class was pulled out
  /// instead), so it is null only in the brief window before `initialize`
  /// runs; tests assign their own directly.
  BroadcastController? broadcast;

  /// Whether a trainer app is actually subscribed to the standalone sensor
  /// peripheral (the "BikeControl" advertisement the no-trainer path stands
  /// up). Mirrors the standalone emulator's own `isConnected` — assigned in
  /// [initialize], so the field itself is stable and can be listened to
  /// before then; the placeholder it starts as simply never flips.
  ValueListenable<bool> get standaloneClientConnected => _standaloneClientConnected;
  ValueListenable<bool> _standaloneClientConnected = ValueNotifier(false);

  /// Tests stand in for the emulator here; production only ever assigns it
  /// once, in [initialize].
  @visibleForTesting
  set standaloneClientConnected(ValueListenable<bool> value) => _standaloneClientConnected = value;

  /// The connected app's name for the Sensors card ("MyWhoosh connected"),
  /// or null while nothing is subscribed. The standalone peripheral does not
  /// learn who paired it, so the rider's chosen trainer app stands in — the
  /// one app they told BikeControl they would be riding in.
  String? get standaloneClientName => _standaloneClientConnected.value ? core.settings.getTrainerApp()?.name : null;

  /// Whether the shared trainer bridge (the FTMS composite) is currently
  /// advertising. `SensorSinkSync` reads the listenable form
  /// (`ftmsEmulator.isStarted`) directly; this plain getter is for callers
  /// that just need the current value (Task 5's Broadcast UI gating).
  bool get isBridgeRunning => ftmsEmulator.isStarted.value;

  List<BluetoothDevice> get bluetoothDevices => devices.whereType<BluetoothDevice>().toList();
  List<ProxyDevice> get proxyDevices => devices.whereType<ProxyDevice>().toList();
  List<GamepadDevice> get gamepadDevices => devices.whereType<GamepadDevice>().toList();
  List<GyroscopeSteering> get gyroscopeDevices => devices.whereType<GyroscopeSteering>().toList();
  List<WahooKickrHeadwind> get accessories => devices.whereType<WahooKickrHeadwind>().toList();
  List<WahooKickrClimb> get climbAccessories => devices.whereType<WahooKickrClimb>().toList();
  List<ManualInclineDevice> get inclineDevices => devices.whereType<ManualInclineDevice>().toList();
  List<BaseDevice> get controllerDevices => [
    ...bluetoothDevices.where((d) => d is! Accessory && d is! ProxyDevice),
    ...gamepadDevices,
    ...gyroscopeDevices,
    ...devices.whereType<HidDevice>(),
  ];

  /// The same physical trainer listed a second time over the other transport
  /// — the WiFi (DirCon) entry of a Bluetooth-discovered trainer, or vice
  /// versa. Twins share one [ProxyDevice.trainerKey], so one tap's consent and
  /// settings cover both; what must never be shared is a live upstream, or the
  /// two paths fight over resistance. Null when the trainer is listed once.
  ProxyDevice? twinOf(ProxyDevice device) => proxyDevices.firstOrNullWhere(
    (other) =>
        !identical(other, device) && other.trainerKey == device.trainerKey && other.isWifiUpstream != device.isWifiUpstream,
  );

  var _androidNotificationsSetup = false;

  final _connectionQueue = <BaseDevice>[];
  var _handlingConnectionQueue = false;

  final Map<BaseDevice, StreamSubscription<BaseNotification>> _streamSubscriptions = {};
  final StreamController<BaseNotification> _actionStreams = StreamController<BaseNotification>.broadcast();
  Stream<BaseNotification> get actionStream => _actionStreams.stream;

  /// High-level app events (shifts, ERG targets, mode changes, handled errors)
  /// — the "Logs:" section of the support bundle. Kept in its own buffer so the
  /// verbose wire trace can never evict it (see [lastTraceEntries]).
  final SupportLogBuffer _appLog = SupportLogBuffer(500);
  List<({DateTime date, String entry})> get lastLogEntries => _appLog.entries;

  /// Verbose DirCon/trainer wire trace (`IN>`/`OUT<`/`trainer>`/`trainer<`),
  /// recorded for everyone from [startLogCapture] on. Separate from
  /// [lastLogEntries] so a few dozen frames per second can't flush the
  /// high-level events a support bundle needs — a beta bundle used to arrive
  /// as pure wire trace with every shift/ERG/control line gone. Deliberately
  /// not gated on any entitlement: the beta gate this used to have only
  /// resolved once IAP/Supabase finished initialising — minutes into a session
  /// on a cold start — and silently dropped exactly the
  /// connect/handshake/first-ride window a support bundle exists to show.
  final SupportLogBuffer _traceLog = SupportLogBuffer(2000);
  List<({DateTime date, String entry})> get lastTraceEntries => _traceLog.entries;

  void _appendLogEntry(String entry) => _appLog.add(entry);

  bool _logCaptureStarted = false;

  /// Start buffering [LogNotification]s (and, for beta testers, the verbose
  /// trace) into [lastLogEntries] independently of the full [initialize], which
  /// only runs once the app content mounts. Called at startup so handled errors
  /// during the bootstrap — before [initialize] — still reach the support and
  /// startup-recovery log bundle. Idempotent.
  void startLogCapture() {
    if (_logCaptureStarted) return;
    _logCaptureStarted = true;

    actionStream.listen((log) => _appendLogEntry(log.toString()));

    // The verbose DirCon/trainer wire trace, in its OWN buffer ([_traceLog])
    // so a high-rate trace never evicts the high-level events in
    // [lastLogEntries]. A release build has no console to read
    // `IN>`/`OUT<`/`trainer<` from, so this is the only way that traffic
    // reaches a support bundle. The string is already built for every trace
    // call once this sink is set, so recording it costs nothing beyond the
    // bounded buffer.
    Logger.onTrace = _traceLog.add;

    // High-level lines from inside prop (e.g. the KICKR tilt control point's
    // answers) belong with the shifts and ERG targets in "Logs:". prop's
    // Logger.info never gets here: it only prints in a debug build.
    Logger.onEvent = _appendLogEntry;
  }

  final Map<BaseDevice, StreamSubscription<bool>> _connectionSubscriptions = {};
  final StreamController<BaseDevice> _connectionStreams = StreamController<BaseDevice>.broadcast();
  Stream<BaseDevice> get connectionStream => _connectionStreams.stream;
  final StreamController<BluetoothDevice> _rssiConnectionStreams = StreamController<BluetoothDevice>.broadcast();
  Stream<BluetoothDevice> get rssiConnectionStream => _rssiConnectionStreams.stream;

  final _lastScanResult = <BleDevice>[];
  final ValueNotifier<bool> hasDevices = ValueNotifier(false);
  final ValueNotifier<bool> isScanning = ValueNotifier(false);

  /// Ids of devices on the ignore list, or disconnected for this session,
  /// that the current scan has seen. They are still never added or connected —
  /// this only lets the screens tell a rider whose controller "won't show up"
  /// that it is in fact ignored. Cleared when a scan starts; ids leave it when
  /// they are un-ignored or reconnected.
  final ValueNotifier<Set<String>> ignoredDevicesNearby = ValueNotifier(const {});

  /// Drops ids from [ignoredDevicesNearby] that are no longer on the ignore
  /// list. Called whenever the ignore list shrinks.
  void pruneIgnoredDevicesNearby() {
    if (ignoredDevicesNearby.value.isEmpty) return;
    final stillIgnored = {
      ...core.settings.getIgnoredDevices().map((d) => d.id),
      ...disconnectedForSession.value.keys,
    };
    final pruned = ignoredDevicesNearby.value.intersection(stillIgnored);
    if (pruned.length != ignoredDevicesNearby.value.length) {
      ignoredDevicesNearby.value = Set.unmodifiable(pruned);
    }
  }

  /// Parsed adverts of nearby SRAM controllers (shifters/blips/pods — NOT the RD),
  /// used to name and pre-register their buttons. Deduped by serial (last wins).
  Iterable<SramDeviceInfo> get sramShifterAdverts {
    final byserial = <int, SramDeviceInfo>{};
    for (final adv in _lastScanResult) {
      final record = _sramServiceDataRecord(adv.serviceData);
      if (record == null) continue;
      final info = SramAdvertisement.parse(record);
      if (info == null || info.isRearDerailleur) continue; // controllers only
      final t = info.effectiveType;
      // Only controllers that have buttons: drop/Reverb/Blipbox shifters (0..4) and blips/pods (96..125).
      // `effectiveType` falls back through the model→type map, so a shifter model
      // resolves to type 0 and a front derailleur (128) / dropper post (132) is excluded.
      final hasButtons = t != null && ((t >= 0 && t <= 4) || (t >= 96 && t <= 125));
      if (!hasButtons) continue;
      byserial[info.serial] = info;
    }
    return byserial.values;
  }

  /// Whether a Zwift Click V2 left puck is switched on within range.
  ///
  /// Read from the raw adverts, not from [devices], and deliberately so: what
  /// matters is a sibling being *nearby*, not paired. In right-side-only mode
  /// the left puck is on the ignored list and so never enters [devices] at
  /// all, yet it is still advertising and still counts.
  bool get hasNearbyClickV2LeftSide {
    if (_lastScanResult.any(isClickV2LeftSideAdvert)) return true;
    // A left puck that connected before the scan list was last cleared no
    // longer has an advert to find, but is plainly still there.
    return devices.whereType<ZwiftClickV2LeftSide>().any((d) => d.isConnected);
  }

  /// Whether an advert is a Click V2 left puck, by the Zwift manufacturer
  /// record's device-type byte. Split out from [hasNearbyClickV2LeftSide] so
  /// the identification can be tested without a radio.
  @visibleForTesting
  static bool isClickV2LeftSideAdvert(BleDevice adv) {
    final payload = adv.manufacturerDataList
        .firstOrNullWhere((e) => e.companyId == ZwiftConstants.ZWIFT_MANUFACTURER_ID)
        ?.payload;
    if (payload == null || payload.isEmpty) return false;
    return ZwiftDeviceType.fromManufacturerData(payload.first) == ZwiftDeviceType.clickV2Left;
  }

  static Uint8List? _sramServiceDataRecord(Map<String, Uint8List> serviceData) {
    for (final e in serviceData.entries) {
      if (e.key.toLowerCase().contains('fe51')) return e.value;
    }
    return null;
  }

  Timer? _gamePadSearchTimer;
  WifiTrainerScanner? _wifiTrainerScanner;

  /// Auto-disconnects idle BLE controllers to save battery (issue #329).
  /// Created in [initialize] once `core` is ready.
  InactivityDisconnector? _inactivityDisconnector;

  InclineController? _inclineController;
  _ClimbRelaySink? _relaySink;
  FitnessBikeDefinition? _relaySinkFbd;

  // ── Remembered devices ────────────────────────────────────────────────
  // A controller that is switched off or out of range used to vanish from the
  // app entirely. These three members keep it on screen instead: rebuilt from
  // the advertisement we stored the last time it connected, greyed out, and
  // still editable.

  /// Controllers known from a previous session, rebuilt from their stored
  /// advertisement. Kept deliberately OUT of [devices] and out of
  /// [_connectionQueue] so a remembered entry never triggers a connection
  /// attempt on its own — it is a picture of a device, not a device.
  final Map<String, BaseDevice> _offlineControllers = {};

  /// The last smart trainer that connected, as data. Unlike controllers this is
  /// never rebuilt into an object: the trainer card needs a name and a route
  /// into its settings page, not buttons or a contour, and constructing a
  /// [ProxyDevice] allocates an emulator we would never start.
  RememberedDevice? rememberedTrainer;

  /// Ids of devices that have connected at least once in this app session.
  ///
  /// This is what separates "lost connection" (red — it was working and broke)
  /// from "out of range" (amber — you just haven't switched it on yet). A fresh
  /// launch with the controller in a drawer must not paint the screen red.
  // Not annotated `Set<String>`: `prop` exports its own non-generic `Set`,
  // which shadows dart:core's here. The literal infers the right type.
  final _connectedThisSession = <String>{};

  bool wasConnectedThisSession(String uniqueId) => _connectedThisSession.contains(uniqueId);

  /// Test seam for the set above. The production path runs through a live BLE
  /// connection-state stream, which no widget test can drive — and the whole
  /// "lost" vs "connecting" distinction hangs off this one bit, so it has to
  /// be settable on its own. Clearing matters as much as setting: `core`
  /// outlives every test, and a session flag one test left behind would make
  /// the next one's fresh device read as broken.
  @visibleForTesting
  void debugSetConnectedThisSession(String uniqueId, bool value) {
    if (value) {
      _connectedThisSession.add(uniqueId);
    } else {
      _connectedThisSession.remove(uniqueId);
    }
  }

  /// Remembered controllers that no live device has taken over yet. Once the
  /// real device is discovered and enters [devices], its offline stand-in drops
  /// out of this list so the rider never sees the same controller twice.
  List<BaseDevice> get offlineControllers {
    final liveIds = devices.map((d) => d.uniqueId).toSet();
    return _offlineControllers.values.where((d) => !liveIds.contains(d.uniqueId)).toList();
  }

  /// Remembers [device] as an offline controller, as [loadRememberedDevices]
  /// does from storage. Tests only.
  @visibleForTesting
  void debugRememberController(BaseDevice device) => _offlineControllers[device.uniqueId] = device;

  /// Clears what [debugRememberController] added. Tests only.
  @visibleForTesting
  void debugForgetOfflineControllers() => _offlineControllers.clear();

  /// Rebuilds the remembered controllers and restores the remembered trainer.
  /// Safe to call more than once — entries already present are left alone.
  void loadRememberedDevices() {
    final ignoredIds = core.settings.getIgnoredDevices().map((d) => d.id).toSet();
    for (final remembered in core.rememberedDevices.load()) {
      if (ignoredIds.contains(remembered.deviceId)) continue;

      if (remembered.kind == RememberedDeviceKind.trainer) {
        rememberedTrainer ??= remembered;
        continue;
      }
      if (_offlineControllers.containsKey(remembered.deviceId)) continue;

      try {
        // The stored advert is exactly what the factory reads, so this yields a
        // real device of the right subclass — correct buttons, correct contour.
        final device = BluetoothDevice.fromScanResult(remembered.toScanResult());
        if (device != null) _offlineControllers[remembered.deviceId] = device;
      } catch (e, s) {
        recordError(e, s, context: 'Connection.loadRememberedDevices ${remembered.deviceId}');
      }
    }
  }

  // ── Startup reconnect ─────────────────────────────────────────────────

  /// How long after launch the remembered devices count as on their way
  /// back. Long enough for a controller to wake and a trainer to be found; a
  /// device still missing after it really is just not here.
  static const Duration startupReconnectWindow = Duration(seconds: 20);

  /// The remembered devices (by id) BikeControl is reconnecting to on its own
  /// right after launch. The home screen shows each as a placeholder card that
  /// is "Connecting…" — where its live card will be — instead of a device that
  /// is away. A device leaves the set the moment it connects; the set empties
  /// when [startupReconnectWindow] runs out.
  // A list, not a Set: `prop` exports its own `Set`, which shadows dart:core's.
  final ValueNotifier<List<String>> startupReconnecting = ValueNotifier(const []);
  Timer? _startupReconnectTimer;

  /// Opens the window for every remembered controller, and the remembered
  /// trainer if the rider left it on auto-connect. Nothing remembered, no
  /// window.
  void beginStartupReconnect({Duration window = startupReconnectWindow}) {
    final trainer = rememberedTrainer;
    final ids = [
      ..._offlineControllers.keys,
      if (trainer != null && core.settings.getAutoConnect(trainer.name ?? trainer.deviceId)) trainer.deviceId,
    ].where((id) => !_connectedThisSession.contains(id)).toSet().toList(growable: false);
    _startupReconnectTimer?.cancel();
    if (ids.isEmpty) {
      startupReconnecting.value = const [];
      return;
    }
    startupReconnecting.value = List.unmodifiable(ids);
    _startupReconnectTimer = Timer(window, endStartupReconnect);
  }

  /// [deviceId] is back: it no longer needs a placeholder. The last one back
  /// closes the window.
  void noteReconnected(String deviceId) {
    final pending = startupReconnecting.value;
    if (!pending.contains(deviceId)) return;
    final rest = pending.where((id) => id != deviceId).toList(growable: false);
    if (rest.isEmpty) {
      endStartupReconnect();
    } else {
      startupReconnecting.value = List.unmodifiable(rest);
    }
  }

  void endStartupReconnect() {
    _startupReconnectTimer?.cancel();
    _startupReconnectTimer = null;
    if (startupReconnecting.value.isNotEmpty) startupReconnecting.value = const [];
  }

  /// Drops a remembered device and returns the index it sat at, so an Undo can
  /// put it back exactly where the rider saw it. Bindings in the keymap are
  /// left alone and the device is NOT ignored, so switching it on nearby still
  /// connects it normally.
  Future<int?> forgetRemembered(String deviceId) async {
    _offlineControllers.remove(deviceId);
    if (rememberedTrainer?.deviceId == deviceId) rememberedTrainer = null;
    final index = await core.rememberedDevices.forget(deviceId);
    hasDevices.value = devices.isNotEmpty || _offlineControllers.isNotEmpty;
    return index;
  }

  Future<void> restoreRemembered(RememberedDevice device, {int? atIndex}) async {
    await core.rememberedDevices.restore(device, atIndex: atIndex);
    loadRememberedDevices();
    hasDevices.value = devices.isNotEmpty || _offlineControllers.isNotEmpty;
  }

  /// Marks a device as genuinely connected in this session, and remembers it.
  ///
  /// Called from both the BLE connection-state listener and the post-connect
  /// path, since neither covers every device type on its own. Remembering is
  /// idempotent (the repository dedupes by id and refreshes the timestamp), so
  /// arriving twice for one connect is harmless.
  void _noteConnected(BaseDevice device) {
    _connectedThisSession.add(device.uniqueId);
    noteReconnected(device.uniqueId);
    unawaited(_rememberConnectedDevice(device));
    _registerSensorSource(device);
  }

  /// Gives the hub a live [SensorSource] the moment a sensor actually reaches
  /// connected state — never at construction, since `fromScanResult` builds
  /// one object per scan result whether or not the rider ever connects it.
  ///
  /// Gated on [BleSensorDevice] rather than a concrete type: a strap, a
  /// cadence sensor and a power meter all own a [BleSensorSource] the same
  /// way, and dispatching on the shared interface means the NEXT sensor type
  /// only has to mix it in, not earn a third `is` check here.
  ///
  /// Called from [_noteConnected], so it inherits the same "arriving twice is
  /// harmless" contract: `SensorHub.register` re-keys a map entry and rebinds
  /// only the quantities that already point at this id, so registering the
  /// same instance again is a no-op in every observable way.
  void _registerSensorSource(BaseDevice device) {
    if (device is! BleSensorDevice) return;
    try {
      core.sensors.register(device.source);
      unawaited(device.source.start());
    } catch (e, s) {
      recordError(e, s, context: 'Connection._registerSensorSource ${device.source.id}');
    }
  }

  /// The disconnect-side counterpart of [_registerSensorSource]: drops the
  /// hub's registration and stops the source so its retained reading is
  /// cleared rather than left to be served stale past its TTL. A rediscovered
  /// sensor arrives as a brand new device and source object (see
  /// `SensorHub.register`'s doc comment), so there is nothing here worth
  /// keeping around once this one is gone.
  ///
  /// Gated on [BleSensorDevice] for the same reason as
  /// [_registerSensorSource] — see its doc comment. Delegates the actual
  /// teardown to [_unregisterSource], shared with [disconnectHealthKit].
  Future<void> _unregisterSensorSource(BaseDevice device, {required bool forget}) async {
    if (device is! BleSensorDevice) return;
    await _unregisterSource(device.source, forget: forget, context: 'Connection._unregisterSensorSource');
  }

  /// Shared by the BLE path above and [disconnectHealthKit]: drop the hub
  /// registration, optionally clear every selection pointing at this id, and
  /// stop the source so its retained reading is cleared rather than served
  /// stale past its TTL.
  ///
  /// `SensorHub.unregister` deliberately leaves the rider's selection
  /// pointing at this id (see its own doc comment) — it cannot tell a
  /// transient drop from the rider being done with the device, so it always
  /// assumes the former. Only [forget] means the latter: [Connection] is the
  /// one place that actually knows the rider forgot this source (as opposed
  /// to it merely dropping out — BLE range, or a transient HealthKit hiccup —
  /// to be rediscovered a moment later), so clearing the selection for good
  /// is done here, explicitly, and only then — a transient drop must leave it
  /// alone so `register`'s rebind loop still matches when the source
  /// reappears.
  Future<void> _unregisterSource(SensorSource source, {required bool forget, required String context}) async {
    try {
      core.sensors.unregister(source.id);
      if (forget) {
        for (final quantity in source.provides) {
          if (core.sensors.selectionFor(quantity) == source.id) {
            core.sensors.select(quantity, null);
          }
        }
      }
      await source.stop();
    } catch (e, s) {
      recordError(e, s, context: '$context ${source.id}');
    }
  }

  /// Ask for Health permission — split out of what used to be
  /// `connectHealthKit` so a caller can authorize BEFORE the hub selection
  /// changes. `SensorHub.select` fires `onSelectionChanged` synchronously
  /// (see `SensorSinkSync`), which restarts the BLE/DIRCON bridge transport
  /// (`DirconEmulator._restartTransportAfterChildChange`) — if that restart
  /// races healthd presenting the permission sheet in this process, the
  /// authorization session itself times out and the sheet never appears
  /// (device-confirmed: first tap on Apple Health always failed this way).
  /// `LiveMetricsSection._select` now calls this before touching
  /// `core.sensors.select` at all, for exactly this reason.
  ///
  /// No-op when [healthKitSource] is null (every non-iOS platform). `unknown`
  /// proceeds — HealthKit hides read denials, so refusing on anything but an
  /// explicit share denial would refuse riders who actually said yes.
  Future<void> authorizeHealthKit() async {
    final source = healthKitSource;
    if (source == null) return;
    final verdict = await source.authorize();
    if (verdict == HealthKitAuthorization.denied) throw HealthKitDeniedException();
  }

  /// The HealthKit analogue of a strap connect: register so `SensorHub`
  /// calls `start()` and the native session/query begins. Deliberately does
  /// NOT authorize — that must already have happened via
  /// [authorizeHealthKit] before the caller ever changed the hub selection
  /// (see that method's doc comment for why the ordering matters); this is
  /// purely the register-and-start half.
  Future<void> connectHealthKit() async {
    final source = healthKitSource;
    if (source == null) return;
    try {
      core.sensors.register(source);
      unawaited(source.start());
    } catch (e, s) {
      recordError(e, s, context: 'Connection.connectHealthKit');
      rethrow;
    }
  }

  /// Mirrors [_unregisterSensorSource]'s `forget` semantics exactly —
  /// `true` only when the rider is done with Apple Health, never for a
  /// transient failure.
  Future<void> disconnectHealthKit({required bool forget}) async {
    final source = healthKitSource;
    if (source == null || !isHealthKitConnected) return;
    await _unregisterSource(source, forget: forget, context: 'Connection.disconnectHealthKit');
  }

  /// TXT record for the standalone sensor advertisement — the same identity
  /// keys the bridge's `_wahoo-fitness-tnp._tcp` record carries for the
  /// selected app (`mac-address`, `serial-number`, plus the app's own; see
  /// [ProxyDevice.trainerMdnsTxtFor]). Seeded from a fixed string rather
  /// than a trainer id: this peripheral IS BikeControl, there is no trainer,
  /// and a stable serial is what lets a client recognise it across rides.
  Map<String, Uint8List> standaloneMdnsTxt() => ProxyDevice.trainerMdnsTxtFor(
    core.settings.getTrainerApp(),
    serialNumber: mdnsSerialNumber('bikecontrol-sensors'),
  );

  /// Cold launch with Apple Health persisted as the heart-rate source:
  /// re-register without a tap. iOS remembers the authorization, so this
  /// shows no sheet. A denial here (the rider revoked access in Settings
  /// meanwhile) is swallowed on purpose: the tile then shows the persisted
  /// pick as "Connecting…" and a tap re-prompts.
  ///
  /// Calls [authorizeHealthKit] then [connectHealthKit] explicitly, in that
  /// order — same ordering requirement as the tap path, even though the
  /// selection here is already persisted from a previous session and does
  /// not change again: keeping both call sites symmetrical means the two
  /// methods never drift out of sync with each other.
  ///
  /// Also swallows a native `PlatformException(code: 'authorize')` here —
  /// this UI-less launch path is exactly where healthd can fail to present
  /// the sheet at all for reasons that have nothing to do with the rider
  /// (e.g. the app launched into the background), an expected environmental
  /// outcome logged like the denied case rather than sent to `recordError`.
  /// Any OTHER exception still propagates to `_probeHealthKit`'s own catch.
  Future<void> restoreHealthKitSelection() async {
    if (healthKitSource == null) return;
    if (core.sensors.selectionFor(SensorQuantity.heartRate) != HealthKitSensorSource.sourceId) return;
    // Sensors-only mode has no bridge to restore for — in that mode Apple
    // Health only ever connects via the Broadcast switch (`turnOn` →
    // `connectSourceById`), so a launch-time restore here would connect a
    // source nothing is serving yet (spec Decision 4, "relaunch starts
    // nothing"). Trainer mode is unaffected: the bridge genuinely relies on
    // this restore running at launch.
    if (core.settings.getSensorsOnlyMode()) {
      _appendLogEntry('HealthKit: sensors-only mode — Apple Health connects when Broadcast is switched on');
      return;
    }
    try {
      await authorizeHealthKit();
      await connectHealthKit();
    } on HealthKitDeniedException {
      _appendLogEntry('HealthKit: persisted Apple Health selection not restored — permission denied');
    } on PlatformException catch (e) {
      if (e.code != 'authorize') rethrow;
      _appendLogEntry('HealthKit: authorization at launch failed — ${e.message}');
    }
  }

  /// Builds the source only where it can work. `isAvailable` is a cheap
  /// synchronous check on the native side; keeping it async here keeps
  /// `initialize` free of a platform round-trip on the critical path.
  Future<void> _probeHealthKit() async {
    try {
      final channel = MethodChannelHealthKit();
      if (!await channel.isAvailable()) return;
      healthKitSource = HealthKitSensorSource(channel: channel);
      await restoreHealthKitSelection();
    } catch (e, s) {
      recordError(e, s, context: 'Connection._probeHealthKit');
    }
  }

  /// [BroadcastController]'s `connectSource` hook: a source id from the hub
  /// resolved to an actual connect. HealthKit routes through
  /// [authorizeHealthKit] + [connectHealthKit] (same ordering requirement as
  /// every other HealthKit call site — see [authorizeHealthKit]'s doc
  /// comment); every other id is a BLE sensor device id — `BleSensorSource
  /// .id` IS the BLE `deviceId` it was built from (see e.g.
  /// `BleHeartRateDevice`'s constructor) — so there is no third, "unknown
  /// kind of id" case to handle here.
  ///
  /// Consent is persisted UNCONDITIONALLY, before the device is even looked
  /// up in [devices]: a strap the rider just selected may not have been
  /// discovered by the scanner yet, and setting consent now is what lets the
  /// auto-connect queue pick it up the moment it is (`shouldAutoConnect`
  /// reads this flag) — not finding it in [devices] here is "not yet in
  /// range," not a failure, so it logs and returns rather than throwing.
  ///
  /// A genuine [connectDevice] failure, though, DOES rethrow after clearing
  /// consent back off and recording — [BroadcastController.turnOn]'s
  /// per-id rollback only ever learns about ids `connectSource` returned
  /// successfully for, so an id that fails here has to clear its own
  /// consent; nothing downstream will do it.
  Future<void> connectSourceById(String id) async {
    if (id == HealthKitSensorSource.sourceId) {
      try {
        await authorizeHealthKit();
        await connectHealthKit();
      } catch (e, s) {
        await recordError(e, s, context: 'Connection.connectSourceById healthkit');
        rethrow;
      }
      return;
    }
    await core.settings.setSensorAutoConnect(id, true);
    final device = devices.whereType<BleSensorDevice>().firstOrNullWhere((d) => d.source.id == id);
    if (device == null) {
      _appendLogEntry('Broadcast: source "$id" not yet discovered — will auto-connect once found');
      return;
    }
    try {
      await connectDevice(device);
    } catch (e, s) {
      await core.settings.setSensorAutoConnect(id, false);
      await recordError(e, s, context: 'Connection.connectSourceById $id');
      rethrow;
    }
  }

  /// The disconnect-side counterpart of [connectSourceById] — same id
  /// routing. HealthKit goes through [disconnectHealthKit] with `forget:
  /// false` (this is Broadcast turning off, not the rider forgetting the
  /// source — mirrors [disconnectHealthKit]'s own `forget` semantics doc
  /// comment).
  ///
  /// For a BLE id, consent is cleared FIRST — before the device is even
  /// looked up — and keyed on [id] directly (`BleSensorSource.id` IS the
  /// BLE `deviceId`, see [connectSourceById]'s doc comment). A strap that
  /// dropped mid-broadcast is already gone from [devices] by the time this
  /// runs (the drop listener's `disconnect(..., dropped: true)` uses
  /// `keepInList: false`): looking the device up FIRST and bailing when it's
  /// missing would leave consent stuck at `true`, and that strap would
  /// auto-connect on rediscovery with the switch off — a Decision 4
  /// violation. A missing device here is therefore expected, not
  /// exceptional: logged, not [recordError]'d. When the device IS still
  /// present, it disconnects with `keepInList: true` so it stays selectable
  /// the moment the rider flips Broadcast back on (same as
  /// `LiveMetricsSection._disconnect`'s own reasoning).
  Future<void> disconnectSourceById(String id) async {
    if (id == HealthKitSensorSource.sourceId) {
      try {
        await disconnectHealthKit(forget: false);
      } catch (e, s) {
        await recordError(e, s, context: 'Connection.disconnectSourceById healthkit');
        rethrow;
      }
      return;
    }
    await core.settings.setSensorAutoConnect(id, false);
    final device = devices.whereType<BleSensorDevice>().firstOrNullWhere((d) => d.source.id == id);
    if (device == null) {
      _appendLogEntry('Broadcast: source "$id" already disconnected — consent cleared');
      return;
    }
    try {
      await disconnect(device, forget: false, persistForget: false, keepInList: true);
    } catch (e, s) {
      await recordError(e, s, context: 'Connection.disconnectSourceById $id');
      rethrow;
    }
  }

  /// Records a device we just connected to. Accessories are skipped — they are
  /// not links in the setup chain and would only clutter the remembered list.
  Future<void> _rememberConnectedDevice(BaseDevice device) async {
    if (device is! BluetoothDevice) return;
    if (device is Accessory) return;

    final kind = device is ProxyDevice ? RememberedDeviceKind.trainer : RememberedDeviceKind.controller;
    final remembered = RememberedDevice.fromScanResult(
      device.device,
      kind: kind,
      lastConnected: DateTime.now(),
    );
    if (kind == RememberedDeviceKind.trainer) {
      rememberedTrainer = remembered;
    } else {
      // The live device supersedes its own stand-in.
      _offlineControllers.remove(device.uniqueId);
    }
    await core.rememberedDevices.remember(remembered);
  }

  /// Devices whose in-place ("No connection") disconnect is currently in
  /// flight. UniversalBle.disconnect resolves only after the platform's
  /// disconnect event has fired — while our connectionStream listener is
  /// still attached. Without this guard that listener re-enters [disconnect]
  /// WITHOUT keepInList and drops the device from the registry, orphaning the
  /// object the open details page still holds.
  final _inPlaceDisconnects = <BaseDevice>{};

  /// Devices whose [disconnect] is currently running its teardown. The same
  /// mid-teardown platform event re-enters [disconnect] from the drop listener
  /// with `dropped: true` — at that point the device still reads as connected
  /// (BaseDevice.disconnect clears the flag last), so without this guard the
  /// echo would start a second, concurrent teardown of the same device.
  final _disconnecting = <BaseDevice>{};

  /// BLE ids of controllers disconnected by the inactivity battery saver. They
  /// are deliberately NOT added to the ignore list (so the user can reconnect),
  /// but must not be auto-reconnected when rediscovered (via scan results,
  /// getSystemDevices or the disconnect listener's performScanning) — otherwise
  /// they reconnect right after the battery-saver disconnect. Cleared on an
  /// explicit reconnect, a successful (re)connect, or automatically once
  /// [inactivityReconnectCooldown] has elapsed — after that a rediscovered
  /// (woken) controller auto-reconnects normally again.
  final _suppressedAutoReconnect = <String>{};

  /// How long after the battery-saver disconnect a controller stays suppressed.
  /// Long enough for the controller to stop advertising and fall asleep;
  /// afterwards any advertisement means the rider woke it and wants it back.
  /// Mutable as a test seam (the integration tests shrink it to milliseconds).
  Duration inactivityReconnectCooldown = const Duration(seconds: 90);

  /// Whether [device] is currently sitting out a battery-saver or backoff
  /// suppression window (see [_suppressedAutoReconnect]). Read-only escape
  /// hatch for callers outside this class (e.g. [ClickV2Onboarding]) that
  /// enumerate devices themselves and must not force-reconnect one the
  /// battery saver deliberately put to sleep.
  bool isAutoReconnectSuppressed(BaseDevice device) =>
      device is BluetoothDevice && _suppressedAutoReconnect.contains(device.device.deviceId);

  /// BLE ids the rider disconnected with "Disconnect and forget for this
  /// session". Unlike the ignore list this is not persisted, but it holds for
  /// the whole session: the device keeps advertising, and the scan dedup entry
  /// that used to be the only thing keeping it out is dropped by a connection
  /// change, a scan restart or a Bluetooth toggle — each of which brought the
  /// device straight back. Lifted by an explicit [connectDevice] or
  /// [reconnectForSession].
  ///
  /// Each held id maps to the name the rider knew the controller by: listed
  /// under Ignored devices with Reconnect ([reconnectForSession]), so changing
  /// one's mind needs no app restart.
  final ValueNotifier<Map<String, String>> disconnectedForSession = ValueNotifier(const {});

  bool _isDisconnectedForSession(String id) => disconnectedForSession.value.containsKey(id);

  void _setDisconnectedForSession(String id, String? name) {
    if (name == null) {
      if (!_isDisconnectedForSession(id)) return;
      disconnectedForSession.value = Map.unmodifiable({...disconnectedForSession.value}..remove(id));
    } else {
      disconnectedForSession.value = Map.unmodifiable({...disconnectedForSession.value, id: name});
    }
  }

  /// Clears what [disconnectForSession] held back, as an app restart does.
  /// Tests only.
  @visibleForTesting
  void debugClearDisconnectedForSession() => disconnectedForSession.value = const {};

  /// Disconnects [device] and keeps it from auto-connecting again until the
  /// app restarts or the rider connects it explicitly.
  Future<void> disconnectForSession(BaseDevice device) async {
    if (device is BluetoothDevice) _setDisconnectedForSession(device.device.deviceId, device.toString());
    await disconnect(device, forget: true, persistForget: false);
  }

  /// Lifts [disconnectForSession] for [id]: the controller is added and
  /// connects again as soon as the scan sees it — at once if it already has.
  Future<void> reconnectForSession(String id) async {
    _setDisconnectedForSession(id, null);
    if (ignoredDevicesNearby.value.contains(id)) {
      ignoredDevicesNearby.value = Set.unmodifiable({...ignoredDevicesNearby.value}..remove(id));
    }
    final seen = _lastScanResult.lastOrNullWhere((d) => d.deviceId == id);
    final device = seen == null ? null : BluetoothDevice.fromScanResult(seen);
    if (device != null) {
      addDevices([device]);
    } else {
      // Not seen since: let its next advert through the scan's de-dupe.
      _lastScanResult.removeWhere((d) => d.deviceId == id);
    }
  }

  /// Consecutive failed auto-connect attempts per BLE device id. Only devices
  /// with [BluetoothDevice.maxAutoConnectAttempts] > 0 ever suppress; reset by
  /// a successful connect.
  final _consecutiveConnectFailures = <String, int>{};

  /// Device ids whose give-up alert was already shown this session — later
  /// suppression rounds only log, so one stubborn device produces one alert.
  final _backoffAlerted = <String>{};

  /// How long a device that exhausted its attempts stays suppressed before
  /// rediscovery may try again (one quiet attempt per round). Mutable as a
  /// test seam.
  Duration autoConnectBackoffCooldown = const Duration(seconds: 90);

  /// Delay before the first automatic retry of a connect attempt that failed
  /// without the platform ever reporting a disconnect (a macOS/iOS connect
  /// timeout). Doubles per consecutive failure, capped at
  /// [connectRetryMaxDelay]. Mutable as a test seam.
  Duration connectRetryBaseDelay = const Duration(seconds: 5);

  /// Upper bound for the growing [connectRetryBaseDelay].
  static const connectRetryMaxDelay = Duration(seconds: 60);

  /// Pending automatic connect retries, keyed by BLE device id. At most one
  /// per device; cancelled by any [disconnect] of it (forget, in-place
  /// "No connection", a drop the listener already cleaned up), by an explicit
  /// [connectDevice] and by [disconnectAll].
  final _connectRetryTimers = <String, Timer>{};

  /// Consecutive failed connects per BLE device id that were followed by a
  /// scheduled retry — drives the growing delay; reset by a successful connect.
  final _connectRetryCounts = <String, int>{};

  /// BLE device ids [disconnect]ed since their current connect attempt
  /// started — the rider (or the drop listener) already decided about the
  /// device while it was still connecting, so that attempt's failure must not
  /// schedule a retry. Cleared when the queue starts the next attempt.
  final _disconnectedDuringConnect = <String>{};

  /// Pending cooldown timers from [_recordConnectFailure], keyed by BLE device
  /// id. Backoff shares [_suppressedAutoReconnect] with the battery saver, so a
  /// stale timer left running past a Retry/reconnect could lift a later —
  /// possibly unrelated — suppression early; tracked here so it can be
  /// cancelled the moment the suppression it guards is lifted some other way.
  final _backoffCooldownTimers = <String, Timer>{};

  /// When each BLE device last became connected — used to spot a pod that
  /// connects but drops again within [quickDropThreshold] (e.g. a WHEELTOP TX
  /// pod whose keepalive we can't answer). Such a connect looks successful to
  /// the connect queue, so [_consecutiveConnectFailures] never catches it.
  final _connectedAt = <String, DateTime>{};

  /// Consecutive quick drops per BLE device id (a connect that dies within
  /// [quickDropThreshold]). Counted only for devices that do NOT opt out via
  /// [BluetoothDevice.keepsReconnectingWhileDropping]; drives the same backoff
  /// as [_consecutiveConnectFailures] once it reaches the device's limit.
  final _quickDropCounts = <String, int>{};

  /// A connection that dies within this window counts as a quick drop. Mutable
  /// as a test seam.
  Duration quickDropThreshold = const Duration(seconds: 5);

  /// True once [device] has exhausted its auto-connect attempts (failed
  /// connects or quick drops) — backoff rounds stay quiet: no
  /// connecting/disconnected toasts, no OS notification.
  bool _isInBackoff(BaseDevice device) {
    if (device is! BluetoothDevice || device.maxAutoConnectAttempts <= 0) return false;
    final id = device.device.deviceId;
    return (_consecutiveConnectFailures[id] ?? 0) >= device.maxAutoConnectAttempts ||
        (_quickDropCounts[id] ?? 0) >= device.maxAutoConnectAttempts;
  }

  void initialize() {
    configureBleCommandQueues();
    // Show what the rider owns before any radio has said a word.
    loadRememberedDevices();
    // Store renders stage a settled setup, not a launch.
    if (!screenshotMode) beginStartupReconnect();

    startLogCapture();

    _inactivityDisconnector = InactivityDisconnector(
      isTrainerAppConnected: () => core.logic.connectedNonLocalTrainerConnections.isNotEmpty,
      isOnlyLocalActive: () => core.logic.enabledNonLocalTrainerConnections.isEmpty && core.settings.getLocalEnabled(),
      hasEligibleControllers: () =>
          controllerDevices.whereType<BluetoothDevice>().any((d) => d.isConnected && !d.exemptFromBatterySaver),
      onTimeout: _onInactivityTimeout,
    );

    _inclineController ??= InclineController(
      gradeProvider: () => ftmsEmulator.fitnessBike?.simGrade.value,
      sinkProvider: () {
        final direct = devices.whereType<InclineSink>().firstOrNullWhere(
          (d) => (d as BaseDevice).isConnected,
        );
        if (direct != null) return direct;
        final fbd = ftmsEmulator.fitnessBike;
        if (fbd != null && fbd.supportsClimbRelay) {
          if (!identical(_relaySinkFbd, fbd)) {
            _relaySinkFbd = fbd;
            _relaySink = _ClimbRelaySink(fbd);
          }
          return _relaySink;
        }
        _relaySink = null;
        _relaySinkFbd = null;
        return null;
      },
    )..start();

    // A trainer app attaching/leaving any non-Local connection method drives
    // the battery saver. These emulator singletons live for the app lifetime,
    // so the listeners never need removing.
    final appConnections = [
      core.zwiftEmulator,
      core.zwiftMdnsEmulator,
      core.rouvyMdnsEmulator,
      core.obpMdnsEmulator,
      core.obpBluetoothEmulator,
      core.whooshLink,
      core.remotePairing,
      core.remoteKeyboardPairing,
    ];
    for (final connection in appConnections) {
      connection.isConnected.addListener(() => _inactivityDisconnector?.onTrainerConnectionChanged());
    }
    // Steering devices' calibrated angle rides to OpenBikeControl apps as 0x1B.
    core.obcSteeringAngle
      ..watchDevices(connectionStream)
      ..watchApps([core.obpMdnsEmulator, core.obpBluetoothEmulator]);
    // It is also what tells the home screen an app that disconnected from one
    // that never connected — whichever tab the rider was on at the time.
    core.appConnectionLatch.watch([
      for (final connection in appConnections) connection.isConnected,
      core.settings.trainerAppListenable,
    ]);

    if (!kIsWeb && (Platform.isMacOS || Platform.isWindows || Platform.isIOS)) {
      core.mediaKeyHandler.initialize();
      // Load saved media key detection state
      core.mediaKeyHandler.isMediaKeyDetectionEnabled.value = core.settings.getMediaKeyDetectionEnabled();
    }

    // Rider metrics BikeControl itself sourced (currently just heart rate) are
    // served through their own definition, which lives either on the bridge's
    // composite or on a standalone emulator — never both. Isolated in its own
    // try/catch so a failure here (e.g. a bad persisted sensor selection)
    // cannot take the rest of connection setup down with it.
    try {
      final sensorDefinition = SensorDefinition();
      final standaloneSensorEmulator = DirconEmulator();
      // Without this, a lapsed subscriber's standalone heart rate monitor
      // keeps advertising forever; the bridge path already refuses to
      // advertise once the trial's spent (`shouldAdvertise`), so the
      // standalone path must too.
      standaloneSensorEmulator.shouldAdvertise = () => IAPManager.instance.isProEnabledForCurrentDevice;
      // Never the trainer-app name (e.g. "Zwift Hub"): unlike ftmsEmulator,
      // which impersonates whatever trainer app the rider picked, this
      // standalone peripheral is BikeControl itself — a rider pairing a
      // heart rate/cadence/power source in Zwift's own pairing screen should
      // see it identified as what it is.
      standaloneSensorEmulator.advertisementNameOverride = () => 'BikeControl';
      _standaloneClientConnected = standaloneSensorEmulator.isConnected;
      // Attach-before-start / stop-before-detach: DirconEmulator.startServer
      // advertises whatever is already on its composite, so calling it
      // before the definition is attached leaves nothing to serve. See
      // StandaloneSensorLifecycle's doc comment for exactly what that fails
      // with.
      // Same identity/transport quirks the bridge applies per selected app
      // (`ProxyDevice.handleServices`): without the TXT record MyWhoosh
      // throws on the missing `serial-number` and Tacx drops the peripheral
      // for lack of a `mac-address`; the bare/`0x` 16-bit service form and
      // the IPv4-only listener follow the app the same way.
      standaloneSensorEmulator.bareShortServiceUuids = () =>
          ProxyDevice.bareShortServiceUuidsFor(core.settings.getTrainerApp());
      standaloneSensorEmulator.forceIPv4 = () => ProxyDevice.needsIPv4For(core.settings.getTrainerApp());
      final standaloneSensorLifecycle = StandaloneSensorLifecycle(
        attachDefinition: standaloneSensorEmulator.attachDefinition,
        startServer: (mode) => standaloneSensorEmulator.startServer(mode: mode, mdnsTxt: standaloneMdnsTxt()),
        stopServer: standaloneSensorEmulator.stop,
        detachDefinition: standaloneSensorEmulator.detachDefinition,
      );
      final sensorSink = SensorSinkController(
        definition: sensorDefinition,
        // attachDefinition/detachDefinition (not composite.attach/detach
        // directly) so a mid-ride source selection restarts the live bridge
        // transport in place when it needs to — composite.attach alone only
        // updates the composite's bookkeeping.
        attach: ftmsEmulator.attachDefinition,
        detach: ftmsEmulator.detachDefinition,
        startStandalone: (def, transport) => standaloneSensorLifecycle.start(def, transport),
        stopStandalone: () => standaloneSensorLifecycle.stop(sensorDefinition),
      );

      // The buffer this attaches to lives on Connection, built after `core`,
      // which is why `log` is a settable field rather than a constructor arg.
      core.sensors.log = _appLog;
      // Runtime callback, not a one-shot: re-evaluated on every publish (see
      // SensorHub.isProEnabled's doc comment), so a subscription lapsing
      // mid-ride stops resolving on the next tick without the rider ever
      // reselecting anything.
      core.sensors.isProEnabled = () => IAPManager.instance.isProEnabledForCurrentDevice;
      core.sensors.loadSelections(core.settings);
      if (!kIsWeb && Platform.isIOS) {
        unawaited(_probeHealthKit());
      }
      Timer.periodic(const Duration(seconds: 1), (_) => core.sensors.tick());

      // The Broadcast switch itself: owns connecting/disconnecting sources
      // and deciding whether a standalone stint is even wanted
      // (`wantsStandalone`). Constructed before `sinkSync` below since the
      // sink needs a live reference to read `wantsStandalone`/`transport`
      // from — but STARTED after it; see the ordering note on `sinkSync
      // .start()` vs `broadcast.start()` below.
      broadcast = BroadcastController(
        hub: core.sensors,
        settings: core.settings,
        isBridgeRunning: ftmsEmulator.isStarted,
        // `_apply` swallows a failed standalone start into recordError, so
        // the switch has to ask the sink itself whether anything came up.
        isStandaloneRunning: () => sensorSink.standaloneRunning,
        connectSource: connectSourceById,
        disconnectSource: disconnectSourceById,
      );

      // Keeps the sink synced to the bridge's isStarted, whether the rider
      // has picked a source at all, AND now the Broadcast switch — a cold
      // launch with nothing selected (or Broadcast left off) must not stand
      // up an empty "BikeControl" advertisement (see SensorSinkSync's own
      // doc comment). Also the retry path for a standalone start that failed
      // at launch: any later selection change re-syncs, not just a bridge
      // transition.
      final sinkSync = SensorSinkSync(
        hub: core.sensors,
        isBridgeRunning: ftmsEmulator.isStarted,
        sink: sensorSink,
        broadcast: broadcast!,
      );
      // Re-sync whenever the switch itself changes (on/off/transport) — the
      // hub's own selection-change hook (below) covers a source being picked
      // or dropped, but not the switch flipping with the same selection
      // still in place.
      broadcast!.onChanged = sinkSync.sync;
      // Order matters: `sinkSync.start()` is what first assigns
      // `hub.onSelectionChanged`; `broadcast.start()` CHAINS onto whatever is
      // already installed there (see BroadcastController.start's own doc
      // comment) rather than replacing it. Starting broadcast first would
      // instead have `sinkSync.start()` clobber broadcast's hook outright —
      // a selection change would then connect/disconnect sources but never
      // re-sync the sink.
      sinkSync.start();
      broadcast!.start();

      SensorBridgeBinding(
        hub: core.sensors,
        onHeartRate: (bpm) {
          ftmsEmulator.fitnessBike?.setExternalHeartRate(bpm);
          sensorDefinition.setHeartRate(bpm);
        },
        // Cadence and power are NOT unconditionally forwarded to
        // sensorDefinition the way heart rate is. FTMS Indoor Bike Data
        // already carries both while a trainer is bridged
        // (setExternalCadence/setExternalPower feed that packet directly), so
        // the standalone-only definition must never be told about them while
        // bridged — doing so would newly expose CSC/Cycling Power on the
        // bridge's own GATT table. sensorDefinition advertises CSC/Cycling
        // Power unconditionally, the same as heart rate always has;
        // SensorSinkController is what keeps them off the bridge, by calling
        // sensorDefinition.exposeServices(heartRate: true, cadence: false,
        // power: false) before every bridge attach (see that method's doc
        // comment for the defect this guards against).
        onCadence: (rpm) {
          ftmsEmulator.fitnessBike?.setExternalCadence(rpm);
          if (!ftmsEmulator.isStarted.value) sensorDefinition.setCadence(rpm);
        },
        onPower: (watts) {
          ftmsEmulator.fitnessBike?.setExternalPower(watts);
          if (!ftmsEmulator.isStarted.value) sensorDefinition.setPower(watts);
        },
      ).start();
    } catch (e, s) {
      recordError(e, s, context: 'SensorHub wiring');
    }

    // The advertised name depends on the selected trainer app (e.g. Rouvy →
    // "Zwift Hub"). Restart the transport on every change so the new name
    // shows up on the wire without the user reconnecting.
    core.settings.trainerAppListenable.addListener(() {
      // Reconcile each device's composite membership (a VS bridge takes its
      // ride-along controller on/off depending on the app, and a Click V2
      // rides on the bridge for some apps but not others) BEFORE the shared
      // emulator re-advertises, so the new advertisement reflects the change.
      for (final pd in proxyDevices) {
        unawaited(pd.onTrainerAppChanged());
      }
      for (final unlockable in bluetoothDevices.whereType<ZwiftUnlock>()) {
        unlockable.onTrainerAppChanged();
      }
      unawaited(ftmsEmulator.restart());
    });

    // Inform the user when ClickLogic restarts a device on purpose — its
    // entry greys out for a few seconds, so explain why.
    ClickLogic.onResetSent = (deviceId) {
      final device = bluetoothDevices.firstOrNullWhere((e) => e.device.deviceId == deviceId);
      if (device != null) {
        _actionStreams.add(
          AlertNotification(LogLevel.LOGLEVEL_INFO, AppLocalizations.current.deviceIsRestarting(device.toString())),
        );
      }
    };

    // Whether the right puck's lights will stay lit — only this side can see
    // what is in range. Never gates the keep-awake itself.
    ClickLogic.isLeftSideNearby = () => hasNearbyClickV2LeftSide;

    UniversalBle.onAvailabilityChange = (available) {
      _actionStreams.add(BluetoothAvailabilityNotification(available == AvailabilityState.poweredOn));
      if (available == AvailabilityState.poweredOn && !kIsWeb && !core.logic.deferLaunchPermissions) {
        core.permissions.getScanRequirements().then((perms) {
          if (Permissions.blockingScan(perms).isEmpty) {
            performScanning();
          }
        });
      } else if (available == AvailabilityState.poweredOff) {
        disconnectAll();
        stop();
      }
    };
    UniversalBle.onScanResult = (result) {
      // Update RSSI for already connected devices
      final existingDevice = bluetoothDevices.firstOrNullWhere(
        (e) => e.device.deviceId == result.deviceId,
      );
      if (existingDevice != null && existingDevice.rssi != result.rssi) {
        existingDevice.rssi = result.rssi;
        _rssiConnectionStreams.add(existingDevice); // Notify UI of update
      }

      if (_lastScanResult.none((e) => e.deviceId == result.deviceId && e.services.contentEquals(result.services))) {
        _lastScanResult.add(result);

        // A left puck coming into range is what brings the right one's LEDs
        // back, so re-enter the mode now rather than waiting up to a tick for
        // it. An ignored left puck never gets further than this — it is
        // discovered and then dropped — so discovery is the only signal.
        // Deliberately narrowed to left pucks: this re-runs the sequence, and
        // every other advert would make that an erase for nothing.
        if (isClickV2LeftSideAdvert(result)) {
          ClickLogic.startKeepAwakeIfPending();
        }

        if (kDebugMode) {
          debugPrint('Scan result: ${result.name} - ${result.deviceId} - Services: ${result.services}');
        }

        try {
          final scanResult = BluetoothDevice.fromScanResult(result);

          if (scanResult != null) {
            _actionStreams.add(
              LogNotification('Found new device: ${scanResult.toString()}'),
            );
            addDevices([scanResult]);
          } else {
            final manufacturerData = result.manufacturerDataList;
            final data = manufacturerData
                .firstOrNullWhere((e) => e.companyId == ZwiftConstants.ZWIFT_MANUFACTURER_ID)
                ?.payload;
            if (data != null && kDebugMode) {
              _actionStreams.add(
                LogNotification('Found unknown device ${result.name} with identifier: ${data.firstOrNull}'),
              );
            }
          }
        } catch (e, backtrace) {
          _actionStreams.add(
            LogNotification("Error processing scan result for device ${result.deviceId}: $e\n$backtrace"),
          );
          if (kDebugMode) {
            print(e);
            print("backtrace: $backtrace");
          }
        }
      }
    };

    UniversalBle.onValueChange = (BleCharacteristicValue change) async {
      final deviceId = change.deviceId;
      final characteristicUuid = change.characteristicId;
      final value = change.value;
      final device = bluetoothDevices.firstOrNullWhere((e) => e.device.deviceId == deviceId);
      if (device == null) {
        _actionStreams.add(LogNotification('Device not found: $deviceId'));
        UniversalBle.disconnect(deviceId);
        return;
      } else {
        if (kIsWeb) {
          // on web, log all characteristic changes for debugging
          _actionStreams.add(
            LogNotification(
              'Characteristic update for device ${device.toString()}, char: $characteristicUuid, value: ${bytesToReadableHex(value)}',
            ),
          );
        }
        try {
          await device.processCharacteristic(characteristicUuid, value);
        } catch (e, backtrace) {
          _actionStreams.add(
            LogNotification(
              "Error processing characteristic for device ${device.toString()} and char: $characteristicUuid: $e\n$backtrace",
            ),
          );
          if (kDebugMode) {
            print(e);
            print("backtrace: $backtrace");
          }
        }

        try {
          await _runCustomDeviceScript(
            device: device,
            characteristicUuid: characteristicUuid,
            value: value,
          );
        } catch (e, backtrace) {
          _actionStreams.add(
            LogNotification(
              "Error executing script for ${device.runtimeType} and char: $characteristicUuid: $e\n$backtrace",
            ),
          );
          if (e is FormatException) {
            final deviceType = device.runtimeType.toString();
            await DeviceScriptService.instance.deleteScript(deviceType);
            _actionStreams.add(
              LogNotification(
                "Deactivated custom script for ${device.runtimeType} due to invalid output format.",
              ),
            );
          }
          if (kDebugMode) {
            print(e);
            print("backtrace: $backtrace");
          }
        }
      }
    };

    UniversalBle.onConnectionChange = (BleConnectionChange change) {
      final deviceId = change.deviceId;
      final isConnected = change.isConnected;
      final device = bluetoothDevices.firstOrNullWhere((e) => e.device.deviceId == deviceId);
      if (device != null && !isConnected) {
        // allow reconnection
        _lastScanResult.removeWhere((d) => d.deviceId == deviceId);
      }
    };

    if (!kIsWeb && !screenshotMode) {
      // Checking permissions means *asking* for them on Apple platforms, so a
      // fresh install with nothing configured must not reach this: the wizard
      // owns that conversation. Everyone else is checked at launch, so a
      // permission revoked in System Settings surfaces here rather than as a
      // silently dead connection.
      if (!core.logic.deferLaunchPermissions) {
        core.permissions.getScanRequirements().then((perms) {
          if (Permissions.blockingScan(perms).isEmpty) {
            performScanning();
          }
        });
      }
      if (core.settings.getPhoneSteeringEnabled()) {
        toggleGyroscopeSteering(true);
      }
    }
  }

  Future<void> performScanning() async {
    if (isScanning.value) {
      return;
    }
    isScanning.value = true;
    ignoredDevicesNearby.value = const {};
    _actionStreams.add(LogNotification(AppLocalizations.current.scanningForDevicesShort));

    if (screenshotMode) {
      return;
    }

    // does not work on web, may not work on Windows
    if (!kIsWeb && !Platform.isWindows) {
      UniversalBle.getSystemDevices(
        withServices: BluetoothDevice.servicesToScan,
      ).then((devices) async {
        // getSystemDevices reports OS-connected/bonded devices, not live
        // advertisements — isEligibleSystemDevice keeps that query from
        // grabbing another app's power meter as if it were a trainer (see
        // its doc comment; fix-wave-C).
        final baseDevices = devices
            .mapNotNull(BluetoothDevice.fromScanResult)
            .where(BluetoothDevice.isEligibleSystemDevice)
            .toList();
        if (baseDevices.isNotEmpty) {
          addDevices(baseDevices);
        }
      });
    }

    await UniversalBle.startScan(
      // allow all to enable Wahoo Kickr Bike Shift detection
      //scanFilter: kIsWeb ? ScanFilter(withServices: BluetoothDevice.servicesToScan) : null,
      platformConfig: PlatformConfig(web: WebOptions(optionalServices: BluetoothDevice.servicesToScan)),
    );

    if (!kIsWeb) {
      _startWifiTrainerDiscovery();
      _gamePadSearchTimer = Timer.periodic(Duration(seconds: 3), (_) {
        Gamepads.list().then((list) {
          // Each listed controller subscribes to the event stream to track its
          // state. Only id and name are needed: dispose them, else every poll
          // leaves one more listener per pad running on every input event.
          for (final pad in list) {
            unawaited(pad.dispose());
          }
          final pads = list.map((pad) => GamepadDevice(pad.name.isEmpty ? 'Gamepad' : pad.name, id: pad.id)).toList();
          addDevices(pads);

          final removedDevices = gamepadDevices.where((device) => list.none((pad) => pad.id == device.id)).toList();
          for (var device in removedDevices) {
            devices.remove(device);
            _streamSubscriptions[device]?.cancel();
            _streamSubscriptions.remove(device);
            _connectionSubscriptions[device]?.cancel();
            _connectionSubscriptions.remove(device);
            signalChange(device);
          }
        });
      });
    } else {
      isScanning.value = false;
    }
  }

  /// Browse the LAN for DirCon trainers (always on while scanning; the
  /// scanner excludes BikeControl's own advertisements). Failures — e.g. the
  /// user denied the Local Network permission — are logged and never affect
  /// BLE scanning.
  void _startWifiTrainerDiscovery() {
    _wifiTrainerScanner ??= WifiTrainerScanner(
      onFound: (trainer) {
        _actionStreams.add(LogNotification('Found WiFi trainer: ${trainer.syntheticDevice.name}'));
        addDevices([ProxyDevice.wifi(trainer.syntheticDevice, host: trainer.host, port: trainer.port)]);
      },
      onLost: (deviceId) {
        final device = proxyDevices.firstOrNullWhere((d) => d.scanResult.deviceId == deviceId);
        // A connected device stays — the live TCP connection is the source
        // of truth; mDNS visibility can flap.
        if (device != null && !device.isConnected && !device.isStarting.value) {
          devices.remove(device);
          _streamSubscriptions[device]?.cancel();
          _streamSubscriptions.remove(device);
          _connectionSubscriptions[device]?.cancel();
          _connectionSubscriptions.remove(device);
          hasDevices.value = devices.isNotEmpty;
          signalChange(device);
        }
      },
    );
    _wifiTrainerScanner!.start().catchError((Object e, s) {
      _actionStreams.add(LogNotification('WiFi trainer discovery unavailable: $e'));
      recordError(e, s, context: 'Wifi Trainer Discovery');
    });
  }

  Future<void> _runCustomDeviceScript({
    required BluetoothDevice device,
    required String characteristicUuid,
    required Uint8List value,
  }) async {
    if (!IAPManager.instance.isPurchased.value && !IAPManager.instance.hasActiveSubscription) {
      return;
    }

    final scriptOutput = await DeviceScriptService.instance.runCustomScript(
      deviceType: device.runtimeType.toString(),
      characteristicUuid: characteristicUuid,
      data: value,
    );

    if (scriptOutput == null) {
      return;
    }

    final serviceUuid = device.serviceUuidForCharacteristic(scriptOutput.characteristicUuid);
    if (serviceUuid == null) {
      _actionStreams.add(
        LogNotification(
          'Script output characteristic ${scriptOutput.characteristicUuid} was not found on ${device.runtimeType}.',
        ),
      );
      return;
    }

    final characteristic = device.services
        ?.firstOrNullWhere((s) => s.uuid == serviceUuid)
        ?.characteristics
        .firstOrNullWhere((c) => c.uuid == scriptOutput.characteristicUuid);

    if (characteristic == null) {
      _actionStreams.add(
        LogNotification(
          'Script output characteristic ${scriptOutput.characteristicUuid} was not found on ${device.runtimeType}.',
        ),
      );
      return;
    } else if (!characteristic.properties.containsAny([
      CharacteristicProperty.write,
      CharacteristicProperty.writeWithoutResponse,
    ])) {
      _actionStreams.add(
        LogNotification(
          'Script output characteristic ${scriptOutput.characteristicUuid} on ${device.runtimeType} does not support writing.',
        ),
      );
      return;
    }

    await UniversalBle.write(
      device.device.deviceId,
      serviceUuid,
      scriptOutput.characteristicUuid,
      scriptOutput.data,
      withoutResponse: characteristic.properties.contains(CharacteristicProperty.writeWithoutResponse) == true,
    );
  }

  Future<void> startMyWhooshServer() {
    return core.whooshLink.startServer().catchError((e) {
      core.settings.setMyWhooshLinkEnabled(false);
      _actionStreams.add(LogNotification('Error starting MyWhoosh "Link" server: $e'));
      _actionStreams.add(
        AlertNotification(
          LogLevel.LOGLEVEL_ERROR,
          AppLocalizations.current.errorStartingMyWhooshLink,
        ),
      );
    });
  }

  void addDevices(List<BaseDevice> dev) {
    final ignoredDevices = core.settings.getIgnoredDevices();
    final ignoredDeviceIds = ignoredDevices.map((d) => d.id).toSet();
    final seenIgnored = <String>{};
    final newDevices = dev.where((device) {
      if (devices.contains(device)) return false;

      // Check if device is in the ignored list
      if (device is BluetoothDevice) {
        if (ignoredDeviceIds.contains(device.device.deviceId)) {
          seenIgnored.add(device.device.deviceId);
          return false;
        }
        // A controller the battery saver disconnected must not silently
        // reconnect when rediscovered until the reconnect cooldown has passed
        // or the user explicitly reconnects it.
        if (_suppressedAutoReconnect.contains(device.device.deviceId)) {
          return false;
        }
        if (_isDisconnectedForSession(device.device.deviceId)) {
          // Shown with the ignored ones, where Reconnect brings it back.
          seenIgnored.add(device.device.deviceId);
          return false;
        }
      }

      return true;
    }).toList();
    if (seenIgnored.isNotEmpty && !ignoredDevicesNearby.value.containsAll(seenIgnored)) {
      ignoredDevicesNearby.value = Set.unmodifiable({...ignoredDevicesNearby.value, ...seenIgnored});
    }
    devices.addAll(newDevices);
    _connectionQueue.addAll(newDevices);
    // A device held back for its setup (a Zwift Click V2 before its
    // unlock-mode choice) never connects, so no connect event would ever tell
    // the screens it is here — and they are where that setup is offered.
    for (final device in newDevices) {
      if (!device.shouldAutoConnect && device.setupNeed != null) _connectionStreams.add(device);
    }

    // A device kept in the list during an automatic reset cycle reappeared in
    // the scan: its fresh instance is filtered out above (same id), so queue
    // the existing instance for reconnection instead.
    final resetDevices = dev
        .mapNotNull((d) => devices.firstOrNullWhere((e) => e == d))
        .where((e) => e.isResetting && !e.isConnected && !_connectionQueue.contains(e))
        .toList();
    _connectionQueue.addAll(resetDevices);

    _handleConnectionQueue();

    hasDevices.value = devices.isNotEmpty;
  }

  void toggleGyroscopeSteering(bool enable) {
    final existing = gyroscopeDevices.firstOrNull;
    if (existing != null && !enable) {
      // Remove gyroscope steering
      disconnect(existing, forget: true, persistForget: false);
    } else if (enable) {
      // Add gyroscope steering
      final gyroDevice = GyroscopeSteering();
      addDevices([gyroDevice]);
    }
  }

  void _handleConnectionQueue() {
    // windows apparently has issues when connecting to multiple devices at once, so don't
    if (_connectionQueue.isNotEmpty && !_handlingConnectionQueue && !screenshotMode) {
      _handlingConnectionQueue = true;
      final device = _connectionQueue.removeAt(0);
      if (device is BluetoothDevice) _disconnectedDuringConnect.remove(device.device.deviceId);

      final willConnect = device.shouldAutoConnect;
      // Reconnections after an automatic reset happen every minute — keep
      // them silent. Captured here because the flag clears during handshake.
      // A device that already gave up (backoff) only gets quiet cooldown
      // rounds from here on — the guidance alert already said its piece.
      // Automatic retries after a failed connect stay quiet too — the first
      // failure already told the rider; the card shows the state.
      final isRetry = device is BluetoothDevice && _connectRetryCounts.containsKey(device.device.deviceId);
      final notify = willConnect && !device.isResetting && !_isInBackoff(device) && !isRetry;
      if (notify) {
        _actionStreams.add(
          AlertNotification(LogLevel.LOGLEVEL_INFO, AppLocalizations.current.connectingToDevice(device.toString())),
        );
      }
      _connect(device)
          .then((_) {
            _handlingConnectionQueue = false;

            if (notify) {
              _actionStreams.add(
                AlertNotification(
                  LogLevel.LOGLEVEL_INFO,
                  AppLocalizations.current.connectionSucceeded(device.toString()),
                ),
              );
            }
            if (_connectionQueue.isNotEmpty) {
              _handleConnectionQueue();
            }
          })
          .catchError((e) {
            device.isConnected = false;
            _handlingConnectionQueue = false;
            _scheduleConnectRetry(device);
            if (device is BluetoothDevice && device.keepsReconnectingWhileDropping) {
              // Keepalive probe: the reconnect churn is expected and is NOT
              // rear-derailleur contention, so the "claimed by the derailleur"
              // give-up guidance must not fire. Keep it to a quiet log.
              _actionStreams.add(LogNotification('${device.toString()}: connect attempt failed during probe ($e)'));
            } else if (_recordConnectFailure(device)) {
              // Backoff engaged — _recordConnectFailure emitted the guidance alert
              // (or the silent per-round log) in place of the generic toast.
            } else if (isRetry) {
              _actionStreams.add(LogNotification('${device.toString()}: connect attempt failed ($e)'));
            } else if (e is TimeoutException) {
              _actionStreams.add(
                AlertNotification(
                  LogLevel.LOGLEVEL_WARNING,
                  AppLocalizations.current.unableToConnectToDeviceTimeout(device.toString()),
                ),
              );
            } else {
              _actionStreams.add(
                AlertNotification(
                  LogLevel.LOGLEVEL_ERROR,
                  AppLocalizations.current.connectionFailed(device.toString(), e.toString()),
                ),
              );
            }
            if (_connectionQueue.isNotEmpty) {
              _handleConnectionQueue();
            }
          });
    }
  }

  /// Schedules another connect attempt for [device] after a failed one.
  ///
  /// A connect that fails with a disconnected event (Android GATT 133/147)
  /// is retried by the connectionStream listener: it drops the device and
  /// clears the scan dedupe so the next advertisement re-adds it. A connect
  /// that simply times out (macOS/iOS: `UniversalBle.connect` throws
  /// TimeoutException, no event ever follows) gets neither — the device would
  /// sit in [devices] unconnected, filtered out of every later [addDevices],
  /// and never be tried again. This timer is that path's retry; the
  /// listener's [disconnect] cancels it when the event does arrive.
  ///
  /// Trainers ([ProxyDevice]) are left out: their connect is gated on the
  /// rider's choice and coordinated with a twin entry, so an unprompted retry
  /// could start a second upstream next to the twin's.
  void _scheduleConnectRetry(BaseDevice device) {
    if (device is! BluetoothDevice || device is ProxyDevice || !device.shouldAutoConnect) return;
    final id = device.device.deviceId;
    if (_disconnectedDuringConnect.contains(id)) return;
    final attempt = (_connectRetryCounts[id] ?? 0) + 1;
    _connectRetryCounts[id] = attempt;
    final delay = connectRetryBaseDelay * (1 << (attempt - 1).clamp(0, 10));
    _connectRetryTimers.remove(id)?.cancel();
    _connectRetryTimers[id] = Timer(delay > connectRetryMaxDelay ? connectRetryMaxDelay : delay, () {
      _connectRetryTimers.remove(id);
      // Only this exact instance, still listed and idle: a removed/forgotten
      // device is gone from [devices]; a rediscovered fresh instance (equal
      // by id, not identical) is already handled by its own queue entry.
      final stillWanted =
          devices.any((d) => identical(d, device)) &&
          !device.isConnected &&
          !_connectionQueue.contains(device) &&
          !_suppressedAutoReconnect.contains(id) &&
          !_isDisconnectedForSession(id) &&
          !core.settings.getIgnoredDevices().any((d) => d.id == id);
      if (!stillWanted) return;
      _actionStreams.add(LogNotification('${device.toString()}: retrying connect (attempt ${attempt + 1})'));
      _connectionQueue.add(device);
      _handleConnectionQueue();
    });
  }

  /// Drops [device]'s pending retry and its failure streak.
  void _cancelConnectRetry(BaseDevice device, {bool blockInFlight = false}) {
    if (device is! BluetoothDevice) return;
    final id = device.device.deviceId;
    if (blockInFlight) _disconnectedDuringConnect.add(id);
    _connectRetryTimers.remove(id)?.cancel();
    _connectRetryCounts.remove(id);
  }

  /// Records a failed auto-connect attempt. Returns true when the device has
  /// exhausted [BluetoothDevice.maxAutoConnectAttempts] and backoff messaging
  /// (guidance alert on the first round, log-only afterwards) replaces the
  /// generic failure toast.
  bool _recordConnectFailure(BaseDevice device) {
    if (device is! BluetoothDevice) return false;
    final maxAttempts = device.maxAutoConnectAttempts;
    if (maxAttempts <= 0) return false;

    final id = device.device.deviceId;
    final failures = (_consecutiveConnectFailures[id] ?? 0) + 1;
    _consecutiveConnectFailures[id] = failures;
    if (failures < maxAttempts) return false;

    _engageBackoff(device);
    return true;
  }

  /// Records a quick drop — a connect that succeeded but died within
  /// [quickDropThreshold] (a WHEELTOP TX pod whose keepalive we can't answer
  /// yet does this in a tight loop). Skipped for devices that opt to keep
  /// cycling via [BluetoothDevice.keepsReconnectingWhileDropping] (the
  /// keepalive probe needs those reconnects). Engages the same backoff once
  /// the drop streak reaches the device's limit.
  void _recordQuickDrop(BluetoothDevice device) {
    final maxAttempts = device.maxAutoConnectAttempts;
    if (maxAttempts <= 0 || device.keepsReconnectingWhileDropping) return;

    final id = device.device.deviceId;
    final drops = (_quickDropCounts[id] ?? 0) + 1;
    _quickDropCounts[id] = drops;
    if (drops >= maxAttempts) _engageBackoff(device);
  }

  /// Suppresses auto-reconnect for [device] for [autoConnectBackoffCooldown],
  /// clears the stale scan-result entry when the cooldown lifts, and shows the
  /// give-up guidance alert once per session (log-only afterwards). Shared by
  /// the connect-failed and quick-drop backoff paths.
  void _engageBackoff(BluetoothDevice device) {
    final id = device.device.deviceId;
    _suppressedAutoReconnect.add(id);
    // Lift the suppression after the cooldown. The stale _lastScanResult entry
    // must go too — it would dedupe every future advertisement and block
    // rediscovery forever (same pitfall the battery-saver cooldown handles).
    // Cancel any earlier round's still-pending timer first — otherwise it
    // fires on its original schedule and can lift a later (even unrelated,
    // e.g. battery-saver) suppression on this id early.
    _backoffCooldownTimers.remove(id)?.cancel();
    _backoffCooldownTimers[id] = Timer(autoConnectBackoffCooldown, () {
      _backoffCooldownTimers.remove(id);
      _suppressedAutoReconnect.remove(id);
      _lastScanResult.removeWhere((d) => d.deviceId == id);
    });

    final guidance = device.connectionGuidance;
    final message = [
      AppLocalizations.current.connectionGaveUpAfterAttempts(device.toString()),
      if (guidance != null) guidance,
    ].join('\n');
    if (_backoffAlerted.add(id)) {
      _actionStreams.add(
        AlertNotification(
          LogLevel.LOGLEVEL_WARNING,
          message,
          buttonTitle: AppLocalizations.current.reconnect,
          onTap: () {
            _backoffCooldownTimers.remove(id)?.cancel();
            _suppressedAutoReconnect.remove(id);
            _consecutiveConnectFailures.remove(id);
            _quickDropCounts.remove(id);
            _lastScanResult.removeWhere((d) => d.deviceId == id);
            addDevices([device]);
          },
        ),
      );
    } else {
      _actionStreams.add(LogNotification(message));
    }
  }

  /// Connect a device that is already in the list — used by the in-place
  /// picker ("No connection" -> Virtual Shifting / Proxy on the same object).
  ///
  /// Routes through the same [_connect] path the auto-connect queue uses so the
  /// action / connection-state listeners are (re)attached. A bare
  /// [ProxyDevice.startProxy] would reconnect the BLE upstream but leave
  /// `isConnected` stuck — the listener that flips it is torn down on
  /// disconnect and only [_connect] re-establishes it.
  Future<void> connectDevice(BaseDevice device) async {
    // An explicit reconnect (e.g. the device picker) clears any battery-saver
    // suppression so the controller auto-reconnects normally again afterwards.
    // It is also a fresh decision by the rider, so any auto-connect backoff
    // streak starts over: the device gets its full attempt budget again
    // instead of re-suppressing after one more failure.
    if (device is BluetoothDevice) {
      final id = device.device.deviceId;
      _suppressedAutoReconnect.remove(id);
      _setDisconnectedForSession(id, null);
      _backoffCooldownTimers.remove(id)?.cancel();
      _consecutiveConnectFailures.remove(id);
      _quickDropCounts.remove(id);
    }
    // The rider is connecting it right now — a pending automatic retry would
    // race this attempt.
    _cancelConnectRetry(device);
    // A twin that would not let go is refused here, by the manual path itself
    // — not left to the auto-connect gate inside ProxyDevice.connect(), which
    // would decline silently and leave the rider staring at a picker that
    // snapped back to "No connection".
    if (device is ProxyDevice && !await _releaseTwin(device)) return;
    return _connect(device);
  }

  /// A trainer listed over both transports is one trainer: connecting its
  /// WiFi entry while the Bluetooth entry holds it (or vice versa) is a path
  /// switch, not a second connection. The sibling is torn down — and awaited —
  /// before this entry's connect starts, so at no point are two upstreams
  /// live. It stays listed as the way back; while this entry holds the
  /// trainer, [ProxyDevice.shouldAutoConnect] keeps the queue from bringing
  /// the sibling back on its own.
  ///
  /// Returns whether [device] may go ahead: true when no twin held the
  /// trainer or the twin is idle now; false when it is still not — then the
  /// rider has been told (alert) and the caller must not connect.
  ///
  /// The shared consent (`auto_connect_<trainerKey>`) and saved mode are
  /// deliberately left as the picker wrote them on a refusal: consent is the
  /// one key under which the sibling is still holding the trainer, so
  /// clearing it would strip the sibling's own reconnect too, and the saved
  /// mode is simply the rider's latest pick, taken up by whichever entry
  /// connects next.
  Future<bool> _releaseTwin(ProxyDevice device) async {
    final twin = twinOf(device);
    if (twin == null || !twin.isConnectedOrConnecting) return true;
    _actionStreams.add(
      LogNotification(
        '${device.trainerKey}: switching from ${twin.isWifiUpstream ? 'WiFi' : 'Bluetooth'} '
        'to ${device.isWifiUpstream ? 'WiFi' : 'Bluetooth'}',
      ),
    );
    // dropped: a sibling still mid-connect has no link to report yet, but its
    // teardown must run anyway or the in-flight connect lands next to ours.
    await disconnect(twin, forget: false, persistForget: false, keepInList: true, dropped: !twin.isConnected);
    // The sibling reports idle a moment after its teardown, not during it:
    // BaseDevice.disconnect() clears `isConnected` a microtask after
    // BluetoothDevice.disconnect() returns, and a connect still in flight only
    // unwinds — through its own failure on the torn-down transport — later
    // still, `isStarting` holding until it does. Wait it out, bounded, on the
    // whole held-state predicate rather than any one flag.
    final deadline = DateTime.now().add(twinReleaseTimeout);
    while (twin.isConnectedOrConnecting && DateTime.now().isBefore(deadline)) {
      await Future<void>.delayed(const Duration(milliseconds: 50));
    }
    if (!twin.isConnectedOrConnecting) return true;
    final l10n = AppLocalizations.current;
    _actionStreams.add(
      AlertNotification(
        LogLevel.LOGLEVEL_WARNING,
        l10n.trainerTwinStillConnecting(
          device.toString(),
          twin.isWifiUpstream ? l10n.connectionWifi : l10n.connectionBluetooth,
        ),
      ),
    );
    return false;
  }

  /// How long a path switch waits for the released sibling to report idle
  /// (see [_releaseTwin]). Mutable as a test seam.
  Duration twinReleaseTimeout = const Duration(seconds: 5);

  Future<void> _connect(BaseDevice device) async {
    // Cancel any stale subscriptions from a previous connect attempt so a retry
    // doesn't stack listeners on the same device's streams.
    await _streamSubscriptions.remove(device)?.cancel();
    await _connectionSubscriptions.remove(device)?.cancel();

    final actionSubscription = device.actionStream.listen((data) {
      _actionStreams.add(data);
      // Any button press — from a BLE controller or any other input device —
      // counts as rider activity and slides the inactivity timer. The timer only
      // arms while a BLE controller is connected (see hasEligibleControllers), so
      // non-BLE button activity simply keeps a co-connected controller alive.
      if (data is ButtonNotification) {
        _inactivityDisconnector?.onButtonActivity();
      }
    });
    _streamSubscriptions[device] = actionSubscription;

    if (device is BluetoothDevice) {
      final connectionStateSubscription = device.device.connectionStream.listen((state) {
        // A disconnected event for a device that is still marked connected is
        // a genuine drop; one arriving after a deliberate disconnect (which
        // already cleared the flag) is the platform's late echo of it.
        final wasConnected = device.isConnected;
        device.isConnected = state;
        if (state) _noteConnected(device);
        _connectionStreams.add(device);

        // Quick-drop tracking (Wheeltop TX pods connect then drop within
        // seconds because their keepalive is unanswered — a "successful"
        // connect the connect queue never counts as a failure). Only devices
        // that declare an attempt limit participate.
        if (device.maxAutoConnectAttempts > 0) {
          final id = device.device.deviceId;
          if (state) {
            _connectedAt[id] = DateTime.now();
          } else {
            final connectedAt = _connectedAt.remove(id);
            if (connectedAt != null) {
              if (DateTime.now().difference(connectedAt) >= quickDropThreshold) {
                // Survived long enough — a healthy connection clears the streak.
                _quickDropCounts.remove(id);
              } else {
                _recordQuickDrop(device);
              }
            }
          }
        }

        // An automatic reset cycle (ClickLogic) reboots the device every
        // minute — don't spam connect/disconnect notifications for it.
        final isSilentReset = device.isResetting;
        // A device that already gave up (backoff) delivers its failure as a
        // delayed disconnected event on this same listener — the guidance
        // alert already said its piece, so quiet cooldown rounds stay quiet
        // here too: no disconnected toast, no OS notification.
        final isSilentBackoff = !state && _isInBackoff(device);
        if (!state && !isSilentReset && !isSilentBackoff) {
          _actionStreams.add(
            AlertNotification(
              state ? LogLevel.LOGLEVEL_INFO : LogLevel.LOGLEVEL_WARNING,
              '${device.toString()} ${state ? AppLocalizations.current.connected.decapitalize() : AppLocalizations.current.disconnected.decapitalize()}',
            ),
          );
        }
        if (!isSilentReset && !isSilentBackoff) {
          core.flutterLocalNotificationsPlugin.show(
            id: 1338,
            title:
                '${device.toString()} ${state ? AppLocalizations.current.connected.decapitalize() : AppLocalizations.current.disconnected.decapitalize()}',
            body: !state ? AppLocalizations.current.tryingToConnectAgain : null,
            notificationDetails: NotificationDetails(
              android: AndroidNotificationDetails('Connection', 'Connection Status'),
              iOS: DarwinNotificationDetails(presentAlert: true, presentSound: false),
            ),
          );
        }
        if (!device.isConnected && !_inPlaceDisconnects.contains(device)) {
          disconnect(device, forget: false, persistForget: false, dropped: wasConnected);
          // try reconnect
          performScanning();
        }
      });
      _connectionSubscriptions[device] = connectionStateSubscription;
    }

    try {
      await device.connect();
      if (device is BluetoothDevice) {
        _consecutiveConnectFailures.remove(device.device.deviceId);
        _cancelConnectRetry(device);
      }
      // Deliberately gated on isConnected, not on connect() returning:
      // ProxyDevice.connect() is a no-op unless the rider has actually asked
      // for that trainer, so an ungated add here marks a trainer that never
      // connected as "connected this session" — and the home screen then
      // reports a brand-new trainer as having lost its connection.
      if (device.isConnected) _noteConnected(device);
      signalChange(device);

      IAPManager.instance.setAttributes();

      core.actionHandler.supportedApp?.keymap.addNewButtons(device.availableButtons);

      // Let the battery saver re-evaluate now that a device connected.
      _inactivityDisconnector?.onDeviceConnectionChanged();

      if (devices.isNotEmpty && !_androidNotificationsSetup && !kIsWeb && Platform.isAndroid) {
        _androidNotificationsSetup = true;
        // start foreground service only when app is in foreground
        NotificationRequirement.addPersistentNotification().catchError((e) {
          _actionStreams.add(LogNotification(e.toString()));
        });
      }
    } catch (e, backtrace) {
      await _streamSubscriptions.remove(device)?.cancel();
      // Deliberately do NOT cancel _connectionSubscriptions here. Android
      // delivers a failed connect twice, and the ordering varies: on real
      // devices the disconnected event usually arrives BEFORE the exception
      // (the listener has already cleaned up — cancelling again is a no-op),
      // while other stacks and the fake platform deliver it after (then this
      // still-attached listener is the only thing that removes the device and
      // re-enables retry). Cancelling here would break the second ordering.
      _actionStreams.add(LogNotification("$e\n$backtrace"));
      if (kDebugMode) {
        print(e);
        print("backtrace: $backtrace");
      }
      rethrow;
    }
  }

  void signalNotification(BaseNotification notification) {
    _actionStreams.add(notification);
  }

  void signalChange(BaseDevice baseDevice) {
    _connectionStreams.add(baseDevice);
  }

  /// [dropped]: the link already went away on its own (peripheral-side BLE
  /// drop, DirCon socket closed). The drop listeners flip [BaseDevice.isConnected]
  /// before calling in, so without this flag the device's own teardown would be
  /// skipped — and a ProxyDevice would leave its definition attached to the
  /// shared emulator, still advertising and still being written to.
  Future<void> disconnect(
    BaseDevice device, {
    required bool persistForget,
    required bool forget,
    bool keepInList = false,
    bool dropped = false,
  }) async {
    if (keepInList) _inPlaceDisconnects.add(device);
    // Removed, forgotten, put on "No connection" or dropped (whose listener
    // path owns the retry via rediscovery): no automatic connect retry.
    _cancelConnectRetry(device, blockInFlight: true);
    final tearingDown = _disconnecting.contains(device);
    if (!tearingDown) _disconnecting.add(device);
    try {
      if (!tearingDown && (device.isConnected || dropped)) {
        await device.disconnect();
      }
    } finally {
      if (keepInList) _inPlaceDisconnects.remove(device);
      if (!tearingDown) _disconnecting.remove(device);
    }

    if (device is BluetoothDevice) {
      await _unregisterSensorSource(device, forget: forget);

      if (persistForget) {
        // Add device to ignored list when forgetting
        await core.settings.addIgnoredDevice(device.device.deviceId, device.toString());
        _actionStreams.add(LogNotification('Device ignored: ${device.toString()}'));
      }
      // For an in-place disconnect (the "No connection" picker entry) keep the
      // scan result so the scanner doesn't churn a fresh duplicate while the
      // user stays on the details page — the same device object must remain
      // reconnectable.
      if (!forget && !keepInList) {
        // allow reconnection
        _lastScanResult.removeWhere((d) => d.deviceId == device.device.deviceId);
      }

      // Clean up subscriptions and scan results for reconnection
      _streamSubscriptions[device]?.cancel();
      _streamSubscriptions.remove(device);
      _connectionSubscriptions[device]?.cancel();
      _connectionSubscriptions.remove(device);

      // Forgetting an emulated device tears down its fake peripheral and clears
      // the scan-result dedupe cache so the same profile can be re-added later.
      if (forget && core.emulation.isEmulated(device.device.deviceId)) {
        core.emulation.stop(device.device.deviceId);
        _lastScanResult.removeWhere((d) => d.deviceId == device.device.deviceId);
      }

      // Remove device from the list — unless it is rebooting due to an
      // automatic reset and will be back in a few seconds, or this is an
      // in-place disconnect (keepInList) where the open details page still
      // holds this exact object and must be able to reconnect it. Dropping it
      // here would orphan that reference: rediscovery builds a *new* device,
      // and the page's stale one fails to reconnect ("Device not found").
      if (!keepInList && (forget || !device.isResetting)) {
        devices.remove(device);
        hasDevices.value = devices.isNotEmpty;
      }
    } else if (device is GyroscopeSteering || device is HidDevice) {
      // Clean up subscriptions
      _streamSubscriptions[device]?.cancel();
      _streamSubscriptions.remove(device);
      _connectionSubscriptions[device]?.cancel();
      _connectionSubscriptions.remove(device);

      // Remove device from the list
      devices.remove(device);
      hasDevices.value = devices.isNotEmpty;
    }

    signalChange(device);
    _inactivityDisconnector?.onDeviceConnectionChanged();
  }

  Future<void> disconnectAll() async {
    _actionStreams.add(LogNotification(AppLocalizations.current.disconnectingAllDevices));
    // Collected rather than awaited inline: this loop is otherwise fully
    // synchronous, and awaiting per-device here would open a re-entrancy
    // window between devices during a global teardown for no benefit —
    // `bluetoothDevices` is already a `.toList()` snapshot, so nothing else
    // needs the sensor-source teardown to have landed before the next
    // device's turn, only before disconnectAll() itself returns.
    final sensorSourceTeardowns = <Future<void>>[];
    for (var device in bluetoothDevices) {
      _streamSubscriptions[device]?.cancel();
      _streamSubscriptions.remove(device);
      _connectionSubscriptions[device]?.cancel();
      _connectionSubscriptions.remove(device);
      // Not a "forget": Bluetooth going away in bulk is a transient global
      // drop, not the rider individually forgetting every device, so the
      // selection is left alone the same way a single transient drop is.
      sensorSourceTeardowns.add(_unregisterSensorSource(device, forget: false));
      device.disconnect();
      signalChange(device);
      devices.remove(device);
    }
    await Future.wait(sensorSourceTeardowns);
    _gamePadSearchTimer?.cancel();
    _lastScanResult.clear();
    // Everything is gone, so the battery-saver suppression is moot — a later
    // rediscovery should auto-connect normally again.
    _suppressedAutoReconnect.clear();
    _consecutiveConnectFailures.clear();
    _quickDropCounts.clear();
    _connectedAt.clear();
    _backoffAlerted.clear();
    for (final timer in _backoffCooldownTimers.values) {
      timer.cancel();
    }
    _backoffCooldownTimers.clear();
    for (final timer in _connectRetryTimers.values) {
      timer.cancel();
    }
    _connectRetryTimers.clear();
    _connectRetryCounts.clear();
    _disconnectedDuringConnect.clear();
    hasDevices.value = false;
    _inactivityDisconnector?.onDeviceConnectionChanged();
  }

  Future<void> stop() async {
    final isBtEnabled = (await UniversalBle.getBluetoothAvailabilityState()) == AvailabilityState.poweredOn;
    if (isBtEnabled) {
      UniversalBle.stopScan();
    }
    _wifiTrainerScanner?.stop();
    // Symmetric with [performScanning], which arms it: gamepad polling is part
    // of scanning, and stopping left it running. It also leaked — stop() clears
    // isScanning, so the next performScanning() sails past its guard and
    // assigns a second periodic timer over the top of the first, once per
    // stop/rescan cycle (unlock-mode switches do exactly that).
    _gamePadSearchTimer?.cancel();
    _gamePadSearchTimer = null;
    isScanning.value = false;
    _lastScanResult.clear();
    _androidNotificationsSetup = false;
  }

  // ── Inactivity / battery-saver disconnect (issue #329) ─────────────────────

  /// Test seam: run the inactivity battery-saver disconnect directly instead of
  /// waiting out the real idle timer.
  @visibleForTesting
  void debugTriggerInactivityTimeout([Duration timeout = const Duration(minutes: 60)]) => _onInactivityTimeout(timeout);

  /// Called by [_inactivityDisconnector] when the idle timeout elapses.
  /// Disconnects every connected BLE controller (battery-powered; ProxyDevice
  /// and accessories excluded), then surfaces an in-app alert with a Reconnect
  /// action and an OS push notification. [timeout] is the elapsed window, used
  /// for the human-readable message.
  void _onInactivityTimeout(Duration timeout) {
    final controllers = controllerDevices
        .whereType<BluetoothDevice>()
        .where((d) => d.isConnected && !d.exemptFromBatterySaver)
        .toList();
    if (controllers.isEmpty) return;

    for (final device in controllers) {
      // Suppress auto-reconnect so the rediscovery that follows the disconnect
      // doesn't immediately bring the controller back (the whole point is to
      // let its battery rest). Lifted by the Reconnect action below or by the
      // cooldown timer once the controller had time to fall asleep.
      _suppressedAutoReconnect.add(device.device.deviceId);
      unawaited(
        disconnect(device, forget: true, persistForget: false).catchError((Object error, StackTrace stackTrace) {
          _actionStreams.add(
            LogNotification('Failed to disconnect ${device.toString()} after inactivity timeout: $error\n$stackTrace'),
          );
        }),
      );
    }

    // Lift the suppression once the controller had time to power down. The
    // stale _lastScanResult entry must go too: the controller's last
    // advertisement right after the disconnect re-entered the dedup list, and
    // it would block every future advertisement from reaching addDevices —
    // leaving a woken controller unconnectable until an app restart.
    final suppressedIds = controllers.map((d) => d.device.deviceId).toList();
    Timer(inactivityReconnectCooldown, () {
      for (final id in suppressedIds) {
        _suppressedAutoReconnect.remove(id);
        _lastScanResult.removeWhere((d) => d.deviceId == id);
      }
    });

    _actionStreams.add(
      AlertNotification(
        LogLevel.LOGLEVEL_WARNING,
        AppLocalizations.current.controllersDisconnectedInactivity(timeout.inMinutes),
        buttonTitle: AppLocalizations.current.reconnect,
        // Route reconnection through the connection queue so BLE connects are
        // serialized (Windows fails on parallel connects) and ignored-device
        // filtering applies. disconnect(persistForget: false) above did not add
        // these to the ignore list, so they are eligible to be re-added.
        onTap: () {
          for (final device in controllers) {
            _suppressedAutoReconnect.remove(device.device.deviceId);
          }
          addDevices(controllers);
        },
      ),
    );

    if (!kIsWeb) {
      core.flutterLocalNotificationsPlugin.show(
        id: 1339,
        title: AppLocalizations.current.batterySaverTitle,
        body: AppLocalizations.current.controllersDisconnectedInactivity(timeout.inMinutes),
        notificationDetails: NotificationDetails(
          android: AndroidNotificationDetails('BatterySaver', 'Battery Saver'),
          iOS: DarwinNotificationDetails(presentAlert: true, presentSound: false),
        ),
      );
    }
  }
}

/// Relay sink that forwards incline writes upstream through the active
/// [FitnessBikeDefinition] (e.g. to a Wahoo app connected over DirCon).
/// Always reports [followsGrade] == true — the relay has no manual-hold state.
class _ClimbRelaySink implements InclineSink {
  _ClimbRelaySink(this._fbd);
  final FitnessBikeDefinition _fbd;
  @override
  bool get followsGrade => true;
  @override
  Future<bool> writeInclineRaw(int g) => _fbd.writeClimbInclineUpstream(g);
}
