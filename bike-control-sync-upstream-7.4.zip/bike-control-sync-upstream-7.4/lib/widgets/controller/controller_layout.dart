import 'package:bike_control/utils/keymap/buttons.dart';
import 'package:flutter/material.dart';

/// Geometric description of a physical controller's silhouette. Each concrete
/// shape has a known painter in [controller_contour_painter.dart].
enum ContourShape {
  /// Rounded-rect pill shape — e.g. Cycplus BC2, Zwift Click V2.
  pill,

  /// Flat triangular steering pad — e.g. Elite Sterzo.
  steeringPad,

  /// Phone silhouette — e.g. Gyroscope Steering (virtual).
  phone,
}

/// Declarative layout for one physical controller. Positions use normalized
/// [0, 1] coordinates so the layout scales with the available footer width.
/// Keys are the actual [ControllerButton] instances (typed, not strings) so
/// typos are compile-time errors.
class ControllerLayout {
  final double aspectRatio;
  final ContourShape shape;
  final double padding;
  final Map<ControllerButton, Offset> positions;

  /// Optional asset path to an SVG silhouette in `assets/contours/`. When set,
  /// the canvas renders that SVG behind the buttons instead of the procedural
  /// [ControllerContourPainter] for [shape].
  final String? svgAsset;

  /// Rotates the SVG silhouette by this many degrees (90° increments only).
  /// [aspectRatio] and [positions] are interpreted in the post-rotation frame
  /// — i.e. the on-screen canvas. Useful when the source SVG is portrait but
  /// the device sits landscape on the bar (e.g. ThinkRider VS200).
  final double rotation;

  /// Horizontally mirrors the SVG silhouette. Used to share a single source
  /// SVG between mirror-image device pairs (e.g. Zwift Play left vs right).
  /// [positions] still refer to the on-screen frame, so the buttons aren't
  /// flipped — only the silhouette art is.
  final bool mirrorX;

  /// Where the SVG silhouette sits in the canvas, on screen (after
  /// [mirrorX]). Centred by default; a layout whose buttons reach past one
  /// side of the art frames the art plus its buttons, and places the art
  /// within that frame here.
  final Alignment svgAlignment;

  const ControllerLayout({
    required this.aspectRatio,
    required this.shape,
    required this.positions,
    this.svgAsset,
    this.rotation = 0,
    this.padding = 0,
    this.mirrorX = false,
    this.svgAlignment = Alignment.center,
  });
}
