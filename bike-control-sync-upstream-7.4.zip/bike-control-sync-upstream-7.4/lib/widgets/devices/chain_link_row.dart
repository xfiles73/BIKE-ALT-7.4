import 'package:bike_control/pages/home/chain_state.dart';
import 'package:bike_control/utils/i18n_extension.dart';
import 'package:bike_control/widgets/home/ampel.dart';
import 'package:bike_control/widgets/home/chain_card.dart'
    show StepRow, chainCardFooterKey, chainCardHighlightKey, chainCardSubtitleKey;
import 'package:bike_control/widgets/home/chain_highlight.dart';
import 'package:bike_control/widgets/ui/bk_grouped_section.dart';
import 'package:bike_control/widgets/ui/bk_status_dot.dart';
import 'package:bike_control/widgets/ui/bk_tappable.dart';
import 'package:bike_control/widgets/ui/bk_touch_target.dart';
import 'package:bike_control/widgets/ui/colors.dart';
import 'package:bike_control/widgets/ui/type_scale.dart';
import 'package:flutter/foundation.dart' show ValueListenable;
import 'package:shadcn_flutter/shadcn_flutter.dart';

/// The status tone a link's state reads in.
BkStatusTone chainStatusTone(LinkStatus status) => switch (status) {
  LinkStatus.ready => BkStatusTone.success,
  LinkStatus.attention => BkStatusTone.warning,
  LinkStatus.problem => BkStatusTone.danger,
  LinkStatus.off => BkStatusTone.neutral,
};

/// Where a link row's text starts: the row inset, the icon tile and the gap.
const double chainRowTextInset = BkGroupedSection.inset + BkIconTile.size + BkGroupedRow.gap;

/// The chevron a row with somewhere to go ends its header with.
const Key chainRowChevronKey = ValueKey('chain-row-chevron');

/// One link of the setup chain as a row of a Devices group: the device's tile,
/// its name and a detail line, and its status as a dot and words at the end.
///
/// Whatever the link still needs sits under the row, indented to the text:
/// the outstanding steps with the next one's fix ("Set up", "Enable overlay"),
/// then any live readout ([body]) and an offer along the bottom ([footer]).
/// Nothing a rider could reach from the old chain card is lost — only its
/// frame.
class ChainLinkRow extends StatefulWidget {
  const ChainLinkRow({
    super.key,
    required this.link,
    required this.leading,
    required this.title,
    this.statusLabel,
    this.subtitle,
    this.statusDetail,
    this.statusBadges = const [],
    this.appName,
    this.onTap,
    this.onInstructions,
    this.instructionsLabel,
    this.onSecondaryAction,
    this.secondaryActionLabel,
    this.onOffer,
    this.offerLabel,
    this.action,
    this.body,
    this.footer,
    this.highlight,
    this.titleColor,
  });

  final ChainLink link;

  /// The icon tile (or the trainer app's logo).
  final Widget leading;

  final String title;

  /// Quiet line under the title: firmware and signal, the transport.
  final String? subtitle;

  /// Null for an invitation row that has no state to report yet.
  final String? statusLabel;

  /// A second line under the status: battery, "to MyWhoosh", the broadcast's
  /// wire.
  final Widget? statusDetail;

  /// Warning glyphs beside [statusDetail] — a battery about to die, a
  /// firmware update, a weak signal.
  final List<Widget> statusBadges;

  /// Fills "{app}" in the steps' wording.
  final String? appName;

  /// Opens this link's own page.
  final VoidCallback? onTap;

  /// The active step's fix — see [StepRow].
  final VoidCallback? onInstructions;
  final String? instructionsLabel;
  final VoidCallback? onSecondaryAction;
  final String? secondaryActionLabel;

  /// An optional step's action while it is not the step in front — see
  /// [StepRow.onOffer]. [offerLabel] names it, or returns null for a step
  /// with nothing to offer.
  final ValueChanged<SetupStep>? onOffer;
  final String? Function(SetupStep step)? offerLabel;

  /// The row's one direct action, under its name — "Connect" on a trainer
  /// that is nearby but not connected — for a row with no steps to carry it.
  final ({String label, IconData? icon, VoidCallback onPressed})? action;

  /// Live content under the row: the trainer's numbers, the sensor chips.
  final Widget? body;

  /// An offer along the row's bottom edge ("Share sensors instead").
  final Widget? footer;

  /// Makes the row jump out once every time its value changes — see
  /// [ChainHighlightController].
  final ValueListenable<int>? highlight;

  final Color? titleColor;

  @override
  State<ChainLinkRow> createState() => _ChainLinkRowState();
}

class _ChainLinkRowState extends State<ChainLinkRow> with TickerProviderStateMixin {
  late final AnimationController _highlight = AnimationController(
    vsync: this,
    duration: chainHighlightDuration,
    // Reduced motion keeps the row still; the flash itself must still last.
    animationBehavior: AnimationBehavior.preserve,
  );

  /// 1 while the row has a checklist, 0 once the last step has ticked away.
  ///
  /// Only that change is a movement — the checklist growing in, or the row
  /// shrinking to its header when everything is done. A change inside the
  /// checklist (a step appearing above the next one, a line rewording itself)
  /// lands at once: an AnimatedSize here clipped the new content to the old
  /// height while it caught up, and a step with a long hint showed its button
  /// cut off at the row's bottom edge.
  late final AnimationController _checklist = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 260),
    value: widget.link.pendingSteps.isEmpty ? 0 : 1,
  );

  late final Animation<double> _checklistSize = CurvedAnimation(parent: _checklist, curve: Curves.easeOutCubic);

  /// The steps last shown, so the checklist collapsing away still has its
  /// lines to collapse rather than vanishing first.
  late List<SetupStep> _lastPending = widget.link.pendingSteps;

  bool _hovered = false;

  @override
  void initState() {
    super.initState();
    widget.highlight?.addListener(_play);
  }

  @override
  void didUpdateWidget(covariant ChainLinkRow oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.highlight != widget.highlight) {
      oldWidget.highlight?.removeListener(_play);
      widget.highlight?.addListener(_play);
    }
    final hasChecklist = widget.link.pendingSteps.isNotEmpty;
    if (hasChecklist != oldWidget.link.pendingSteps.isNotEmpty) {
      if (hasChecklist) {
        _checklist.forward();
      } else {
        _checklist.reverse();
      }
    }
  }

  @override
  void dispose() {
    widget.highlight?.removeListener(_play);
    _highlight.dispose();
    _checklist.dispose();
    super.dispose();
  }

  void _play() => _highlight.forward(from: 0);

  @override
  Widget build(BuildContext context) {
    final link = widget.link;
    final pending = link.pendingSteps;
    final content = Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: [
        _header(context),
        if (widget.action case final action?)
          Padding(
            padding: const EdgeInsets.fromLTRB(chainRowTextInset, 0, BkGroupedSection.inset, 12),
            child: Align(
              alignment: AlignmentDirectional.centerStart,
              child: BkTouchTarget(
                child: PrimaryButton(
                  alignment: Alignment.center,
                  size: ButtonSize.small,
                  onPressed: action.onPressed,
                  leading: action.icon == null ? null : Icon(action.icon, size: 14),
                  child: Text(action.label),
                ),
              ),
            ),
          ),
        if (widget.body case final body?) ...[
          const BkGroupedDivider(indent: chainRowTextInset),
          Padding(
            padding: const EdgeInsets.fromLTRB(chainRowTextInset, 10, BkGroupedSection.inset, 12),
            child: body,
          ),
        ],
        _checklistSection(context, link, pending),
        if (widget.footer case final footer?)
          Column(
            key: chainCardFooterKey,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const BkGroupedDivider(indent: chainRowTextInset),
              footer,
            ],
          ),
      ],
    );
    return _highlighted(context, content);
  }

  /// What the link still needs, indented to the row's text — see
  /// [_checklist] for when it moves.
  Widget _checklistSection(BuildContext context, ChainLink link, List<SetupStep> pending) {
    if (pending.isNotEmpty) _lastPending = pending;
    final steps = pending.isNotEmpty ? pending : _lastPending;
    return AnimatedBuilder(
      animation: _checklist,
      builder: (context, child) {
        if (_checklist.isDismissed || steps.isEmpty) return const SizedBox(width: double.infinity);
        // At full size this lays the checklist out at exactly its own height.
        return SizeTransition(sizeFactor: _checklistSize, alignment: Alignment.topCenter, child: child);
      },
      child: Padding(
        // The step's own tick sits where the row's text starts.
        padding: const EdgeInsets.fromLTRB(chainRowTextInset - 10, 0, 10, 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            for (final (index, step) in steps.indexed)
              // A standby controller's steps are all offers: none is "the
              // next thing to do", so none is highlighted, and the first
              // keeps its fix as a quiet button.
              StepRow(
                step: step,
                active: index == 0 && !link.standby,
                appName: widget.appName,
                onInstructions: index == 0 ? widget.onInstructions : null,
                instructionsLabel: widget.instructionsLabel,
                onSecondaryAction: index == 0 ? widget.onSecondaryAction : null,
                secondaryActionLabel: widget.secondaryActionLabel,
                onOffer: link.standby
                    ? (index == 0 ? widget.onInstructions : null)
                    : widget.onOffer == null
                    ? null
                    : () => widget.onOffer!(step),
                offerLabel: link.standby
                    ? (index == 0 ? widget.instructionsLabel ?? context.i18n.chainShowMeHow : null)
                    : widget.offerLabel?.call(step),
              ),
          ],
        ),
      ),
    );
  }

  Widget _header(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final typography = context.typography;
    // A controller the rider is riding without reads quiet, not amber: it is
    // not something to fix right now — see [ChainLink.standby].
    final tone = widget.link.standby ? BkStatusTone.neutral : chainStatusTone(widget.link.status);
    final detail = widget.statusDetail;
    final badges = widget.statusBadges;

    final row = ConstrainedBox(
      constraints: const BoxConstraints(minHeight: 56),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: BkGroupedSection.inset, vertical: 10),
        child: Row(
          children: [
            widget.leading,
            const Gap(BkGroupedRow.gap),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                spacing: 2,
                children: [
                  Text(
                    widget.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: typography.base.copyWith(
                      fontWeight: FontWeight.w600,
                      color: widget.titleColor ?? cs.foreground,
                    ),
                  ),
                  if (widget.subtitle case final subtitle? when subtitle.isNotEmpty)
                    Text(
                      subtitle,
                      key: chainCardSubtitleKey,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: typography.xSmall.copyWith(color: cs.mutedForeground),
                    ),
                ],
              ),
            ),
            if (widget.statusLabel != null || detail != null || badges.isNotEmpty) ...[
              const Gap(8),
              ConstrainedBox(
                // A long status ("Waiting for MyWhoosh to connect to …") wraps
                // rather than squeezing the name to nothing.
                constraints: const BoxConstraints(maxWidth: 170),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisSize: MainAxisSize.min,
                  spacing: 3,
                  children: [
                    if (widget.statusLabel case final label?) BkStatusDot(label: label, tone: tone),
                    if (detail != null || badges.isNotEmpty)
                      DefaultTextStyle.merge(
                        style: typography.xSmall.copyWith(color: cs.mutedForeground),
                        textAlign: TextAlign.end,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          spacing: 4,
                          children: [
                            ...badges,
                            if (detail != null) Flexible(child: detail),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
            ],
            // The whole header opens the link's page, and a green row has no
            // button left to hint at that — the same quiet chevron as every
            // other row that opens something, and Ride's step rows.
            if (widget.onTap != null) ...[
              const Gap(4),
              Icon(LucideIcons.chevronRight, key: chainRowChevronKey, size: 16, color: cs.mutedForeground),
            ],
          ],
        ),
      ),
    );

    if (widget.onTap == null) return row;
    return BkTappable(
      onPressed: widget.onTap,
      onHover: (hovered) => setState(() => _hovered = hovered),
      child: ColoredBox(
        color: _hovered ? bkCardHover(context) : const Color(0x00000000),
        child: row,
      ),
    );
  }

  /// The highlight: an accent outline and wash over the row that fade out.
  /// Rows sit inside a clipped group, so unlike the old card this one keeps
  /// still — the flash alone says "this one", with or without motion.
  Widget _highlighted(BuildContext context, Widget content) {
    final accent = AmpelStyle.of(
      context,
      widget.link.status == LinkStatus.problem ? LinkStatus.problem : LinkStatus.attention,
    ).color;
    return AnimatedBuilder(
      animation: _highlight,
      child: content,
      builder: (context, content) {
        final opacity = chainHighlightBorderOpacity(_highlight.value);
        // Always a stack, so the row's live content is never rebuilt from
        // scratch when a flash starts or ends.
        return Stack(
          fit: StackFit.passthrough,
          children: [
            content!,
            if (_highlight.isAnimating)
              Positioned.fill(
                child: IgnorePointer(
                  child: DecoratedBox(
                    key: chainCardHighlightKey(widget.link.id),
                    decoration: BoxDecoration(
                      color: accent.withValues(alpha: 0.10 * opacity),
                      border: Border.all(color: accent.withValues(alpha: opacity), width: 2),
                      borderRadius: BorderRadius.circular(BkGroupedSection.inset),
                    ),
                  ),
                ),
              ),
          ],
        );
      },
    );
  }
}

/// An action row inside a Devices group: an accent "+" tile and an accent
/// title — "Connect Controllers", "Connect a smart trainer".
class DeviceAddRow extends StatelessWidget {
  const DeviceAddRow({super.key, required this.title, this.subtitle, required this.onPressed, this.icon});

  final String title;
  final String? subtitle;
  final VoidCallback onPressed;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    final accent = bkAccentText(context);
    return BkGroupedRow(
      leading: BkIconTile(icon: icon ?? LucideIcons.plus, color: accent),
      title: title,
      subtitle: subtitle,
      titleColor: accent,
      onPressed: onPressed,
    );
  }
}
