import 'package:bike_control/main.dart';
import 'package:bike_control/utils/core.dart';
import 'package:bike_control/utils/i18n_extension.dart';
import 'package:bike_control/utils/keymap/apps/supported_app.dart';
import 'package:bike_control/widgets/ui/connection_method.dart';
import 'package:bike_control/widgets/ui/toast.dart';
import 'package:dartx/dartx.dart';
import 'package:prop/prop.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart';

class OpenBikeControlBluetoothTile extends StatefulWidget {
  final bool small;
  const OpenBikeControlBluetoothTile({super.key, required this.small});

  @override
  State<OpenBikeControlBluetoothTile> createState() => _OpenBikeProtocolTileState();
}

class _OpenBikeProtocolTileState extends State<OpenBikeControlBluetoothTile> {
  /// Built once, not per build: PlatformRequirement carries a mutable
  /// `status`, so rebuilding the list every frame throws away whatever the
  /// last probe learned.
  final _requirements = core.permissions.getRemoteControlRequirements();

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder(
      valueListenable: core.obpBluetoothEmulator.isStarted,
      builder: (context, isStarted, _) {
        return ValueListenableBuilder(
          valueListenable: core.obpBluetoothEmulator.connectedApp,
          builder: (context, isConnected, _) {
            return ConnectionMethod(
              small: widget.small,
              trainerConnection: core.obpBluetoothEmulator,
              isRecommended: true,
              supportLevel: core.settings.getTrainerApp()?.supportLevel(AppConnectionMethod.obpBle),
              supportedActions: isConnected?.supportedActions,
              isEnabled: core.settings.getObpBleEnabled(),
              title: context.i18n.connectUsingBluetooth,
              description: isConnected != null
                  ? context.i18n.connectedTo(
                      "${isConnected.appId}:\n${isConnected.supportedActions.joinToString(transform: (s) => s.title)}",
                    )
                  : isStarted
                  ? context.i18n.chooseBikeControlInConnectionScreen
                  : context.i18n.letsAppConnectOverBluetooth(shownTrainerAppName(core.settings.getTrainerApp()?.name ?? '')),
              requirements: _requirements,
              onChange: (value) async {
                if (value) {
                  await core.stopAllBleConnections();
                }
                core.settings.setObpBleEnabled(value);
                if (!value) {
                  core.obpBluetoothEmulator.stopServer();
                } else if (value) {
                  core.obpBluetoothEmulator.startServer().catchError((e, s) {
                    recordError(e, s, context: 'OBP BLE Emulator');
                    core.settings.setObpBleEnabled(false);
                    buildToast(
                      level: LogLevel.LOGLEVEL_WARNING,
                      title: context.i18n.errorStartingOpenBikeControlBluetoothServer,
                    );
                  });
                }
              },
            );
          },
        );
      },
    );
  }
}
